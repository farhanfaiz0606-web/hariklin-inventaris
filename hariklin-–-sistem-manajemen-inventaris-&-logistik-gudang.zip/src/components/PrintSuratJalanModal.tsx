import React, { useState } from 'react';
import { X, Printer, FileCheck2 } from 'lucide-react';
import { Peminjaman } from '../types';

interface PrintSuratJalanModalProps {
  isOpen: boolean;
  onClose: () => void;
  peminjamanList: Peminjaman[];
  initialLoan?: Peminjaman | null;
}

export const PrintSuratJalanModal: React.FC<PrintSuratJalanModalProps> = ({
  isOpen,
  onClose,
  peminjamanList,
  initialLoan,
}) => {
  const [selectedId, setSelectedId] = useState<string>(
    initialLoan ? initialLoan.id : peminjamanList[0]?.id || ''
  );

  if (!isOpen) return null;

  const currentLoan = peminjamanList.find((p) => p.id === selectedId) || initialLoan || peminjamanList[0];

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-3xl max-h-[95vh] overflow-hidden flex flex-col">
        {/* Modal Header (hidden in print) */}
        <div className="flex items-center justify-between p-4 border-b border-slate-200 bg-slate-50 no-print">
          <div className="flex items-center gap-2">
            <FileCheck2 className="w-4 h-4 text-emerald-600" />
            <h3 className="font-bold text-slate-900 text-sm">Cetak Surat Jalan Bukti Peminjaman Alat</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              disabled={!currentLoan}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shadow-xs disabled:opacity-50"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak Surat Jalan</span>
            </button>
            <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-600 rounded">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Loan Transaction Selector (hidden in print) */}
        <div className="p-4 border-b border-slate-200 bg-white no-print">
          <label className="block text-slate-700 font-semibold text-xs mb-1">
            Pilih Nomor Transaksi Peminjaman:
          </label>
          <select
            value={selectedId}
            onChange={(e) => setSelectedId(e.target.value)}
            className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs bg-white"
          >
            {peminjamanList.map((p) => (
              <option key={p.id} value={p.id}>
                [{p.noTransaksi}] - {p.namaPeminjam} ({p.keperluan}) - Tanggal: {p.tanggalPinjam}
              </option>
            ))}
          </select>
        </div>

        {/* PRINTABLE DOCUMENT BODY */}
        <div className="p-8 overflow-y-auto flex-1 bg-white text-slate-900 print:p-0">
          {currentLoan ? (
            <div className="space-y-6">
              {/* Document Letterhead */}
              <div className="border-b-2 border-slate-900 pb-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-white p-1 border border-slate-200 flex items-center justify-center shrink-0">
                    <img
                      src="/hariklin-logo.jpg"
                      alt="HARIKLIN"
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div>
                    <div className="text-2xl font-black tracking-tight text-emerald-700">HARIKLIN</div>
                    <div className="text-xs font-bold tracking-wider text-slate-800 uppercase">
                      Sistem Manajemen Inventaris &amp; Logistik Gudang
                    </div>
                    <div className="text-[10px] text-slate-500">
                      Layanan Cleaning &amp; Pemeliharaan Profesional &middot; Gudang Logistik Pusat
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-sm font-black text-slate-900 uppercase">SURAT JALAN PEMINJAMAN ALAT</div>
                  <div className="text-xs font-mono font-bold text-slate-700 mt-1">
                    No: {currentLoan.noTransaksi}
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono">
                    Tanggal: {currentLoan.tanggalPinjam}
                  </div>
                </div>
              </div>

              {/* Information Grid */}
              <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-lg border border-slate-200">
                <div className="space-y-1">
                  <div>
                    <span className="text-slate-500">Nama Peminjam:</span>{' '}
                    <strong className="text-slate-900">{currentLoan.namaPeminjam}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500">Penanggung Jawab:</span>{' '}
                    <strong className="text-slate-900">{currentLoan.penanggungJawab}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500">Petugas Pencatat:</span>{' '}
                    <span className="text-slate-800">{currentLoan.dicatatOleh}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <div>
                    <span className="text-slate-500">Keperluan Pembersihan:</span>{' '}
                    <strong className="text-slate-900">{currentLoan.keperluan}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500">Rencana Pengembalian:</span>{' '}
                    <span className="font-mono font-bold text-slate-900">{currentLoan.tanggalRencanaKembali}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">Status Transaksi:</span>{' '}
                    <span className="font-semibold text-emerald-800">{currentLoan.status}</span>
                  </div>
                </div>
              </div>

              {/* Items Table */}
              <div>
                <table className="w-full text-left text-xs border border-slate-300">
                  <thead>
                    <tr className="bg-slate-100 border-b border-slate-300 text-slate-700 font-bold uppercase">
                      <th className="py-2 px-3 border-r border-slate-300 w-12 text-center">No</th>
                      <th className="py-2 px-3 border-r border-slate-300 w-28">Kode Barang</th>
                      <th className="py-2 px-3 border-r border-slate-300">Nama Barang / Mesin</th>
                      <th className="py-2 px-3 border-r border-slate-300 text-right w-24">Jumlah</th>
                      <th className="py-2 px-3 w-20">Satuan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {currentLoan.items.map((it, idx) => (
                      <tr key={idx}>
                        <td className="py-2 px-3 border-r border-slate-300 text-center font-mono">{idx + 1}</td>
                        <td className="py-2 px-3 border-r border-slate-300 font-mono font-bold">{it.kodeBarang}</td>
                        <td className="py-2 px-3 border-r border-slate-300 font-medium">{it.namaBarang}</td>
                        <td className="py-2 px-3 border-r border-slate-300 text-right font-mono font-bold">
                          {it.jumlahPinjam}
                        </td>
                        <td className="py-2 px-3">{it.satuan}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Terms and notes */}
              <div className="p-3 rounded border border-slate-200 bg-slate-50 text-[11px] text-slate-600 space-y-1">
                <span className="font-bold text-slate-800">Ketentuan &amp; Tanggung Jawab:</span>
                <p>
                  1. Peminjam bertanggung jawab penuh atas kebersihan, kelengkapan aksesoris, dan keselamatan alat selama pemakaian.
                </p>
                <p>
                  2. Setiap kerusakan fisik atau kehilangan unit wajib dilaporkan segera saat proses pengembalian kepada Petugas Gudang.
                </p>
              </div>

              {/* 3 Signatures Block */}
              <div className="pt-8 grid grid-cols-3 gap-6 text-center text-xs">
                <div>
                  <div className="text-slate-500 mb-16">Peminjam / Petugas Lapangan,</div>
                  <div className="border-t border-slate-400 pt-1 font-bold text-slate-900">
                    ( {currentLoan.namaPeminjam} )
                  </div>
                </div>

                <div>
                  <div className="text-slate-500 mb-16">Petugas Gudang &amp; Logistik,</div>
                  <div className="border-t border-slate-400 pt-1 font-bold text-slate-900">
                    ( {currentLoan.dicatatOleh || 'Petugas Gudang'} )
                  </div>
                </div>

                <div>
                  <div className="text-slate-500 mb-16">Penanggung Jawab / SPV,</div>
                  <div className="border-t border-slate-400 pt-1 font-bold text-slate-900">
                    ( {currentLoan.penanggungJawab} )
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-400">
              Belum ada data peminjaman yang dipilih.
            </div>
          )}
        </div>

        {/* Modal Footer (hidden in print) */}
        <div className="p-3 border-t border-slate-200 bg-slate-50 flex justify-end gap-2 no-print">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg border border-slate-200 text-slate-700 font-semibold text-xs hover:bg-slate-100"
          >
            Tutup
          </button>
          <button
            onClick={handlePrint}
            disabled={!currentLoan}
            className="px-5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-xs"
          >
            Cetak Surat Jalan
          </button>
        </div>
      </div>
    </div>
  );
};
