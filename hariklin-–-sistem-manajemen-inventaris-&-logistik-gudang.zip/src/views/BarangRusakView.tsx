import React, { useState } from 'react';
import {
  AlertTriangle,
  Wrench,
  ShoppingCart,
  Search,
  FileSpreadsheet,
  Plus,
  X,
} from 'lucide-react';
import { BarangRusak, User, MasterBarang } from '../types';
import { exportToCSV } from '../utils/exportUtils';

interface BarangRusakViewProps {
  barangRusakList: BarangRusak[];
  masterBarang: MasterBarang[];
  onAlihkanKePerbaikan: (
    barangRusakId: string,
    payload: {
      penyebabKerusakan: string;
      keteranganPerbaikan: string;
      estimasiBiaya: number;
      namaPetugas: string;
    }
  ) => void;
  onAlihkanKePembelian: (
    barangRusakId: string,
    payload: {
      alasanPembelian: string;
      estimasiHarga: number;
      namaPengaju: string;
    }
  ) => void;
  onManualReportDamage: (data: {
    kodeBarang: string;
    jumlahRusak: number;
    tanggalKerusakan: string;
    sumberKerusakan: string;
    keterangan: string;
  }) => void;
  currentUser: User;
}

export const BarangRusakView: React.FC<BarangRusakViewProps> = ({
  barangRusakList,
  masterBarang,
  onAlihkanKePerbaikan,
  onAlihkanKePembelian,
  onManualReportDamage,
  currentUser,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('SEMUA');

  // Action Modals State
  const [itemForPerbaikan, setItemForPerbaikan] = useState<BarangRusak | null>(null);
  const [itemForPembelian, setItemForPembelian] = useState<BarangRusak | null>(null);
  const [isManualReportOpen, setIsManualReportOpen] = useState(false);

  // Perbaikan Form Data
  const [perbaikanForm, setPerbaikanForm] = useState({
    penyebabKerusakan: '',
    keteranganPerbaikan: '',
    estimasiBiaya: 0,
    namaPetugas: currentUser.namaLengkap || currentUser.username,
  });

  // Pembelian Form Data
  const [pembelianForm, setPembelianForm] = useState({
    alasanPembelian: '',
    estimasiHarga: 0,
    namaPengaju: currentUser.namaLengkap || currentUser.username,
  });

  // Manual Damage Form Data
  const [manualForm, setManualForm] = useState({
    kodeBarang: '',
    jumlahRusak: 1,
    tanggalKerusakan: new Date().toISOString().split('T')[0],
    sumberKerusakan: 'Inspeksi Rutin Gudang',
    keterangan: '',
  });

  const handleOpenPerbaikanModal = (item: BarangRusak) => {
    setItemForPerbaikan(item);
    setPerbaikanForm({
      penyebabKerusakan: item.keterangan || '',
      keteranganPerbaikan: 'Perlu servis dan penggantian suku cadang',
      estimasiBiaya: 50000,
      namaPetugas: currentUser.namaLengkap || currentUser.username,
    });
  };

  const handleOpenPembelianModal = (item: BarangRusak) => {
    setItemForPembelian(item);
    setPembelianForm({
      alasanPembelian: `Barang rusak tidak ekonomis diperbaiki: ${item.keterangan}`,
      estimasiHarga: 150000,
      namaPengaju: currentUser.namaLengkap || currentUser.username,
    });
  };

  const handleConfirmPerbaikan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemForPerbaikan) return;
    onAlihkanKePerbaikan(itemForPerbaikan.id, perbaikanForm);
    setItemForPerbaikan(null);
  };

  const handleConfirmPembelian = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemForPembelian) return;
    onAlihkanKePembelian(itemForPembelian.id, pembelianForm);
    setItemForPembelian(null);
  };

  const handleConfirmManualDamage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualForm.kodeBarang) {
      alert('Pilih barang terlebih dahulu!');
      return;
    }
    if (manualForm.jumlahRusak <= 0) {
      alert('Jumlah rusak harus lebih dari 0!');
      return;
    }
    onManualReportDamage(manualForm);
    setIsManualReportOpen(false);
    setManualForm({
      kodeBarang: '',
      jumlahRusak: 1,
      tanggalKerusakan: new Date().toISOString().split('T')[0],
      sumberKerusakan: 'Inspeksi Rutin Gudang',
      keterangan: '',
    });
  };

  const filteredList = barangRusakList.filter((it) => {
    const matchSearch =
      it.kodeBarang.toLowerCase().includes(searchTerm.toLowerCase()) ||
      it.namaBarang.toLowerCase().includes(searchTerm.toLowerCase()) ||
      it.keterangan.toLowerCase().includes(searchTerm.toLowerCase()) ||
      it.sumberKerusakan.toLowerCase().includes(searchTerm.toLowerCase());

    const matchStatus =
      filterStatus === 'SEMUA' || it.statusPenanganan === filterStatus;

    return matchSearch && matchStatus;
  });

  const handleExport = () => {
    const exportRows = filteredList.map((b) => ({
      'Kode Barang': b.kodeBarang,
      'Nama Barang': b.namaBarang,
      Satuan: b.satuan,
      'Jumlah Rusak': b.jumlahRusak,
      'Tanggal Kerusakan': b.tanggalKerusakan,
      'Sumber Kerusakan': b.sumberKerusakan,
      Keterangan: b.keterangan,
      'Status Penanganan': b.statusPenanganan,
      'Dicatat Oleh': b.dicatatOleh,
    }));
    exportToCSV('Laporan_Barang_Rusak_Hariklin', exportRows);
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Barang Rusak &amp; Penanganan</h1>
            <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200">
              {barangRusakList.length} Unit Rusak Terdata
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Daftar seluruh unit inventaris yang rusak. Pilih tindakan: <strong>Perbaiki Barang</strong> atau <strong>Beli Baru</strong>.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold border border-slate-200 transition-colors"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => setIsManualReportOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Catat Kerusakan Baru</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari kode barang, nama, sumber..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 text-xs focus:ring-2 focus:ring-rose-500/20"
          />
        </div>

        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-700 bg-white"
        >
          <option value="SEMUA">Semua Status Penanganan</option>
          <option value="Menunggu Keputusan">Menunggu Keputusan</option>
          <option value="Dialihkan ke Perbaikan">Dialihkan ke Perbaikan</option>
          <option value="Dialihkan ke Pembelian">Dialihkan ke Pembelian</option>
          <option value="Selesai Diperbaiki">Selesai Diperbaiki</option>
          <option value="Diganti Baru">Diganti Baru</option>
        </select>
      </div>

      {/* Table Barang Rusak */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                <th className="py-3 px-3">Kode</th>
                <th className="py-3 px-3">Nama Barang</th>
                <th className="py-3 px-3 text-right">Jumlah Rusak</th>
                <th className="py-3 px-3">Tgl Kerusakan</th>
                <th className="py-3 px-3">Sumber Kerusakan</th>
                <th className="py-3 px-3">Keterangan / Kondisi</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-3 text-center">Tindakan Alur</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    Tidak ada barang rusak dengan status yang dipilih.
                  </td>
                </tr>
              ) : (
                filteredList.map((item) => {
                  const canDecide = item.statusPenanganan === 'Menunggu Keputusan';

                  return (
                    <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-3 font-mono font-bold text-slate-900">{item.kodeBarang}</td>
                      <td className="py-3 px-3 font-semibold text-slate-900">{item.namaBarang}</td>
                      <td className="py-3 px-3 text-right font-mono font-bold text-rose-600 tabular-nums">
                        {item.jumlahRusak} {item.satuan}
                      </td>
                      <td className="py-3 px-3 font-mono text-slate-600">{item.tanggalKerusakan}</td>
                      <td className="py-3 px-3 text-slate-600">{item.sumberKerusakan}</td>
                      <td className="py-3 px-3 text-slate-700 max-w-xs">{item.keterangan}</td>
                      <td className="py-3 px-3 text-center">
                        <span
                          className={`text-[11px] px-2 py-0.5 rounded font-semibold ${
                            item.statusPenanganan === 'Menunggu Keputusan'
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : item.statusPenanganan === 'Dialihkan ke Perbaikan'
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : item.statusPenanganan === 'Dialihkan ke Pembelian'
                              ? 'bg-purple-50 text-purple-700 border border-purple-200'
                              : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          }`}
                        >
                          {item.statusPenanganan}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-center">
                        {canDecide ? (
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => handleOpenPerbaikanModal(item)}
                              className="px-2.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-semibold text-[11px] shadow-xs flex items-center gap-1"
                              title="Alihkan ke Perbaikan Barang"
                            >
                              <Wrench className="w-3 h-3" />
                              <span>Perbaiki</span>
                            </button>
                            <button
                              onClick={() => handleOpenPembelianModal(item)}
                              className="px-2.5 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-semibold text-[11px] shadow-xs flex items-center gap-1"
                              title="Alihkan ke Pembelian Barang Baru"
                            >
                              <ShoppingCart className="w-3 h-3" />
                              <span>Beli Baru</span>
                            </button>
                          </div>
                        ) : (
                          <span className="text-slate-400 text-[11px] italic">Sudah Diproses</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL: Alihkan ke Perbaikan */}
      {itemForPerbaikan && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-md overflow-hidden">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-amber-50">
              <div className="flex items-center gap-2">
                <Wrench className="w-4 h-4 text-amber-700" />
                <h3 className="font-bold text-amber-950 text-sm">Alihkan ke Perbaikan Barang</h3>
              </div>
              <button onClick={() => setItemForPerbaikan(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmPerbaikan} className="p-4 space-y-3.5 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="font-semibold text-slate-800">{itemForPerbaikan.namaBarang}</div>
                <div className="text-[11px] text-slate-500">
                  Jumlah: <strong className="text-amber-800">{itemForPerbaikan.jumlahRusak} {itemForPerbaikan.satuan}</strong> &middot; Kode: {itemForPerbaikan.kodeBarang}
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Penyebab Kerusakan</label>
                <input
                  type="text"
                  required
                  value={perbaikanForm.penyebabKerusakan}
                  onChange={(e) => setPerbaikanForm({ ...perbaikanForm, penyebabKerusakan: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Rencana Keterangan Perbaikan</label>
                <textarea
                  rows={2}
                  required
                  value={perbaikanForm.keteranganPerbaikan}
                  onChange={(e) => setPerbaikanForm({ ...perbaikanForm, keteranganPerbaikan: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Estimasi Biaya (Rp)</label>
                  <input
                    type="number"
                    min="0"
                    step="1000"
                    value={perbaikanForm.estimasiBiaya}
                    onChange={(e) => setPerbaikanForm({ ...perbaikanForm, estimasiBiaya: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nama Petugas Penanggung</label>
                  <input
                    type="text"
                    required
                    value={perbaikanForm.namaPetugas}
                    onChange={(e) => setPerbaikanForm({ ...perbaikanForm, namaPetugas: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setItemForPerbaikan(null)}
                  className="px-3.5 py-2 rounded-lg border border-slate-200 text-slate-700 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-semibold shadow-xs"
                >
                  Buat Tiket Perbaikan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Alihkan ke Pembelian */}
      {itemForPembelian && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-md overflow-hidden">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-purple-50">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-4 h-4 text-purple-700" />
                <h3 className="font-bold text-purple-950 text-sm">Alihkan ke Pembelian Barang Baru</h3>
              </div>
              <button onClick={() => setItemForPembelian(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmPembelian} className="p-4 space-y-3.5 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="font-semibold text-slate-800">{itemForPembelian.namaBarang}</div>
                <div className="text-[11px] text-slate-500">
                  Dibutuhkan: <strong className="text-purple-800">{itemForPembelian.jumlahRusak} {itemForPembelian.satuan}</strong> &middot; Kode: {itemForPembelian.kodeBarang}
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Alasan Pembelian / Pergantian Unit</label>
                <textarea
                  rows={2}
                  required
                  value={pembelianForm.alasanPembelian}
                  onChange={(e) => setPembelianForm({ ...pembelianForm, alasanPembelian: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Estimasi Harga Beli (Rp)</label>
                  <input
                    type="number"
                    min="0"
                    step="5000"
                    value={pembelianForm.estimasiHarga}
                    onChange={(e) => setPembelianForm({ ...pembelianForm, estimasiHarga: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nama Pengaju</label>
                  <input
                    type="text"
                    required
                    value={pembelianForm.namaPengaju}
                    onChange={(e) => setPembelianForm({ ...pembelianForm, namaPengaju: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setItemForPembelian(null)}
                  className="px-3.5 py-2 rounded-lg border border-slate-200 text-slate-700 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-semibold shadow-xs"
                >
                  Ajukan Pengadaan Pembelian
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Catat Kerusakan Baru Manual */}
      {isManualReportOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-md overflow-hidden">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-rose-50">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-700" />
                <h3 className="font-bold text-rose-950 text-sm">Catat Kerusakan Barang Fisik</h3>
              </div>
              <button onClick={() => setIsManualReportOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmManualDamage} className="p-4 space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Pilih Barang dari Master *</label>
                <select
                  required
                  value={manualForm.kodeBarang}
                  onChange={(e) => setManualForm({ ...manualForm, kodeBarang: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs bg-white"
                >
                  <option value="">-- Pilih Barang di Master --</option>
                  {masterBarang.map((m) => (
                    <option key={m.kodeBarang} value={m.kodeBarang}>
                      [{m.kodeBarang}] {m.namaBarang} (Stok aktif: {m.stokAktif} {m.satuan})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Jumlah Rusak *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={manualForm.jumlahRusak}
                    onChange={(e) => setManualForm({ ...manualForm, jumlahRusak: Math.max(1, Number(e.target.value)) })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Tanggal Kerusakan</label>
                  <input
                    type="date"
                    required
                    value={manualForm.tanggalKerusakan}
                    onChange={(e) => setManualForm({ ...manualForm, tanggalKerusakan: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Sumber Kerusakan</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Inspeksi Rutin Gudang / Kecelakaan Kerja"
                  value={manualForm.sumberKerusakan}
                  onChange={(e) => setManualForm({ ...manualForm, sumberKerusakan: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Keterangan Detail Kerusakan *</label>
                <textarea
                  rows={2}
                  required
                  placeholder="Deskripsikan bagian yang rusak atau gejalanya..."
                  value={manualForm.keterangan}
                  onChange={(e) => setManualForm({ ...manualForm, keterangan: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsManualReportOpen(false)}
                  className="px-3.5 py-2 rounded-lg border border-slate-200 text-slate-700 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-semibold shadow-xs"
                >
                  Simpan Catatan Kerusakan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
