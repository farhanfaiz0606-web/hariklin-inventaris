import React, { useState, useMemo } from 'react';
import {
  ClipboardCheck,
  Search,
  CheckCircle,
  XCircle,
  ShieldCheck,
  FileSpreadsheet,
  Plus,
  Boxes,
  History,
  CheckSquare,
  Square,
  Layers,
  Save,
  AlertTriangle,
  RotateCcw,
  Check,
  X,
  AlertCircle,
  Info,
} from 'lucide-react';
import { StockOpname, MasterBarang, User } from '../types';
import { exportToCSV } from '../utils/exportUtils';

interface StockOpnameViewProps {
  stockOpnameList: StockOpname[];
  masterBarang: MasterBarang[];
  onCreateOpname: (data: {
    kodeBarang: string;
    stokFisik: number;
    catatan: string;
  }) => void;
  onCreateMultiOpname: (
    items: {
      kodeBarang: string;
      stokFisik: number;
      catatan: string;
    }[]
  ) => void;
  onApproveOpname: (opnameId: string, action: 'SETUJUI' | 'TOLAK') => void;
  onApproveAllOpname: () => void;
  currentUser: User;
}

export const StockOpnameView: React.FC<StockOpnameViewProps> = ({
  stockOpnameList,
  masterBarang,
  onCreateOpname,
  onCreateMultiOpname,
  onApproveOpname,
  onApproveAllOpname,
  currentUser,
}) => {
  // Main view tab: 'LEMBAR_FISIK' (live table of all items with direct physical input) vs 'RIWAYAT_AUDIT'
  const [activeTab, setActiveTab] = useState<'LEMBAR_FISIK' | 'RIWAYAT_AUDIT'>('LEMBAR_FISIK');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('SEMUA');
  const [filterSelisih, setFilterSelisih] = useState<'SEMUA' | 'ADA_SELISIH' | 'SESUAI'>('SEMUA');

  // Inline physical inputs state for row-by-row live audit: { [kodeBarang]: number }
  const [physicalCounts, setPhysicalCounts] = useState<{ [kodeBarang: string]: number }>(() => {
    const initial: { [kodeBarang: string]: number } = {};
    masterBarang.forEach((m) => {
      initial[m.kodeBarang] = m.stokAktif;
    });
    return initial;
  });

  // Inline notes: { [kodeBarang]: string }
  const [auditNotes, setAuditNotes] = useState<{ [kodeBarang: string]: string }>({});

  // Multi-selection for bulk opname
  const [selectedForMulti, setSelectedForMulti] = useState<string[]>([]);
  const [isMultiModalOpen, setIsMultiModalOpen] = useState(false);
  const [batchCatatan, setBatchCatatan] = useState('Audit Rutin Gudang Hariklin');
  const [multiModalError, setMultiModalError] = useState('');

  // Modal Input Barang Fisik Manual (Pengecekan Satuan Langsung)
  const [isManualSingleModalOpen, setIsManualSingleModalOpen] = useState(false);
  const [manualSingleKode, setManualSingleKode] = useState('');
  const [manualSingleFisik, setManualSingleFisik] = useState<number>(0);
  const [manualSingleCatatan, setManualSingleCatatan] = useState('Pengecekan fisik manual gudang');
  const [manualSingleError, setManualSingleError] = useState('');
  const [manualItemSearch, setManualItemSearch] = useState('');

  // Confirmation modal for approving all pending audits (replaces browser confirm)
  const [isConfirmApproveAllOpen, setIsConfirmApproveAllOpen] = useState(false);

  // Toast feedback state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const isAdmin = currentUser.role === 'ADMIN';

  // Categories list
  const categories = useMemo(() => {
    const set = new Set<string>();
    masterBarang.forEach((m) => {
      if (m.kategori) set.add(m.kategori);
    });
    return Array.from(set).sort();
  }, [masterBarang]);

  // Keep physicalCounts updated if master changes
  const getFisikCount = (kode: string, defaultStok: number) => {
    return physicalCounts[kode] !== undefined ? physicalCounts[kode] : defaultStok;
  };

  const handlePhysicalChange = (kode: string, val: number) => {
    setPhysicalCounts((prev) => ({
      ...prev,
      [kode]: Math.max(0, val),
    }));
  };

  const handleNotesChange = (kode: string, note: string) => {
    setAuditNotes((prev) => ({
      ...prev,
      [kode]: note,
    }));
  };

  // Filtered master catalog for the live inspection sheet
  const filteredCatalog = useMemo(() => {
    return masterBarang.filter((item) => {
      const matchSearch =
        item.namaBarang.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.kodeBarang.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (item.lokasiRak && item.lokasiRak.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchCategory =
        selectedCategory === 'SEMUA' || item.kategori === selectedCategory;

      const fisik = getFisikCount(item.kodeBarang, item.stokAktif);
      const selisih = fisik - item.stokAktif;

      let matchSelisih = true;
      if (filterSelisih === 'ADA_SELISIH') {
        matchSelisih = selisih !== 0;
      } else if (filterSelisih === 'SESUAI') {
        matchSelisih = selisih === 0;
      }

      return matchSearch && matchCategory && matchSelisih;
    });
  }, [masterBarang, searchTerm, selectedCategory, filterSelisih, physicalCounts]);

  // Save single row opname
  const handleSaveSingleRow = (item: MasterBarang) => {
    const fisik = getFisikCount(item.kodeBarang, item.stokAktif);
    const note = auditNotes[item.kodeBarang] || (fisik === item.stokAktif ? 'Stok fisik sesuai sistem' : 'Ditemukan selisih fisik');

    onCreateOpname({
      kodeBarang: item.kodeBarang,
      stokFisik: fisik,
      catatan: note,
    });
  };

  // Toggle selection for multi opname
  const handleToggleSelectMulti = (kode: string) => {
    setSelectedForMulti((prev) =>
      prev.includes(kode) ? prev.filter((k) => k !== kode) : [...prev, kode]
    );
  };

  const handleSelectAllFiltered = () => {
    const allFilteredCodes = filteredCatalog.map((m) => m.kodeBarang);
    const allSelected = allFilteredCodes.every((c) => selectedForMulti.includes(c));

    if (allSelected) {
      setSelectedForMulti((prev) => prev.filter((c) => !allFilteredCodes.includes(c)));
    } else {
      setSelectedForMulti((prev) => Array.from(new Set([...prev, ...allFilteredCodes])));
    }
  };

  // Buka Modal Input Barang Fisik Manual
  const handleOpenManualSingleModal = (defaultItem?: MasterBarang) => {
    const item = defaultItem || masterBarang[0];
    if (item) {
      setManualSingleKode(item.kodeBarang);
      setManualSingleFisik(getFisikCount(item.kodeBarang, item.stokAktif));
      setManualSingleCatatan(auditNotes[item.kodeBarang] || 'Cek fisik manual di gudang');
    }
    setManualItemSearch('');
    setManualSingleError('');
    setIsManualSingleModalOpen(true);
  };

  // Submit modal input barang fisik manual
  const handleSubmitManualSingleOpname = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualSingleKode) {
      setManualSingleError('Pilih barang yang diperiksa terlebih dahulu!');
      return;
    }

    const item = masterBarang.find((m) => m.kodeBarang === manualSingleKode);
    if (!item) {
      setManualSingleError('Barang tidak ditemukan dalam Master Barang!');
      return;
    }

    if (manualSingleFisik < 0) {
      setManualSingleError('Jumlah fisik tidak boleh negatif!');
      return;
    }

    onCreateOpname({
      kodeBarang: manualSingleKode,
      stokFisik: manualSingleFisik,
      catatan: manualSingleCatatan.trim() || 'Pengecekan fisik manual gudang',
    });

    // Update local row count as well
    setPhysicalCounts((prev) => ({
      ...prev,
      [manualSingleKode]: manualSingleFisik,
    }));
    if (manualSingleCatatan) {
      setAuditNotes((prev) => ({
        ...prev,
        [manualSingleKode]: manualSingleCatatan,
      }));
    }

    setIsManualSingleModalOpen(false);
    setToastMessage(`Hasil cek fisik ${item.namaBarang} (${item.kodeBarang}) berhasil disimpan & diajukan ke admin.`);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Submit multi opname
  const handleSubmitMultiOpname = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedForMulti.length === 0) {
      setMultiModalError('Pilih minimal 1 barang untuk diaudit secara multi!');
      return;
    }

    const payload = selectedForMulti.map((kode) => {
      const brg = masterBarang.find((m) => m.kodeBarang === kode)!;
      const fisik = getFisikCount(kode, brg?.stokAktif || 0);
      const note = auditNotes[kode] || batchCatatan;
      return {
        kodeBarang: kode,
        stokFisik: fisik,
        catatan: note,
      };
    });

    onCreateMultiOpname(payload);
    setIsMultiModalOpen(false);
    setSelectedForMulti([]);
    setToastMessage(`Berhasil mengajukan ${payload.length} data audit fisik serentak.`);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Filtered history list
  const filteredHistory = stockOpnameList.filter(
    (s) =>
      s.noOpname.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.kodeBarang.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.namaBarang.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.dicatatOleh.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.catatan.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const pendingCount = stockOpnameList.filter(
    (s) => s.statusPenyesuaian === 'Menunggu Persetujuan Admin'
  ).length;

  const handleExportHistory = () => {
    const exportRows = filteredHistory.map((s) => ({
      'No Opname': s.noOpname,
      'Tanggal Opname': s.tanggalOpname,
      'Kode Barang': s.kodeBarang,
      'Nama Barang': s.namaBarang,
      Satuan: s.satuan,
      'Stok Sistem': s.stokSistem,
      'Stok Fisik': s.stokFisik,
      Selisih: s.selisih,
      'Status Penyesuaian': s.statusPenyesuaian,
      'Pemeriksa': s.dicatatOleh,
      'Disetujui Oleh': s.disetujuiOleh || '-',
      Catatan: s.catatan || '-',
    }));
    exportToCSV('Laporan_Stock_Opname_Hariklin', exportRows);
  };

  const handleExportLembarFisik = () => {
    const exportRows = filteredCatalog.map((m) => {
      const fisik = getFisikCount(m.kodeBarang, m.stokAktif);
      const selisih = fisik - m.stokAktif;
      return {
        'Kode Barang': m.kodeBarang,
        'Nama Barang': m.namaBarang,
        Kategori: m.kategori,
        'Lokasi Rak': m.lokasiRak || '-',
        Satuan: m.satuan,
        'Stok Sistem (Aktif)': m.stokAktif,
        'Input Stok Fisik': fisik,
        Selisih: selisih,
        'Status Cek': selisih === 0 ? 'Klop' : selisih < 0 ? 'Kurang' : 'Lebih',
        Catatan: auditNotes[m.kodeBarang] || '-',
      };
    });
    exportToCSV('Lembar_Audit_Fisik_Gudang_Hariklin', exportRows);
  };

  return (
    <div className="space-y-5">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 px-4 py-3 rounded-xl shadow-xs flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="font-medium">{toastMessage}</span>
          </div>
          <button
            onClick={() => setToastMessage(null)}
            className="text-emerald-700 hover:text-emerald-900 p-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Stock Opname &amp; Cek Fisik Gudang</h1>
            <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-purple-50 text-purple-700 border border-purple-200">
              {masterBarang.length} Barang Terdaftar
            </span>
            {pendingCount > 0 && (
              <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">
                {pendingCount} Menunggu ACC Admin
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Lembar cek fisik interaktif gudang. Masukkan jumlah fisik per baris atau gunakan <strong>Opname Manual Multi</strong> untuk input serentak.
          </p>
        </div>

        {/* Tab & Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Subtabs */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
            <button
              onClick={() => setActiveTab('LEMBAR_FISIK')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${
                activeTab === 'LEMBAR_FISIK'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Boxes className="w-3.5 h-3.5" />
              <span>Lembar Data Fisik ({masterBarang.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('RIWAYAT_AUDIT')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${
                activeTab === 'RIWAYAT_AUDIT'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>Riwayat &amp; ACC ({stockOpnameList.length})</span>
            </button>
          </div>

          {/* Tombol Input Barang Fisik Manual */}
          <button
            onClick={() => handleOpenManualSingleModal()}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Input Barang Fisik Manual</span>
          </button>

          {/* Tombol Opname Manual Multi */}
          <button
            onClick={() => {
              if (selectedForMulti.length === 0) {
                // If nothing selected, select currently filtered items
                setSelectedForMulti(filteredCatalog.map((m) => m.kodeBarang));
              }
              setMultiModalError('');
              setIsMultiModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Opname Manual Multi ({selectedForMulti.length > 0 ? selectedForMulti.length : 'Semua'})</span>
          </button>
        </div>
      </div>

      {/* FILTER & CONTROLS */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari kode, nama barang, lokasi rak..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 text-xs focus:ring-2 focus:ring-purple-500/20"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {activeTab === 'LEMBAR_FISIK' && (
            <>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-700 bg-white"
              >
                <option value="SEMUA">Semua Kategori</option>
                {categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>

              <select
                value={filterSelisih}
                onChange={(e) => setFilterSelisih(e.target.value as any)}
                className="px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-700 bg-white"
              >
                <option value="SEMUA">Semua Status Selisih</option>
                <option value="ADA_SELISIH">Ada Selisih (Fisik &ne; Sistem)</option>
                <option value="SESUAI">Sesuai / Klop (Selisih 0)</option>
              </select>

              <button
                onClick={handleExportLembarFisik}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold border border-slate-200"
                title="Export Lembar Cek Fisik ke CSV"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>Export Fisik</span>
              </button>
            </>
          )}

          {activeTab === 'RIWAYAT_AUDIT' && (
            <>
              {isAdmin && pendingCount > 0 && (
                <button
                  onClick={() => setIsConfirmApproveAllOpen(true)}
                  className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shadow-xs"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Setujui Semua Penyesuaian ({pendingCount})</span>
                </button>
              )}

              <button
                onClick={handleExportHistory}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold border border-slate-200"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>Export Riwayat</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* TAB 1: LEMBAR CEK FISIK INTERAKTIF BARANG GUDANG (TABEL DATA BARANG + KOLOM INPUT FISIK) */}
      {activeTab === 'LEMBAR_FISIK' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-3 border-b border-slate-200 bg-slate-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-3">
              <button
                onClick={handleSelectAllFiltered}
                className="flex items-center gap-1.5 font-semibold text-slate-700 hover:text-purple-700"
              >
                {filteredCatalog.length > 0 &&
                filteredCatalog.every((m) => selectedForMulti.includes(m.kodeBarang)) ? (
                  <CheckSquare className="w-4 h-4 text-purple-600" />
                ) : (
                  <Square className="w-4 h-4 text-slate-400" />
                )}
                <span>Pilih Semua di Tampilan ({filteredCatalog.length})</span>
              </button>
              <span className="text-slate-400">|</span>
              <span className="text-slate-500">
                Terpilih untuk Multi-Opname:{' '}
                <strong className="text-purple-700">{selectedForMulti.length} item</strong>
              </span>
            </div>

            <div className="text-[11px] text-slate-500">
              Isi angka pada kolom <strong>Jumlah Fisik</strong> &rarr; Selisih otomatis terhitung live
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                  <th className="py-3 px-3 w-10 text-center">Pilih</th>
                  <th className="py-3 px-3 w-28">Kode Barang</th>
                  <th className="py-3 px-3">Nama Barang / Mesin</th>
                  <th className="py-3 px-3">Kategori</th>
                  <th className="py-3 px-3">Lokasi Rak</th>
                  <th className="py-3 px-3 text-right">Stok Sistem</th>
                  <th className="py-3 px-3 text-center w-36 bg-purple-50/70 border-x border-purple-200 text-purple-950 font-bold">
                    Kolom Isi Fisik
                  </th>
                  <th className="py-3 px-3 text-right w-24">Selisih</th>
                  <th className="py-3 px-3 w-48">Catatan Audit</th>
                  <th className="py-3 px-3 text-center w-28">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredCatalog.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="py-8 text-center text-slate-400">
                      Tidak ada barang inventaris yang cocok dengan kriteria pencarian.
                    </td>
                  </tr>
                ) : (
                  filteredCatalog.map((item) => {
                    const isSelected = selectedForMulti.includes(item.kodeBarang);
                    const fisik = getFisikCount(item.kodeBarang, item.stokAktif);
                    const selisih = fisik - item.stokAktif;
                    const note = auditNotes[item.kodeBarang] || '';

                    return (
                      <tr
                        key={item.kodeBarang}
                        className={`hover:bg-slate-50/90 transition-colors ${
                          isSelected ? 'bg-purple-50/30' : ''
                        }`}
                      >
                        <td className="py-2.5 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => handleToggleSelectMulti(item.kodeBarang)}
                            className="text-slate-400 hover:text-purple-600"
                          >
                            {isSelected ? (
                              <CheckSquare className="w-4 h-4 text-purple-600" />
                            ) : (
                              <Square className="w-4 h-4 text-slate-300" />
                            )}
                          </button>
                        </td>

                        <td className="py-2.5 px-3 font-mono font-bold text-slate-900">{item.kodeBarang}</td>
                        <td className="py-2.5 px-3 font-semibold text-slate-900">
                          <div>{item.namaBarang}</div>
                          {item.keterangan && (
                            <div className="text-[10px] text-slate-400 truncate max-w-[200px]">
                              {item.keterangan}
                            </div>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-slate-600">{item.kategori}</td>
                        <td className="py-2.5 px-3 text-slate-500 font-mono text-[11px]">{item.lokasiRak || '-'}</td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-700 tabular-nums">
                          {item.stokAktif} <span className="text-[10px] text-slate-400 font-normal">{item.satuan}</span>
                        </td>

                        {/* KOLOM INTERAKTIF: ISI JUMLAH FISIK */}
                        <td className="py-2 px-3 bg-purple-50/40 border-x border-purple-200 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <input
                              type="number"
                              min="0"
                              step="any"
                              value={fisik}
                              onChange={(e) =>
                                handlePhysicalChange(item.kodeBarang, Number(e.target.value))
                              }
                              className="w-20 px-2 py-1 rounded border border-purple-300 bg-white font-mono text-xs font-bold text-slate-900 text-center focus:ring-2 focus:ring-purple-500/30 shadow-2xs"
                            />
                            <span className="text-[10px] text-slate-500 font-medium">{item.satuan}</span>
                          </div>
                        </td>

                        {/* LIVE SELISIH */}
                        <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[11px] inline-block ${
                              selisih === 0
                                ? 'text-emerald-700 bg-emerald-50'
                                : selisih < 0
                                ? 'text-rose-700 bg-rose-50 font-bold'
                                : 'text-blue-700 bg-blue-50 font-bold'
                            }`}
                          >
                            {selisih > 0 ? `+${selisih}` : selisih}
                          </span>
                        </td>

                        {/* INPUT CATATAN BARIS */}
                        <td className="py-2 px-3">
                          <input
                            type="text"
                            placeholder={selisih === 0 ? 'Klop' : 'Alasan selisih...'}
                            value={note}
                            onChange={(e) => handleNotesChange(item.kodeBarang, e.target.value)}
                            className="w-full px-2 py-1 rounded border border-slate-200 text-xs bg-white"
                          />
                        </td>

                        {/* TOMBOL SIMPAN ROW */}
                        <td className="py-2.5 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => handleSaveSingleRow(item)}
                            className="px-2.5 py-1 rounded-md bg-slate-900 hover:bg-slate-800 text-white font-semibold text-[11px] shadow-2xs transition-colors flex items-center justify-center gap-1 mx-auto"
                            title="Simpan audit untuk barang ini"
                          >
                            <Save className="w-3 h-3" />
                            <span>Simpan</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: RIWAYAT & PERSETUJUAN ADMIN */}
      {activeTab === 'RIWAYAT_AUDIT' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                  <th className="py-3 px-3">No Opname</th>
                  <th className="py-3 px-3">Nama Barang</th>
                  <th className="py-3 px-3 text-right">Stok Sistem</th>
                  <th className="py-3 px-3 text-right">Stok Fisik</th>
                  <th className="py-3 px-3 text-right">Selisih</th>
                  <th className="py-3 px-3">Tgl Periksa</th>
                  <th className="py-3 px-3">Pemeriksa &amp; Catatan</th>
                  <th className="py-3 px-3 text-center">Status</th>
                  <th className="py-3 px-3 text-center">Persetujuan Admin</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredHistory.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-8 text-center text-slate-400">
                      Belum ada riwayat stock opname yang tersimpan.
                    </td>
                  </tr>
                ) : (
                  filteredHistory.map((opname) => {
                    const isPending = opname.statusPenyesuaian === 'Menunggu Persetujuan Admin';
                    const isApproved = opname.statusPenyesuaian === 'Disetujui & Disesuaikan';

                    return (
                      <tr key={opname.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-3 font-mono font-bold text-purple-900">{opname.noOpname}</td>
                        <td className="py-3 px-3 font-semibold text-slate-900">
                          <div>{opname.namaBarang}</div>
                          <div className="text-[10px] text-slate-400 font-mono">{opname.kodeBarang}</div>
                        </td>
                        <td className="py-3 px-3 text-right font-mono text-slate-600 tabular-nums">
                          {opname.stokSistem} {opname.satuan}
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 tabular-nums">
                          {opname.stokFisik} {opname.satuan}
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-bold tabular-nums">
                          <span
                            className={
                              opname.selisih === 0
                                ? 'text-emerald-700'
                                : opname.selisih < 0
                                ? 'text-rose-600'
                                : 'text-blue-600'
                            }
                          >
                            {opname.selisih > 0 ? `+${opname.selisih}` : opname.selisih} {opname.satuan}
                          </span>
                        </td>
                        <td className="py-3 px-3 font-mono text-slate-600">{opname.tanggalOpname}</td>
                        <td className="py-3 px-3 text-slate-700 max-w-xs">
                          <div>Oleh: {opname.dicatatOleh}</div>
                          {opname.catatan && (
                            <div className="text-[11px] text-slate-500 italic mt-0.5">{opname.catatan}</div>
                          )}
                        </td>
                        <td className="py-3 px-3 text-center">
                          <span
                            className={`text-[11px] px-2 py-0.5 rounded font-semibold inline-block ${
                              opname.statusPenyesuaian === 'Disetujui & Disesuaikan'
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : opname.statusPenyesuaian === 'Menunggu Persetujuan Admin'
                                ? 'bg-amber-50 text-amber-700 border border-amber-200'
                                : 'bg-rose-50 text-rose-700 border border-rose-200'
                            }`}
                          >
                            {opname.statusPenyesuaian}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-center">
                          {isPending && isAdmin ? (
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                onClick={() => onApproveOpname(opname.id, 'SETUJUI')}
                                className="px-2.5 py-1 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-[10px] shadow-xs flex items-center gap-1"
                                title="Setujui dan sesuaikan saldo stok Master Barang"
                              >
                                <CheckCircle className="w-3 h-3" />
                                <span>ACC Sesuaikan</span>
                              </button>
                              <button
                                onClick={() => onApproveOpname(opname.id, 'TOLAK')}
                                className="px-2 py-1 rounded-md bg-rose-600 hover:bg-rose-500 text-white font-semibold text-[10px]"
                                title="Tolak penyesuaian"
                              >
                                <XCircle className="w-3 h-3" />
                                <span>Tolak</span>
                              </button>
                            </div>
                          ) : isPending && !isAdmin ? (
                            <span className="text-amber-700 text-[11px] font-medium">Menunggu ACC Admin</span>
                          ) : isApproved ? (
                            <span className="text-emerald-700 text-[11px] font-semibold flex items-center justify-center gap-1">
                              <CheckCircle className="w-3.5 h-3.5" />
                              Stok Diselaraskan
                            </span>
                          ) : (
                            <span className="text-rose-600 text-[11px] italic">Penyesuaian Ditolak</span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL 1: INPUT BARANG FISIK MANUAL (PENGECEKAN TUNGGAL DETAIL) */}
      {isManualSingleModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-xl max-h-[92vh] overflow-hidden flex flex-col">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-emerald-50">
              <div className="flex items-center gap-2">
                <Plus className="w-4 h-4 text-emerald-700" />
                <h3 className="font-bold text-emerald-950 text-sm">
                  Input Cek Fisik Barang Manual
                </h3>
              </div>
              <button
                onClick={() => setIsManualSingleModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitManualSingleOpname} className="flex-1 flex flex-col overflow-y-auto p-5 space-y-4 text-xs">
              {manualSingleError && (
                <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{manualSingleError}</span>
                </div>
              )}

              {/* Pilih Barang */}
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Pilih Barang dari Master Barang:
                </label>
                <div className="space-y-2">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Ketik untuk filter nama / kode barang..."
                      value={manualItemSearch}
                      onChange={(e) => setManualItemSearch(e.target.value)}
                      className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-slate-200 text-xs bg-slate-50 focus:bg-white"
                    />
                  </div>

                  <select
                    value={manualSingleKode}
                    onChange={(e) => {
                      const kode = e.target.value;
                      setManualSingleKode(kode);
                      const brg = masterBarang.find((m) => m.kodeBarang === kode);
                      if (brg) {
                        setManualSingleFisik(getFisikCount(kode, brg.stokAktif));
                        setManualSingleCatatan(auditNotes[kode] || 'Cek fisik manual gudang');
                      }
                      setManualSingleError('');
                    }}
                    required
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-medium text-slate-800 bg-white"
                  >
                    {masterBarang
                      .filter((m) =>
                        manualItemSearch
                          ? m.namaBarang.toLowerCase().includes(manualItemSearch.toLowerCase()) ||
                            m.kodeBarang.toLowerCase().includes(manualItemSearch.toLowerCase())
                          : true
                      )
                      .map((m) => (
                        <option key={m.kodeBarang} value={m.kodeBarang}>
                          [{m.kodeBarang}] {m.namaBarang} (Stok Sistem: {m.stokAktif} {m.satuan})
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              {/* Kartu Detail Barang Terpilih */}
              {(() => {
                const item = masterBarang.find((m) => m.kodeBarang === manualSingleKode);
                if (!item) return null;
                const selisih = manualSingleFisik - item.stokAktif;

                return (
                  <div className="space-y-4">
                    <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-mono font-bold text-xs text-purple-700 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                          {item.kodeBarang}
                        </span>
                        <span className="text-[11px] text-slate-500 font-mono">
                          Lokasi Rak: {item.lokasiRak || 'Gudang Utama'}
                        </span>
                      </div>
                      <div className="font-bold text-slate-900 text-sm">{item.namaBarang}</div>
                      <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-3">
                        <span>Kategori: <strong>{item.kategori}</strong></span>
                        <span>Satuan: <strong>{item.satuan}</strong></span>
                      </div>
                    </div>

                    {/* Input Jumlah Stok Fisik Riil */}
                    <div className="bg-emerald-50/60 p-4 rounded-xl border border-emerald-200 space-y-3">
                      <label className="block text-emerald-950 font-bold text-xs">
                        Jumlah Stok Fisik Riil di Lokasi Gudang:
                      </label>

                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          min="0"
                          step="any"
                          required
                          value={manualSingleFisik}
                          onChange={(e) => {
                            setManualSingleFisik(Math.max(0, Number(e.target.value)));
                            setManualSingleError('');
                          }}
                          className="flex-1 px-3 py-2 rounded-lg border border-emerald-400 text-base font-mono font-bold text-slate-900 bg-white text-center focus:ring-2 focus:ring-emerald-500/20 shadow-2xs"
                        />
                        <span className="font-semibold text-slate-700 text-xs px-2 py-1 bg-white border border-slate-200 rounded-lg">
                          {item.satuan}
                        </span>
                      </div>

                      {/* Tombol Step Cepat */}
                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                        <button
                          type="button"
                          onClick={() => setManualSingleFisik((prev) => Math.max(0, prev - 5))}
                          className="px-2 py-1 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-[11px] font-mono font-semibold"
                        >
                          -5
                        </button>
                        <button
                          type="button"
                          onClick={() => setManualSingleFisik((prev) => Math.max(0, prev - 1))}
                          className="px-2 py-1 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-[11px] font-mono font-semibold"
                        >
                          -1
                        </button>
                        <button
                          type="button"
                          onClick={() => setManualSingleFisik(item.stokAktif)}
                          className="px-2.5 py-1 rounded bg-white hover:bg-slate-100 border border-emerald-300 text-emerald-700 text-[11px] font-semibold"
                        >
                          Samakan Sistem ({item.stokAktif})
                        </button>
                        <button
                          type="button"
                          onClick={() => setManualSingleFisik((prev) => prev + 1)}
                          className="px-2 py-1 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-[11px] font-mono font-semibold"
                        >
                          +1
                        </button>
                        <button
                          type="button"
                          onClick={() => setManualSingleFisik((prev) => prev + 5)}
                          className="px-2 py-1 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-[11px] font-mono font-semibold"
                        >
                          +5
                        </button>
                      </div>

                      {/* Perbandingan & Analisa Selisih */}
                      <div className="p-3 rounded-lg bg-white border border-slate-200 space-y-1.5 mt-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-500">Stok Sistem Saat Ini:</span>
                          <span className="font-mono font-bold text-slate-700">
                            {item.stokAktif} {item.satuan}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-500">Hasil Cek Fisik Riil:</span>
                          <span className="font-mono font-bold text-slate-900">
                            {manualSingleFisik} {item.satuan}
                          </span>
                        </div>
                        <div className="pt-1.5 border-t border-slate-100 flex items-center justify-between text-xs">
                          <span className="font-semibold text-slate-700">Status Selisih:</span>
                          <span
                            className={`font-mono font-bold px-2 py-0.5 rounded text-xs ${
                              selisih === 0
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : selisih < 0
                                ? 'bg-rose-50 text-rose-700 border border-rose-200'
                                : 'bg-blue-50 text-blue-700 border border-blue-200'
                            }`}
                          >
                            {selisih === 0
                              ? 'Klop / Sesuai (0)'
                              : selisih < 0
                              ? `Selisih Kurang (${selisih} ${item.satuan})`
                              : `Selisih Lebih (+${selisih} ${item.satuan})`}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Catatan & Rekomendasi Cepat */}
                    <div className="space-y-1.5">
                      <label className="block text-slate-700 font-semibold">
                        Catatan Temuan / Kondisi Fisik Lapangan:
                      </label>
                      <div className="flex flex-wrap gap-1 mb-1">
                        {[
                          'Fisik lengkap & kondisi baik',
                          'Ditemukan selisih fisik di rak',
                          'Barang tercecer di area packing',
                          'Fisik berdebu tapi siap pakai',
                        ].map((chip) => (
                          <button
                            key={chip}
                            type="button"
                            onClick={() => setManualSingleCatatan(chip)}
                            className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px]"
                          >
                            + {chip}
                          </button>
                        ))}
                      </div>
                      <input
                        type="text"
                        value={manualSingleCatatan}
                        onChange={(e) => setManualSingleCatatan(e.target.value)}
                        placeholder="Tuliskan keterangan detail hasil pengecekan..."
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs bg-white"
                      />
                    </div>

                    <div className="text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-lg border border-slate-200 flex items-center justify-between">
                      <span>Pemeriksa: <strong>{currentUser.namaLengkap}</strong> ({currentUser.role})</span>
                      <span>Tanggal: <strong>{new Date().toISOString().split('T')[0]}</strong></span>
                    </div>
                  </div>
                );
              })()}

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsManualSingleModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 font-semibold hover:bg-slate-100 text-xs"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-xs flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Simpan &amp; Ajukan Cek Fisik</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: OPNAME MANUAL MULTI (BULK AUDIT MODAL) */}
      {isMultiModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-3xl max-h-[92vh] overflow-hidden flex flex-col">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-purple-50">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-purple-700" />
                <h3 className="font-bold text-purple-950 text-sm">
                  Opname Manual Multi – Audit Serentak ({selectedForMulti.length} Barang Dipilih)
                </h3>
              </div>
              <button
                onClick={() => setIsMultiModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitMultiOpname} className="flex-1 flex flex-col overflow-hidden">
              <div className="p-4 border-b border-slate-200 bg-slate-50 space-y-2">
                {multiModalError && (
                  <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
                    <AlertCircle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                    <span>{multiModalError}</span>
                  </div>
                )}
                <label className="block text-slate-700 font-semibold text-xs">
                  Catatan Batch Audit Serentak:
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Audit Fisik Mingguan Rak A &amp; B / Stock Opname Akhir Bulan"
                  value={batchCatatan}
                  onChange={(e) => setBatchCatatan(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
                />
              </div>

              {/* Items in Multi Opname */}
              <div className="p-4 overflow-y-auto flex-1 space-y-2.5 text-xs">
                {selectedForMulti.map((kode) => {
                  const brg = masterBarang.find((m) => m.kodeBarang === kode);
                  if (!brg) return null;
                  const fisik = getFisikCount(kode, brg.stokAktif);
                  const selisih = fisik - brg.stokAktif;

                  return (
                    <div
                      key={kode}
                      className="p-3 rounded-lg border border-slate-200 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-slate-900">[{brg.kodeBarang}]</span>
                          <span className="font-semibold text-slate-900">{brg.namaBarang}</span>
                          <span className="text-[11px] text-slate-400">({brg.kategori})</span>
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          Stok Sistem: <strong className="text-slate-700">{brg.stokAktif} {brg.satuan}</strong> &middot; Lokasi: {brg.lokasiRak || '-'}
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[11px] text-slate-600 font-semibold">Fisik:</span>
                          <input
                            type="number"
                            min="0"
                            step="any"
                            value={fisik}
                            onChange={(e) => handlePhysicalChange(kode, Number(e.target.value))}
                            className="w-20 px-2 py-1 rounded border border-purple-300 text-center font-mono font-bold text-xs"
                          />
                          <span className="text-[11px] text-slate-500">{brg.satuan}</span>
                        </div>

                        <div className="w-20 text-right font-mono font-bold">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[11px] ${
                              selisih === 0
                                ? 'text-emerald-700 bg-emerald-50'
                                : selisih < 0
                                ? 'text-rose-700 bg-rose-50'
                                : 'text-blue-700 bg-blue-50'
                            }`}
                          >
                            {selisih > 0 ? `+${selisih}` : selisih}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Modal Footer */}
              <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs">
                <div className="text-slate-500">
                  Total diaudit: <strong className="text-slate-800">{selectedForMulti.length} jenis barang</strong>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsMultiModalOpen(false)}
                    className="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 font-semibold hover:bg-slate-100"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-semibold shadow-xs"
                  >
                    Simpan &amp; Ajukan Opname Multi ({selectedForMulti.length})
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: KONFIRMASI SETUJUI SEMUA PENYESUAIAN */}
      {isConfirmApproveAllOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-md p-5 space-y-4">
            <div className="flex items-center gap-2.5 text-emerald-700">
              <ShieldCheck className="w-5 h-5 shrink-0" />
              <h3 className="font-bold text-slate-900 text-sm">
                Setujui Semua Penyesuaian Stok
              </h3>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Yakin ingin menyetujui sekaligus <strong>{pendingCount} hasil pemeriksaan</strong> stock opname yang tertunda?
              Saldo stok aktif di Master Barang akan otomatis diselaraskan dengan hasil cek fisik di gudang.
            </p>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsConfirmApproveAllOpen(false)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 font-semibold hover:bg-slate-100 text-xs"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  onApproveAllOpname();
                  setIsConfirmApproveAllOpen(false);
                  setToastMessage(`Berhasil menyetujui & menyelaraskan ${pendingCount} penyesuaian stok.`);
                  setTimeout(() => setToastMessage(null), 4000);
                }}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-xs"
              >
                Ya, Setujui &amp; Selaraskan
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
