import React, { useState } from 'react';
import {
  PackagePlus,
  Search,
  Upload,
  FileSpreadsheet,
  Image as ImageIcon,
  CheckCircle,
  Plus,
} from 'lucide-react';
import { MasterBarang, BarangMasuk, User } from '../types';
import { exportToCSV } from '../utils/exportUtils';

interface BarangMasukViewProps {
  masterBarang: MasterBarang[];
  barangMasukList: BarangMasuk[];
  onProcessBarangMasuk: (data: {
    kodeBarang?: string;
    namaBarang: string;
    kategori: string;
    satuan: string;
    jumlahMasuk: number;
    tanggalMasuk: string;
    sumberBarang: string;
    penanggungJawab: string;
    keterangan: string;
    notaFotoUrl?: string;
  }) => void;
  currentUser: User;
}

export const BarangMasukView: React.FC<BarangMasukViewProps> = ({
  masterBarang,
  barangMasukList,
  onProcessBarangMasuk,
  currentUser,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);

  // Form mode: 'PILIH_MASTER' or 'BARANG_BARU'
  const [inputMode, setInputMode] = useState<'PILIH_MASTER' | 'BARANG_BARU'>('PILIH_MASTER');

  // Form Fields
  const [selectedKodeBarang, setSelectedKodeBarang] = useState('');
  const [namaBarang, setNamaBarang] = useState('');
  const [kategori, setKategori] = useState('Alat Kebersihan & Sanitasi');
  const [satuan, setSatuan] = useState('Pcs');
  const [jumlahMasuk, setJumlahMasuk] = useState<number>(1);
  const [tanggalMasuk, setTanggalMasuk] = useState(new Date().toISOString().split('T')[0]);
  const [sumberBarang, setSumberBarang] = useState('');
  const [penanggungJawab, setPenanggungJawab] = useState(currentUser.namaLengkap || currentUser.username);
  const [keterangan, setKeterangan] = useState('');
  const [notaPreview, setNotaPreview] = useState<string | null>(null);

  // When selecting existing master item
  const handleSelectMasterItem = (kode: string) => {
    setSelectedKodeBarang(kode);
    const brg = masterBarang.find((m) => m.kodeBarang === kode);
    if (brg) {
      setNamaBarang(brg.namaBarang);
      setKategori(brg.kategori);
      setSatuan(brg.satuan);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNotaPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!namaBarang.trim()) {
      alert('Nama barang wajib diisi!');
      return;
    }
    if (jumlahMasuk <= 0) {
      alert('Jumlah masuk harus lebih dari 0!');
      return;
    }
    if (!sumberBarang.trim()) {
      alert('Sumber / supplier barang wajib diisi!');
      return;
    }

    onProcessBarangMasuk({
      kodeBarang: inputMode === 'PILIH_MASTER' ? selectedKodeBarang : undefined,
      namaBarang: namaBarang.trim(),
      kategori,
      satuan,
      jumlahMasuk: Number(jumlahMasuk),
      tanggalMasuk,
      sumberBarang: sumberBarang.trim(),
      penanggungJawab: penanggungJawab.trim(),
      keterangan: keterangan.trim(),
      notaFotoUrl: notaPreview || undefined,
    });

    // Reset Form
    setSelectedKodeBarang('');
    setNamaBarang('');
    setJumlahMasuk(1);
    setSumberBarang('');
    setKeterangan('');
    setNotaPreview(null);
    setIsFormOpen(false);
  };

  const filteredHistory = barangMasukList.filter(
    (b) =>
      b.noTransaksiMasuk.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.kodeBarang.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.namaBarang.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.sumberBarang.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.penanggungJawab.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleExport = () => {
    const exportRows = barangMasukList.map((b) => ({
      'No Transaksi': b.noTransaksiMasuk,
      'Kode Barang': b.kodeBarang,
      'Nama Barang': b.namaBarang,
      Kategori: b.kategori,
      Satuan: b.satuan,
      'Jumlah Masuk': b.jumlahMasuk,
      'Tanggal Masuk': b.tanggalMasuk,
      'Sumber / Vendor': b.sumberBarang,
      'Penanggung Jawab': b.penanggungJawab,
      'Dicatat Oleh': b.dicatatOleh,
      Keterangan: b.keterangan || '-',
    }));
    exportToCSV('Laporan_Barang_Masuk_Hariklin', exportRows);
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Barang Masuk (Penerimaan Gudang)</h1>
            <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-teal-50 text-teal-700 border border-teal-200">
              {barangMasukList.length} Transaksi Masuk
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Penerimaan barang dari vendor / restock. Stok aktif otomatis bertambah atau otomatis dibuatkan di Master Barang.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold border border-slate-200 transition-colors"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => setIsFormOpen(!isFormOpen)}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{isFormOpen ? 'Tutup Formulir' : 'Input Barang Masuk'}</span>
          </button>
        </div>
      </div>

      {/* FORMULIR BARANG MASUK */}
      {isFormOpen && (
        <div className="bg-white rounded-xl border border-teal-300 p-5 shadow-md animate-in fade-in duration-200">
          <div className="pb-3 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <PackagePlus className="w-4 h-4 text-teal-600" />
                <span>Formulir Penerimaan Barang Masuk</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Pilih apakah barang sudah ada di Master Barang atau barang baru pertama kali masuk
              </p>
            </div>

            {/* Mode switch */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
              <button
                type="button"
                onClick={() => setInputMode('PILIH_MASTER')}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${
                  inputMode === 'PILIH_MASTER'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Pilih dari Master
              </button>
              <button
                type="button"
                onClick={() => {
                  setInputMode('BARANG_BARU');
                  setSelectedKodeBarang('');
                  setNamaBarang('');
                }}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${
                  inputMode === 'BARANG_BARU'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                + Input Barang Baru
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-xs">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
              {inputMode === 'PILIH_MASTER' ? (
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Pilih Barang di Master *
                  </label>
                  <select
                    required
                    value={selectedKodeBarang}
                    onChange={(e) => handleSelectMasterItem(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs bg-white focus:ring-2 focus:ring-teal-500/20"
                  >
                    <option value="">-- Pilih Barang dari Master --</option>
                    {masterBarang.map((m) => (
                      <option key={m.kodeBarang} value={m.kodeBarang}>
                        [{m.kodeBarang}] {m.namaBarang} (Stok saat ini: {m.stokAktif} {m.satuan})
                      </option>
                    ))}
                  </select>
                </div>
              ) : (
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Nama Barang Baru *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Mesin Jet Cleaner 120 Bar"
                    value={namaBarang}
                    onChange={(e) => setNamaBarang(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-teal-500/20"
                  />
                </div>
              )}

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Kategori</label>
                <input
                  type="text"
                  list="cat-masuk-list"
                  required
                  value={kategori}
                  onChange={(e) => setKategori(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-teal-500/20"
                />
                <datalist id="cat-masuk-list">
                  <option value="Mesin & Peralatan Elektrik" />
                  <option value="Alat Kebersihan & Sanitasi" />
                  <option value="Perlengkapan Pest Control" />
                  <option value="Bahan Pembersih & Kimia" />
                  <option value="Perkakas & Alat Pertukangan" />
                  <option value="APD & Perlengkapan Kerja" />
                  <option value="Sarana & Inventaris Kantor" />
                </datalist>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Jumlah Masuk *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={jumlahMasuk}
                    onChange={(e) => setJumlahMasuk(Math.max(1, Number(e.target.value)))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs font-bold text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Satuan</label>
                  <input
                    type="text"
                    required
                    placeholder="Pcs / Unit"
                    value={satuan}
                    onChange={(e) => setSatuan(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Sumber Barang / Vendor *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: PT. Karcher Indonesia / Ace Hardware"
                  value={sumberBarang}
                  onChange={(e) => setSumberBarang(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-teal-500/20"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Penanggung Jawab Penerima</label>
                <input
                  type="text"
                  required
                  value={penanggungJawab}
                  onChange={(e) => setPenanggungJawab(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Tanggal Masuk</label>
                <input
                  type="date"
                  required
                  value={tanggalMasuk}
                  onChange={(e) => setTanggalMasuk(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                />
              </div>
            </div>

            {/* Upload Foto Nota / Surat Jalan Fisik */}
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
              <label className="block text-slate-700 font-semibold mb-1.5">
                Foto Nota / Invoice / Surat Jalan Fisik (Opsional)
              </label>
              <div className="flex flex-col sm:flex-row items-center gap-4">
                <label className="flex items-center gap-2 px-3 py-2 bg-white rounded-lg border border-slate-300 hover:border-slate-400 cursor-pointer text-slate-700 text-xs font-medium">
                  <Upload className="w-4 h-4 text-slate-500" />
                  <span>Unggah Foto Nota / Dokumen</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="sr-only"
                  />
                </label>
                {notaPreview && (
                  <div className="flex items-center gap-2">
                    <img
                      src={notaPreview}
                      alt="Preview Nota"
                      className="w-12 h-12 object-cover rounded-md border border-slate-300"
                    />
                    <span className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5" />
                      Foto nota terlampir
                    </span>
                    <button
                      type="button"
                      onClick={() => setNotaPreview(null)}
                      className="text-[11px] text-rose-600 hover:underline"
                    >
                      Hapus
                    </button>
                  </div>
                )}
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Keterangan Tambahan</label>
              <textarea
                rows={2}
                placeholder="Catatan nomor invoice, nomor PO, atau kondisi paket saat diterima..."
                value={keterangan}
                onChange={(e) => setKeterangan(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-teal-500/20"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setIsFormOpen(false)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 font-semibold hover:bg-slate-50"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-semibold shadow-xs"
              >
                Simpan Penerimaan &amp; Tambahkan Stok
              </button>
            </div>
          </form>
        </div>
      )}

      {/* RIWAYAT BARANG MASUK */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari transaksi, kode barang, vendor..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 text-xs focus:ring-2 focus:ring-teal-500/20"
            />
          </div>

          <div className="text-xs text-slate-500">
            Menampilkan <strong className="text-slate-800">{filteredHistory.length}</strong> transaksi barang masuk
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                <th className="py-3 px-3">No Penerimaan</th>
                <th className="py-3 px-3">Kode Barang</th>
                <th className="py-3 px-3">Nama Barang</th>
                <th className="py-3 px-3">Kategori</th>
                <th className="py-3 px-3 text-right">Jumlah Masuk</th>
                <th className="py-3 px-3">Sumber / Vendor</th>
                <th className="py-3 px-3">Tgl Masuk</th>
                <th className="py-3 px-3">PJ &amp; Penerima</th>
                <th className="py-3 px-3 text-center">Nota</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredHistory.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-400">
                    Belum ada catatan barang masuk.
                  </td>
                </tr>
              ) : (
                filteredHistory.map((b) => (
                  <tr key={b.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-3 font-mono font-bold text-teal-800">{b.noTransaksiMasuk}</td>
                    <td className="py-3 px-3 font-mono font-semibold text-slate-800">{b.kodeBarang}</td>
                    <td className="py-3 px-3 font-medium text-slate-900">{b.namaBarang}</td>
                    <td className="py-3 px-3 text-slate-600">{b.kategori}</td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-teal-700 tabular-nums">
                      +{b.jumlahMasuk} {b.satuan}
                    </td>
                    <td className="py-3 px-3 text-slate-800">{b.sumberBarang}</td>
                    <td className="py-3 px-3 font-mono text-slate-600">{b.tanggalMasuk}</td>
                    <td className="py-3 px-3 text-slate-600">
                      <div>{b.penanggungJawab}</div>
                      <div className="text-[10px] text-slate-400">Oleh: {b.dicatatOleh}</div>
                    </td>
                    <td className="py-3 px-3 text-center">
                      {b.notaFotoUrl ? (
                        <a
                          href={b.notaFotoUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1 text-[11px] font-semibold text-teal-600 hover:text-teal-700"
                        >
                          <ImageIcon className="w-3.5 h-3.5" />
                          <span>Lihat</span>
                        </a>
                      ) : (
                        <span className="text-slate-400">-</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
