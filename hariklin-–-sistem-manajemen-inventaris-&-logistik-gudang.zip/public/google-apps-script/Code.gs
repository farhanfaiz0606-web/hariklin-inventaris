/**
 * ============================================================================
 * HARIKLIN – SISTEM MANAJEMEN INVENTARIS & LOGISTIK GUDANG
 * Backend Google Apps Script (Code.gs)
 * 
 * STRUKTUR 12 SHEET DATABASE:
 * 1. masterBarang
 * 2. barangMasuk
 * 3. peminjaman
 * 4. pengembalian
 * 5. stockOpname
 * 6. rekapTransaksi
 * 7. barangRusak
 * 8. perbaikan
 * 9. wajibBeli
 * 10. users
 * 11. hakAkses
 * 12. logAktivitas
 * 
 * LANGKAH DEPLOYMENT:
 * 1. Buka Google Spreadsheet baru atau yang sudah ada.
 * 2. Klik menu 'Ekstensi' > 'Apps Script' (Extensions > Apps Script).
 * 3. Tempel seluruh kode ini ke file 'Code.gs'.
 * 4. Simpan (Ctrl+S / Cmd+S).
 * 5. Pilih fungsi 'setupAllSheets' di dropdown atas, lalu klik 'Run' (Jalankan)
 *    untuk membuat 12 sheet beserta header otomatis.
 * 6. Klik tombol 'Deploy' (Terapkan) > 'New deployment' (Terapkan Baru).
 * 7. Pilih tipe 'Web app' (Aplikasi Web).
 * 8. Kolom 'Execute as': Pilih 'Me' (Saya).
 * 9. Kolom 'Who has access': Pilih 'Anyone' (Siapa saja).
 * 10. Klik Deploy, lalu salin 'Web App URL' yang berakhiran /exec.
 * 11. Tempelkan URL tersebut ke aplikasi website HARIKLIN di menu
 *     'Kelola Akses' > 'Google Spreadsheet & Apps Script'.
 * ============================================================================
 */

const SHEET_NAMES = {
  MASTER: 'masterBarang',
  MASUK: 'barangMasuk',
  PINJAM: 'peminjaman',
  KEMBALI: 'pengembalian',
  OPNAME: 'stockOpname',
  REKAP: 'rekapTransaksi',
  RUSAK: 'barangRusak',
  PERBAIKAN: 'perbaikan',
  BELI: 'wajibBeli',
  USERS: 'users',
  HAK_AKSES: 'hakAkses',
  LOGS: 'logAktivitas'
};

function doGet(e) {
  try {
    const action = e && e.parameter ? e.parameter.action : 'readAll';
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    
    if (action === 'ping') {
      return responseJSON({
        success: true,
        message: 'Koneksi HARIKLIN Google Apps Script Aktif!',
        timestamp: new Date().toISOString()
      });
    }
    
    // Membaca seluruh data 12 sheet menjadi objek JSON
    const result = {
      masterBarang: readSheetData(ss, SHEET_NAMES.MASTER),
      barangMasuk: readSheetData(ss, SHEET_NAMES.MASUK),
      peminjaman: readSheetData(ss, SHEET_NAMES.PINJAM),
      pengembalian: readSheetData(ss, SHEET_NAMES.KEMBALI),
      stockOpname: readSheetData(ss, SHEET_NAMES.OPNAME),
      rekapTransaksi: readSheetData(ss, SHEET_NAMES.REKAP),
      barangRusak: readSheetData(ss, SHEET_NAMES.RUSAK),
      perbaikan: readSheetData(ss, SHEET_NAMES.PERBAIKAN),
      wajibBeli: readSheetData(ss, SHEET_NAMES.BELI),
      users: readSheetData(ss, SHEET_NAMES.USERS),
      hakAkses: readSheetData(ss, SHEET_NAMES.HAK_AKSES),
      logAktivitas: readSheetData(ss, SHEET_NAMES.LOGS)
    };

    return responseJSON({ success: true, data: result, timestamp: new Date().toISOString() });
  } catch (err) {
    return responseJSON({ success: false, error: err.toString() });
  }
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    // Kunci proses transaksi selama 30 detik untuk perlindungan transaksi bersamaan
    lock.waitLock(30000);
    
    const postData = JSON.parse(e.postData.contents);
    const action = postData.action;
    const payload = postData.payload;
    const ss = SpreadsheetApp.getActiveSpreadsheet();

    if (action === 'sync_all') {
      // Sinkronisasi data ke sheet yang relevan
      if (payload.masterBarang) writeSheetData(ss, SHEET_NAMES.MASTER, payload.masterBarang);
      if (payload.barangMasuk) writeSheetData(ss, SHEET_NAMES.MASUK, payload.barangMasuk);
      if (payload.peminjaman) writeSheetData(ss, SHEET_NAMES.PINJAM, payload.peminjaman);
      if (payload.pengembalian) writeSheetData(ss, SHEET_NAMES.KEMBALI, payload.pengembalian);
      if (payload.stockOpname) writeSheetData(ss, SHEET_NAMES.OPNAME, payload.stockOpname);
      if (payload.rekapTransaksi) writeSheetData(ss, SHEET_NAMES.REKAP, payload.rekapTransaksi);
      if (payload.barangRusak) writeSheetData(ss, SHEET_NAMES.RUSAK, payload.barangRusak);
      if (payload.perbaikan) writeSheetData(ss, SHEET_NAMES.PERBAIKAN, payload.perbaikan);
      if (payload.wajibBeli) writeSheetData(ss, SHEET_NAMES.BELI, payload.wajibBeli);
      if (payload.users) writeSheetData(ss, SHEET_NAMES.USERS, payload.users);
      if (payload.hakAkses) writeSheetData(ss, SHEET_NAMES.HAK_AKSES, payload.hakAkses);
      if (payload.logAktivitas) writeSheetData(ss, SHEET_NAMES.LOGS, payload.logAktivitas);

      return responseJSON({
        success: true,
        message: 'Data seluruh modul berhasil disinkronkan ke Google Spreadsheet.'
      });
    }

    if (action === 'append_row') {
      const sheet = getOrCreateSheet(ss, postData.sheetName);
      sheet.appendRow(postData.rowValues);
      return responseJSON({ success: true, message: 'Baris transaksi berhasil ditambahkan.' });
    }

    return responseJSON({ success: false, message: 'Aksi doPost tidak dikenali: ' + action });
  } catch (err) {
    return responseJSON({ success: false, error: err.toString() });
  } finally {
    lock.releaseLock();
  }
}

function responseJSON(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function getOrCreateSheet(ss, sheetName) {
  let sheet = ss.getSheetByName(sheetName);
  if (!sheet) {
    sheet = ss.insertSheet(sheetName);
  }
  return sheet;
}

function readSheetData(ss, sheetName) {
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet) return [];
  const rows = sheet.getDataRange().getValues();
  if (rows.length <= 1) return [];

  const headers = rows[0];
  const data = [];
  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    const item = {};
    for (let j = 0; j < headers.length; j++) {
      const key = headers[j];
      if (key) {
        item[key] = row[j];
      }
    }
    data.push(item);
  }
  return data;
}

function writeSheetData(ss, sheetName, items) {
  if (!items || !items.length) return;
  const sheet = getOrCreateSheet(ss, sheetName);
  sheet.clearContents();

  const headers = Object.keys(items[0]);
  const rows = [headers];

  for (let i = 0; i < items.length; i++) {
    const obj = items[i];
    const row = [];
    for (let j = 0; j < headers.length; j++) {
      const key = headers[j];
      let val = obj[key];
      if (typeof val === 'object' && val !== null) {
        val = JSON.stringify(val);
      }
      row.push(val !== undefined && val !== null ? val : '');
    }
    rows.push(row);
  }

  sheet.getRange(1, 1, rows.length, headers.length).setValues(rows);
  sheet.getRange(1, 1, 1, headers.length)
    .setFontWeight('bold')
    .setBackground('#064e3b')
    .setFontColor('#ffffff');
}

/**
 * Jalankan fungsi ini satu kali di Google Apps Script Editor
 * untuk menginisialisasi 12 sheet dan header bawaan.
 */
function setupAllSheets() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  const headersMap = {
    masterBarang: ['id', 'kodeBarang', 'namaBarang', 'kategori', 'satuan', 'stokAwal', 'stokAktif', 'dipinjam', 'rusak', 'perbaikan', 'menungguBeli', 'keterangan', 'lokasiRak', 'updatedAt'],
    barangMasuk: ['id', 'noTransaksiMasuk', 'kodeBarang', 'namaBarang', 'kategori', 'satuan', 'jumlahMasuk', 'tanggalMasuk', 'sumberBarang', 'penanggungJawab', 'keterangan', 'dicatatOleh', 'createdAt'],
    peminjaman: ['id', 'noTransaksi', 'tanggalPinjam', 'tanggalRencanaKembali', 'namaPeminjam', 'penanggungJawab', 'keperluan', 'keterangan', 'status', 'items', 'dicatatOleh', 'createdAt'],
    pengembalian: ['id', 'noPengembalian', 'peminjamanId', 'noTransaksiPinjam', 'tanggalKembali', 'namaPeminjam', 'penanggungJawab', 'items', 'dicatatOleh', 'createdAt'],
    stockOpname: ['id', 'noOpname', 'tanggalOpname', 'kodeBarang', 'namaBarang', 'satuan', 'stokSistem', 'stokFisik', 'selisih', 'statusPenyesuaian', 'dicatatOleh', 'disetujuiOleh', 'catatan', 'createdAt'],
    rekapTransaksi: ['id', 'tanggal', 'jenisTransaksi', 'noReferensi', 'kodeBarang', 'namaBarang', 'jumlah', 'stokSebelum', 'stokSesudah', 'keterangan', 'user'],
    barangRusak: ['id', 'kodeBarang', 'namaBarang', 'satuan', 'jumlahRusak', 'tanggalKerusakan', 'sumberKerusakan', 'keterangan', 'statusPenanganan', 'perbaikanId', 'pembelianId', 'dicatatOleh', 'createdAt'],
    perbaikan: ['id', 'noPerbaikan', 'barangRusakId', 'kodeBarang', 'namaBarang', 'satuan', 'jumlahBarang', 'tanggalKerusakan', 'penyebabKerusakan', 'namaPetugas', 'keteranganPerbaikan', 'estimasiBiaya', 'biayaAktual', 'tanggalMulai', 'tanggalSelesai', 'status', 'disetujuiOleh', 'ditolakAlasan', 'accSelesaiOleh', 'createdAt'],
    wajibBeli: ['id', 'noPengadaan', 'barangRusakId', 'kodeBarang', 'namaBarang', 'satuan', 'jumlahDibutuhkan', 'alasanPembelian', 'tanggalPengajuan', 'namaPengaju', 'estimasiHarga', 'hargaAktual', 'status', 'disetujuiOleh', 'ditolakAlasan', 'accDiterimaOleh', 'createdAt'],
    users: ['id', 'username', 'namaLengkap', 'email', 'role', 'status', 'terakhirLogin', 'createdAt'],
    hakAkses: ['userId', 'username', 'role', 'permissionsJson', 'updatedAt'],
    logAktivitas: ['id', 'timestamp', 'userId', 'username', 'action', 'modul', 'detail']
  };

  for (const sheetName in headersMap) {
    let sheet = ss.getSheetByName(sheetName);
    if (!sheet) {
      sheet = ss.insertSheet(sheetName);
    }
    if (sheet.getLastRow() === 0) {
      const headers = headersMap[sheetName];
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
      sheet.getRange(1, 1, 1, headers.length)
        .setFontWeight('bold')
        .setBackground('#064e3b')
        .setFontColor('#ffffff');
      sheet.setFrozenRows(1);
    }
  }

  Logger.log('Inisialisasi 12 Sheet database HARIKLIN berhasil disiapkan!');
}

/**
 * Jalankan fungsi ini untuk mengisi otomatis 75 barang awal inventaris HARIKLIN
 * langsung ke sheet 'masterBarang'.
 */
function isiDataAwal75Barang() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const items = [
  {
    "id": "BRG-001",
    "kodeBarang": "BRG-001",
    "namaBarang": "set vacum kecil crisbow",
    "kategori": "Mesin & Peralatan Elektrik",
    "satuan": "Set",
    "stokAwal": 2,
    "stokAktif": 0,
    "dipinjam": 0,
    "rusak": 2,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Motor dinamo perlu servis (2 unit rusak)",
    "lokasiRak": "Rak Mesin A-01",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-002",
    "kodeBarang": "BRG-002",
    "namaBarang": "set vacum extraktor",
    "kategori": "Mesin & Peralatan Elektrik",
    "satuan": "Set",
    "stokAwal": 2,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 1,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "1 unit siap pakai, 1 unit noozle bocor",
    "lokasiRak": "Rak Mesin A-02",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-003",
    "kodeBarang": "BRG-003",
    "namaBarang": "ujung vacum bening",
    "kategori": "Mesin & Peralatan Elektrik",
    "satuan": "Pcs",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Aksesoris vacum kondisi mulus",
    "lokasiRak": "Rak Aksesoris B-01",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-004",
    "kodeBarang": "BRG-004",
    "namaBarang": "set water jet",
    "kategori": "Mesin & Peralatan Elektrik",
    "satuan": "Set",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Tekanan tinggi normal siap operasional",
    "lokasiRak": "Area Heavy Tool G-01",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-005",
    "kodeBarang": "BRG-005",
    "namaBarang": "mesin poliser",
    "kategori": "Mesin & Peralatan Elektrik",
    "satuan": "Unit",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Poliser lantai lengkap pad holder",
    "lokasiRak": "Area Heavy Tool G-02",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-006",
    "kodeBarang": "BRG-006",
    "namaBarang": "set mesin steam",
    "kategori": "Mesin & Peralatan Elektrik",
    "satuan": "Set",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Mesin steam uap siap pakai",
    "lokasiRak": "Rak Mesin A-03",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-007",
    "kodeBarang": "BRG-007",
    "namaBarang": "bor hijau",
    "kategori": "Perkakas & Alat Pertukangan",
    "satuan": "Unit",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Bor listrik tangan warna hijau",
    "lokasiRak": "Lemari Toolkit T-01",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-008",
    "kodeBarang": "BRG-008",
    "namaBarang": "mesin senso steel",
    "kategori": "Mesin & Peralatan Elektrik",
    "satuan": "Unit",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Mesin senso pemotong ranting",
    "lokasiRak": "Lemari Toolkit T-02",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-009",
    "kodeBarang": "BRG-009",
    "namaBarang": "penutup telinga crisbow",
    "kategori": "APD & Perlengkapan Kerja",
    "satuan": "Pcs",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Earmuff safety standar Crisbow",
    "lokasiRak": "Lemari APD P-01",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-010",
    "kodeBarang": "BRG-010",
    "namaBarang": "parang",
    "kategori": "Perkakas & Alat Pertukangan",
    "satuan": "Pcs",
    "stokAwal": 2,
    "stokAktif": 2,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Kondisi tajam dengan sarung pelindung",
    "lokasiRak": "Gantungan Alat K-01",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-011",
    "kodeBarang": "BRG-011",
    "namaBarang": "gergaji tangan",
    "kategori": "Perkakas & Alat Pertukangan",
    "satuan": "Pcs",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Gergaji kayu standar",
    "lokasiRak": "Gantungan Alat K-02",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-012",
    "kodeBarang": "BRG-012",
    "namaBarang": "cangkul kecil",
    "kategori": "Perkakas & Alat Pertukangan",
    "satuan": "Pcs",
    "stokAwal": 4,
    "stokAktif": 4,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Gagang kayu kuat",
    "lokasiRak": "Sudut Kebun S-01",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-013",
    "kodeBarang": "BRG-013",
    "namaBarang": "set kunci AC warna biru",
    "kategori": "Perkakas & Alat Pertukangan",
    "satuan": "Set",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Set manifold dan kunci servis AC",
    "lokasiRak": "Lemari Toolkit T-03",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-014",
    "kodeBarang": "BRG-014",
    "namaBarang": "set kunci L",
    "kategori": "Perkakas & Alat Pertukangan",
    "satuan": "Set",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Lengkap ukuran 1.5mm - 10mm",
    "lokasiRak": "Lemari Toolkit T-04",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-015",
    "kodeBarang": "BRG-015",
    "namaBarang": "kabel panjang",
    "kategori": "Mesin & Peralatan Elektrik",
    "satuan": "Roll",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Panjang 30 meter dengan rol stopkontak",
    "lokasiRak": "Rak Elektrik E-01",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-016",
    "kodeBarang": "BRG-016",
    "namaBarang": "selang panjang hijau",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Roll",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Selang air spiral serat benang 25m",
    "lokasiRak": "Area Cuci W-01",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-017",
    "kodeBarang": "BRG-017",
    "namaBarang": "sprayer 8ltr putih kuning",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Unit",
    "stokAwal": 2,
    "stokAktif": 0,
    "dipinjam": 0,
    "rusak": 2,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "2 unit pompa presur bocor",
    "lokasiRak": "Area Hama H-01",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-018",
    "kodeBarang": "BRG-018",
    "namaBarang": "set pel pake yg empat",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Set",
    "stokAwal": 5,
    "stokAktif": 5,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Set pel lengkap ember peras 4 roda",
    "lokasiRak": "Rak Janitor J-01",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-019",
    "kodeBarang": "BRG-019",
    "namaBarang": "pel biasa",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 3,
    "stokAktif": 3,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Pel tangkai katun",
    "lokasiRak": "Rak Janitor J-02",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-020",
    "kodeBarang": "BRG-020",
    "namaBarang": "sapu",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 12,
    "stokAktif": 4,
    "dipinjam": 0,
    "rusak": 8,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "8 unit rontok/patah gagang",
    "lokasiRak": "Gantungan Janitor J-03",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-021",
    "kodeBarang": "BRG-021",
    "namaBarang": "sapu panjang bambu",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 2,
    "stokAktif": 2,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Sapu lidi gagang bambu panjang",
    "lokasiRak": "Area Luar Gudang",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-022",
    "kodeBarang": "BRG-022",
    "namaBarang": "sikat lantai",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 2,
    "stokAktif": 2,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Sikat dorong lantai gagang panjang",
    "lokasiRak": "Rak Janitor J-04",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-023",
    "kodeBarang": "BRG-023",
    "namaBarang": "sekop sampah",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 4,
    "stokAktif": 4,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Dustpan plastik tebal gagang panjang",
    "lokasiRak": "Rak Janitor J-05",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-024",
    "kodeBarang": "BRG-024",
    "namaBarang": "kuas",
    "kategori": "Perkakas & Alat Pertukangan",
    "satuan": "Pcs",
    "stokAwal": 5,
    "stokAktif": 0,
    "dipinjam": 0,
    "rusak": 5,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "5 kuas mengeras/rusak perlu beli baru",
    "lokasiRak": "Lemari Toolkit T-05",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-025",
    "kodeBarang": "BRG-025",
    "namaBarang": "kerok lantai",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 10,
    "stokAktif": 7,
    "dipinjam": 0,
    "rusak": 3,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Scraper lantai 3 unit tumpul parah/bengkok",
    "lokasiRak": "Rak Janitor J-06",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-026",
    "kodeBarang": "BRG-026",
    "namaBarang": "pisau cat",
    "kategori": "Perkakas & Alat Pertukangan",
    "satuan": "Pcs",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Kape scraper stainless",
    "lokasiRak": "Lemari Toolkit T-06",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-027",
    "kodeBarang": "BRG-027",
    "namaBarang": "tang",
    "kategori": "Perkakas & Alat Pertukangan",
    "satuan": "Pcs",
    "stokAwal": 4,
    "stokAktif": 4,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Tang kombinasi & potong",
    "lokasiRak": "Lemari Toolkit T-07",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-028",
    "kodeBarang": "BRG-028",
    "namaBarang": "gunting tanaman",
    "kategori": "Perkakas & Alat Pertukangan",
    "satuan": "Pcs",
    "stokAwal": 2,
    "stokAktif": 2,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Gunting dahan tajam",
    "lokasiRak": "Lemari Toolkit T-08",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-029",
    "kodeBarang": "BRG-029",
    "namaBarang": "kunci pipa kuning",
    "kategori": "Perkakas & Alat Pertukangan",
    "satuan": "Pcs",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Ukuran 12 inch pipa heavy duty",
    "lokasiRak": "Lemari Toolkit T-09",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-030",
    "kodeBarang": "BRG-030",
    "namaBarang": "wiper kaca",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 4,
    "stokAktif": 4,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Karet pembersih kaca jendela",
    "lokasiRak": "Rak Janitor J-07",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-031",
    "kodeBarang": "BRG-031",
    "namaBarang": "wiper lantai",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 4,
    "stokAktif": 4,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Floor squeegee karet tebal",
    "lokasiRak": "Rak Janitor J-08",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-032",
    "kodeBarang": "BRG-032",
    "namaBarang": "stik laba2",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 2,
    "stokAktif": 2,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Tongkat teleskopik pembersih sarang laba-laba",
    "lokasiRak": "Gantungan Janitor J-09",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-033",
    "kodeBarang": "BRG-033",
    "namaBarang": "sikat tangan",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 12,
    "stokAktif": 12,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Sikat kecil serbaguna untuk nat & dinding",
    "lokasiRak": "Rak Janitor J-10",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-034",
    "kodeBarang": "BRG-034",
    "namaBarang": "sikat panci",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 23,
    "stokAktif": 20,
    "dipinjam": 0,
    "rusak": 3,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "3 unit kawat aus",
    "lokasiRak": "Rak Janitor J-11",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-035",
    "kodeBarang": "BRG-035",
    "namaBarang": "ember biru kotak",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Ember kotak ukuran sedang",
    "lokasiRak": "Rak Ember E-02",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-036",
    "kodeBarang": "BRG-036",
    "namaBarang": "ember bulat sedang",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Ember air bulat standar",
    "lokasiRak": "Rak Ember E-03",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-037",
    "kodeBarang": "BRG-037",
    "namaBarang": "ember bulat hijau sedang",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Ember air warna hijau",
    "lokasiRak": "Rak Ember E-04",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-038",
    "kodeBarang": "BRG-038",
    "namaBarang": "ember orange kecil",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 6,
    "stokAktif": 6,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Ember kecil serbaguna",
    "lokasiRak": "Rak Ember E-05",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-039",
    "kodeBarang": "BRG-039",
    "namaBarang": "parfum londry jerigen 5ltr",
    "kategori": "Bahan Pembersih & Kimia",
    "satuan": "Jerigen",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Isi tersisa 1/2 jerigen (2.5 Liter)",
    "lokasiRak": "Lemari Kimia K-01",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-040",
    "kodeBarang": "BRG-040",
    "namaBarang": "jerigen baclyn belum terpakai",
    "kategori": "Bahan Pembersih & Kimia",
    "satuan": "Jerigen",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Disinfektan pemutih/bleach segel",
    "lokasiRak": "Lemari Kimia K-02",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-041",
    "kodeBarang": "BRG-041",
    "namaBarang": "perangkap tikus",
    "kategori": "Perlengkapan Pest Control",
    "satuan": "Pcs",
    "stokAwal": 2,
    "stokAktif": 0,
    "dipinjam": 0,
    "rusak": 2,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Per perangkap patah (2 unit)",
    "lokasiRak": "Area Hama H-02",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-042",
    "kodeBarang": "BRG-042",
    "namaBarang": "tas pinggang hitam",
    "kategori": "APD & Perlengkapan Kerja",
    "satuan": "Pcs",
    "stokAwal": 14,
    "stokAktif": 13,
    "dipinjam": 0,
    "rusak": 1,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "1 unit resleting rusak robek",
    "lokasiRak": "Lemari APD P-02",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-043",
    "kodeBarang": "BRG-043",
    "namaBarang": "baju hariklin",
    "kategori": "APD & Perlengkapan Kerja",
    "satuan": "Pcs",
    "stokAwal": 3,
    "stokAktif": 3,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Seragam kerja resmi Hariklin",
    "lokasiRak": "Lemari APD P-03",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-044",
    "kodeBarang": "BRG-044",
    "namaBarang": "rompi biru",
    "kategori": "APD & Perlengkapan Kerja",
    "satuan": "Pcs",
    "stokAwal": 7,
    "stokAktif": 7,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Rompi safety warna biru",
    "lokasiRak": "Lemari APD P-04",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-045",
    "kodeBarang": "BRG-045",
    "namaBarang": "lap kanebo",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 8,
    "stokAktif": 8,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Kanebo daya serap tinggi",
    "lokasiRak": "Kotak Lap L-01",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-046",
    "kodeBarang": "BRG-046",
    "namaBarang": "lap biasa",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 19,
    "stokAktif": 19,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Kain lap microfiber & katun",
    "lokasiRak": "Kotak Lap L-02",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-047",
    "kodeBarang": "BRG-047",
    "namaBarang": "lap kaca",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 2,
    "stokAktif": 2,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Kain lap khusus kaca tanpa serat",
    "lokasiRak": "Kotak Lap L-03",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-048",
    "kodeBarang": "BRG-048",
    "namaBarang": "spoit kecil",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 17,
    "stokAktif": 5,
    "dipinjam": 0,
    "rusak": 12,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "12 unit tabung karet macet/retak",
    "lokasiRak": "Kotak Kecil K-03",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-049",
    "kodeBarang": "BRG-049",
    "namaBarang": "sprayer 2litr ungu",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 2,
    "stokAktif": 2,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Sprayer botol presur warna ungu",
    "lokasiRak": "Area Hama H-03",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-050",
    "kodeBarang": "BRG-050",
    "namaBarang": "sprayer 2ltr hitam",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 2,
    "stokAktif": 0,
    "dipinjam": 0,
    "rusak": 2,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "2 unit nozzle mampet & pecah leher",
    "lokasiRak": "Area Hama H-04",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-051",
    "kodeBarang": "BRG-051",
    "namaBarang": "box perlengkapan hama tikus",
    "kategori": "Perlengkapan Pest Control",
    "satuan": "Box",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Kotak baiting station dan umpan lengkap",
    "lokasiRak": "Area Hama H-05",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-052",
    "kodeBarang": "BRG-052",
    "namaBarang": "Tempat duduk kecil",
    "kategori": "Sarana & Inventaris Kantor",
    "satuan": "Pcs",
    "stokAwal": 4,
    "stokAktif": 4,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Bangku plastik portable",
    "lokasiRak": "Gudang Belakang",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-053",
    "kodeBarang": "BRG-053",
    "namaBarang": "kursi kantor hitam",
    "kategori": "Sarana & Inventaris Kantor",
    "satuan": "Pcs",
    "stokAwal": 4,
    "stokAktif": 4,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Kursi putar hidrolik hitam",
    "lokasiRak": "Ruang Kantor",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-054",
    "kodeBarang": "BRG-054",
    "namaBarang": "meja kerja",
    "kategori": "Sarana & Inventaris Kantor",
    "satuan": "Unit",
    "stokAwal": 2,
    "stokAktif": 2,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Meja kerja kantor 1/2 biro",
    "lokasiRak": "Ruang Kantor",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-055",
    "kodeBarang": "BRG-055",
    "namaBarang": "kompor gas kecil",
    "kategori": "Sarana & Inventaris Kantor",
    "satuan": "Unit",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Kompor portable 1 tungku",
    "lokasiRak": "Pantry Gudang",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-056",
    "kodeBarang": "BRG-056",
    "namaBarang": "tabung gas melon",
    "kategori": "Sarana & Inventaris Kantor",
    "satuan": "Pcs",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Tabung LPG 3kg",
    "lokasiRak": "Pantry Gudang",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-057",
    "kodeBarang": "BRG-057",
    "namaBarang": "AC",
    "kategori": "Sarana & Inventaris Kantor",
    "satuan": "Unit",
    "stokAwal": 2,
    "stokAktif": 2,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "AC Split 1 PK terpasang",
    "lokasiRak": "Ruang Kantor & Gudang Obat",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-058",
    "kodeBarang": "BRG-058",
    "namaBarang": "kipas angin Gantung",
    "kategori": "Sarana & Inventaris Kantor",
    "satuan": "Unit",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Kipas langit-langit",
    "lokasiRak": "Area Gudang Utama",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-059",
    "kodeBarang": "BRG-059",
    "namaBarang": "set teskit kolam renang",
    "kategori": "Bahan Pembersih & Kimia",
    "satuan": "Set",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Tes kit pH dan Chlorine dengan tabung komparator",
    "lokasiRak": "Lemari Kimia K-03",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-060",
    "kodeBarang": "BRG-060",
    "namaBarang": "jerigen kaporit tablet",
    "kategori": "Bahan Pembersih & Kimia",
    "satuan": "Jerigen",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Kaporit tablet 90% perlakuan air",
    "lokasiRak": "Lemari Kimia K-04",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-061",
    "kodeBarang": "BRG-061",
    "namaBarang": "tempat sampah kecil",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Tempat sampah pedal injak",
    "lokasiRak": "Area Kantor",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-062",
    "kodeBarang": "BRG-062",
    "namaBarang": "papan tulis sedang",
    "kategori": "Sarana & Inventaris Kantor",
    "satuan": "Pcs",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Whiteboard 90x120cm",
    "lokasiRak": "Ruang Rapat",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-063",
    "kodeBarang": "BRG-063",
    "namaBarang": "papan tulis kecil",
    "kategori": "Sarana & Inventaris Kantor",
    "satuan": "Pcs",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Whiteboard 40x60cm papan jadwal",
    "lokasiRak": "Gudang Depan",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-064",
    "kodeBarang": "BRG-064",
    "namaBarang": "ring led( lampu cicin)",
    "kategori": "Mesin & Peralatan Elektrik",
    "satuan": "Pcs",
    "stokAwal": 1,
    "stokAktif": 1,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Ring light penerangan dokumentasi pekerjaan",
    "lokasiRak": "Rak Elektrik E-02",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-065",
    "kodeBarang": "BRG-065",
    "namaBarang": "blower crisbow",
    "kategori": "Mesin & Peralatan Elektrik",
    "satuan": "Unit",
    "stokAwal": 4,
    "stokAktif": 4,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Floor blower pengering karpet / lantai",
    "lokasiRak": "Area Heavy Tool G-03",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-066",
    "kodeBarang": "BRG-066",
    "namaBarang": "tangga aluminium crisbow",
    "kategori": "Perkakas & Alat Pertukangan",
    "satuan": "Unit",
    "stokAwal": 2,
    "stokAktif": 2,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Tangga lipat teleskopik 2 meter",
    "lokasiRak": "Gudang Belakang Dinding",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-067",
    "kodeBarang": "BRG-067",
    "namaBarang": "Gorden tirai warna coklat",
    "kategori": "Sarana & Inventaris Kantor",
    "satuan": "Set",
    "stokAwal": 2,
    "stokAktif": 2,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Gorden tirai jendela kantor",
    "lokasiRak": "Ruang Kantor",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-068",
    "kodeBarang": "BRG-068",
    "namaBarang": "Sepatu Bot Uk 41",
    "kategori": "APD & Perlengkapan Kerja",
    "satuan": "Pasang",
    "stokAwal": 3,
    "stokAktif": 3,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Boots karet kuning safety ukuran 41",
    "lokasiRak": "Rak Sepatu APD S-01",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-069",
    "kodeBarang": "BRG-069",
    "namaBarang": "Sepatu Bot Uk 42",
    "kategori": "APD & Perlengkapan Kerja",
    "satuan": "Pasang",
    "stokAwal": 2,
    "stokAktif": 2,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Boots karet kuning safety ukuran 42",
    "lokasiRak": "Rak Sepatu APD S-02",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-070",
    "kodeBarang": "BRG-070",
    "namaBarang": "Gayung",
    "kategori": "Alat Kebersihan & Sanitasi",
    "satuan": "Pcs",
    "stokAwal": 2,
    "stokAktif": 2,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Gayung plastik tebal",
    "lokasiRak": "Toilet & Kamar Mandi",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-071",
    "kodeBarang": "BRG-071",
    "namaBarang": "Helm Kuning",
    "kategori": "APD & Perlengkapan Kerja",
    "satuan": "Pcs",
    "stokAwal": 5,
    "stokAktif": 5,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Safety helmet konstruksi warna kuning",
    "lokasiRak": "Lemari APD P-05",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-072",
    "kodeBarang": "BRG-072",
    "namaBarang": "terminal kabel hitam",
    "kategori": "Mesin & Peralatan Elektrik",
    "satuan": "Pcs",
    "stokAwal": 2,
    "stokAktif": 2,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Colokan cabang 4 lobang dengan saklar",
    "lokasiRak": "Rak Elektrik E-03",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-073",
    "kodeBarang": "BRG-073",
    "namaBarang": "Lampu Cas",
    "kategori": "Mesin & Peralatan Elektrik",
    "satuan": "Pcs",
    "stokAwal": 3,
    "stokAktif": 3,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Emergency lamp rechargeable LED",
    "lokasiRak": "Rak Elektrik E-04",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-074",
    "kodeBarang": "BRG-074",
    "namaBarang": "Senter Kepala Cas",
    "kategori": "Mesin & Peralatan Elektrik",
    "satuan": "Pcs",
    "stokAwal": 3,
    "stokAktif": 3,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Headlamp LED cas untuk kerja plafon & malam",
    "lokasiRak": "Lemari APD P-06",
    "updatedAt": "2026-11-01"
  },
  {
    "id": "BRG-075",
    "kodeBarang": "BRG-075",
    "namaBarang": "rompi proyek hijau",
    "kategori": "APD & Perlengkapan Kerja",
    "satuan": "Pcs",
    "stokAwal": 7,
    "stokAktif": 7,
    "dipinjam": 0,
    "rusak": 0,
    "perbaikan": 0,
    "menungguBeli": 0,
    "keterangan": "Rompi spotlight hijau terang untuk lapangan",
    "lokasiRak": "Lemari APD P-07",
    "updatedAt": "2026-11-01"
  }
];
  writeSheetData(ss, SHEET_NAMES.MASTER, items);
  Logger.log('75 Data inventaris HARIKLIN berhasil diisi ke sheet masterBarang!');
}
