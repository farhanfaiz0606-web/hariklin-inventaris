import React from 'react';
import {
  LayoutDashboard,
  Boxes,
  ArrowUpRight,
  ArrowDownLeft,
  PackagePlus,
  AlertTriangle,
  Wrench,
  ShoppingCart,
  ClipboardCheck,
  FileText,
  ShieldCheck,
  X,
} from 'lucide-react';
import { User } from '../types';

export type NavMenuKey =
  | 'dashboard'
  | 'masterBarang'
  | 'peminjaman'
  | 'pengembalian'
  | 'barangMasuk'
  | 'barangRusak'
  | 'perbaikan'
  | 'pembelian'
  | 'stockOpname'
  | 'laporan'
  | 'kelolaAkses';

interface SidebarProps {
  activeMenu: NavMenuKey;
  onSelectMenu: (menu: NavMenuKey) => void;
  currentUser: User;
  isOpen: boolean;
  onClose: () => void;
  badgeCounts: {
    pinjamAktif: number;
    barangRusak: number;
    perbaikanPending: number;
    pembelianPending: number;
    opnamePending: number;
  };
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeMenu,
  onSelectMenu,
  currentUser,
  isOpen,
  onClose,
  badgeCounts,
}) => {
  const menuItems: {
    key: NavMenuKey;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number;
    badgeColor?: string;
    adminOnly?: boolean;
  }[] = [
    {
      key: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
    },
    {
      key: 'masterBarang',
      label: 'Master Barang',
      icon: Boxes,
    },
    {
      key: 'peminjaman',
      label: 'Peminjaman Alat',
      icon: ArrowUpRight,
      badge: badgeCounts.pinjamAktif,
      badgeColor: 'bg-emerald-100 text-emerald-800',
    },
    {
      key: 'pengembalian',
      label: 'Pengembalian Alat',
      icon: ArrowDownLeft,
    },
    {
      key: 'barangMasuk',
      label: 'Barang Masuk',
      icon: PackagePlus,
    },
    {
      key: 'barangRusak',
      label: 'Barang Rusak',
      icon: AlertTriangle,
      badge: badgeCounts.barangRusak,
      badgeColor: 'bg-rose-100 text-rose-800',
    },
    {
      key: 'perbaikan',
      label: 'Perbaikan Barang',
      icon: Wrench,
      badge: badgeCounts.perbaikanPending,
      badgeColor: 'bg-amber-100 text-amber-800',
    },
    {
      key: 'pembelian',
      label: 'Pembelian Barang',
      icon: ShoppingCart,
      badge: badgeCounts.pembelianPending,
      badgeColor: 'bg-blue-100 text-blue-800',
    },
    {
      key: 'stockOpname',
      label: 'Stock Opname',
      icon: ClipboardCheck,
      badge: badgeCounts.opnamePending,
      badgeColor: 'bg-purple-100 text-purple-800',
    },
    {
      key: 'laporan',
      label: 'Laporan',
      icon: FileText,
    },
    {
      key: 'kelolaAkses',
      label: 'Kelola Akses',
      icon: ShieldCheck,
      adminOnly: true,
    },
  ];

  // Filter based on user role and permissions
  const filteredMenuItems = menuItems.filter((item) => {
    // If Admin, has access to everything
    if (currentUser.role === 'ADMIN') return true;
    // Kelola Akses is strictly Admin only
    if (item.adminOnly) return false;
    // Check Petugas permissions
    return currentUser.permissions[item.key as keyof typeof currentUser.permissions] === true;
  });

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-40 lg:hidden"
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 w-64 bg-slate-950 border-r border-slate-800/80 z-50 transition-transform duration-200 lg:translate-x-0 lg:static lg:z-0 flex flex-col no-print ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Sidebar Brand Header */}
        <div className="flex items-center justify-between p-3.5 border-b border-slate-800/80 bg-slate-900/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white p-1 flex items-center justify-center shrink-0 shadow-xs overflow-hidden">
              <img
                src="/hariklin-logo.jpg"
                alt="HARIKLIN"
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <div className="font-extrabold text-xs text-white tracking-tight">HARIKLIN</div>
              <div className="text-[9px] text-emerald-400 font-semibold tracking-wider uppercase">Gudang &amp; Logistik</div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation List */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">
            Menu Utama
          </div>

          {filteredMenuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeMenu === item.key;
            return (
              <button
                key={item.key}
                onClick={() => {
                  onSelectMenu(item.key);
                  if (isOpen) onClose();
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all group ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-900/40 font-semibold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`w-4 h-4 transition-colors ${
                      isActive ? 'text-white' : 'text-slate-400 group-hover:text-emerald-400'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>

                {item.badge !== undefined && item.badge > 0 && (
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                      isActive ? 'bg-white/20 text-white' : item.badgeColor || 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Footer info */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-950/60 text-slate-400 text-[11px]">
          <div className="flex items-center justify-between">
            <span className="font-medium text-slate-300">Hariklin Warehouse</span>
            <span className="font-mono text-[10px] text-emerald-400">v2.5 GAS</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">Database Google Spreadsheet</p>
        </div>
      </aside>
    </>
  );
};
