import React, { useState } from 'react';
import {
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Search,
  FileSpreadsheet,
  Check,
  Clock,
} from 'lucide-react';
import { Peminjaman, Pengembalian, User } from '../types';
import { exportToCSV } from '../utils/exportUtils';

interface PengembalianViewProps {
  peminjamanList: Peminjaman[];
  pengembalianList: Pengembalian[];
  onProcessPengembalian: (data: {
    peminjamanId: string;
    tanggalKembali: string;
    items: {
      kodeBarang: string;
      namaBarang: string;
      satuan: string;
      jumlahKembali: number;
      kondisi: 'Baik' | 'Rusak';
      keteranganRusak?: string;
    }[];
  }) => void;
  currentUser: User;
}

export const PengembalianView: React.FC<PengembalianViewProps> = ({
  peminjamanList,
  pengembalianList,
  onProcessPengembalian,
  currentUser,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLoanId, setSelectedLoanId] = useState('');
  const [tanggalKembali, setTanggalKembali] = useState(
    new Date().toISOString().split('T')[0]
  );

  // Return items form state
  const [returnItems, setReturnItems] = useState<{
    [kodeBarang: string]: {
      jumlahKembali: number;
      kondisi: 'Baik' | 'Rusak';
      keteranganRusak: string;
    };
  }>({});

  // Active loans (not finished yet)
  const activeLoans = peminjamanList.filter((p) => p.status !== 'Selesai');
  const selectedLoan = peminjamanList.find((p) => p.id === selectedLoanId);

  // When a loan is selected, initialize the return inputs
  const handleSelectLoan = (loanId: string) => {
    setSelectedLoanId(loanId);
    const loan = peminjamanList.find((p) => p.id === loanId);
    if (!loan) return;

    const initialMap: typeof returnItems = {};
    loan.items.forEach((it) => {
      const sisa = it.jumlahPinjam - (it.jumlahKembaliBaik + it.jumlahKembaliRusak);
      initialMap[it.kodeBarang] = {
        jumlahKembali: sisa > 0 ? sisa : 0,
        kondisi: 'Baik',
        keteranganRusak: '',
      };
    });
    setReturnItems(initialMap);
  };

  const handleUpdateItemReturn = (
    kodeBarang: string,
    field: 'jumlahKembali' | 'kondisi' | 'keteranganRusak',
    value: any
  ) => {
    setReturnItems((prev) => ({
      ...prev,
      [kodeBarang]: {
        ...prev[kodeBarang],
        [field]: value,
      },
    }));
  };

  const handleSubmitReturn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLoan) {
      alert('Pilih transaksi peminjaman terlebih dahulu!');
      return;
    }

    const itemsToProcess = Object.entries(returnItems)
      .map(([kodeBarang, itemData]) => {
        const pItem = selectedLoan.items.find((it) => it.kodeBarang === kodeBarang);
        return {
          kodeBarang,
          namaBarang: pItem?.namaBarang || '',
          satuan: pItem?.satuan || 'Pcs',
          jumlahKembali: Number(itemData.jumlahKembali || 0),
          kondisi: itemData.kondisi,
          keteranganRusak: itemData.keteranganRusak,
        };
      })
      .filter((it) => it.jumlahKembali > 0);

    if (itemsToProcess.length === 0) {
      alert('Masukkan jumlah kembali minimal 1 item!');
      return;
    }

    // Validate if damaged, must specify damage notes
    for (const it of itemsToProcess) {
      if (it.kondisi === 'Rusak' && !it.keteranganRusak?.trim()) {
        alert(`Harap isi keterangan kerusakan untuk ${it.namaBarang}!`);
        return;
      }
    }

    onProcessPengembalian({
      peminjamanId: selectedLoan.id,
      tanggalKembali,
      items: itemsToProcess,
    });

    // Reset selection
    setSelectedLoanId('');
    setReturnItems({});
  };

  // Filtered return history
  const filteredHistory = pengembalianList.filter(
    (k) =>
      k.noPengembalian.toLowerCase().includes(searchTerm.toLowerCase()) ||
      k.noTransaksiPinjam.toLowerCase().includes(searchTerm.toLowerCase()) ||
      k.namaPeminjam.toLowerCase().includes(searchTerm.toLowerCase()) ||
      k.items.some((it) => it.namaBarang.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleExport = () => {
    const exportRows: any[] = [];
    pengembalianList.forEach((k) => {
      k.items.forEach((it) => {
        exportRows.push({
          'No Pengembalian': k.noPengembalian,
          'No Peminjaman': k.noTransaksiPinjam,
          'Tanggal Kembali': k.tanggalKembali,
          'Nama Peminjam': k.namaPeminjam,
          'Penanggung Jawab': k.penanggungJawab,
          'Kode Barang': it.kodeBarang,
          'Nama Barang': it.namaBarang,
          'Jumlah Kembali': it.jumlahKembali,
          'Kondisi': it.kondisi,
          'Keterangan Kerusakan': it.keteranganRusak || '-',
          'Dicatat Oleh': k.dicatatOleh,
        });
      });
    });
    exportToCSV('Laporan_Pengembalian_Hariklin', exportRows);
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Pengembalian Alat & Mesin</h1>
            <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
              {activeLoans.length} Peminjaman Menunggu Selesai
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Proses pengembalian bertahap: Kembali Baik (otomatis aktif) &amp; Kembali Rusak (masuk ke menu Barang Rusak)
          </p>
        </div>

        <button
          onClick={handleExport}
          className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold border border-slate-200 transition-colors"
        >
          <FileSpreadsheet className="w-3.5 h-3.5" />
          <span>Export Riwayat CSV</span>
        </button>
      </div>

      {/* FORM PENGEMBALIAN */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="pb-3 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-emerald-600" />
              <span>Input Pengembalian Alat (Bertahap &amp; Kondisi)</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Pilih transaksi peminjaman aktif di bawah ini untuk mencatat unit yang kembali
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmitReturn} className="mt-4 space-y-4 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Pilih Transaksi Peminjaman *
              </label>
              <select
                required
                value={selectedLoanId}
                onChange={(e) => handleSelectLoan(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs bg-white focus:ring-2 focus:ring-emerald-500/20"
              >
                <option value="">-- Pilih Transaksi Pinjaman Aktif --</option>
                {activeLoans.map((loan) => (
                  <option key={loan.id} value={loan.id}>
                    [{loan.noTransaksi}] - {loan.namaPeminjam} ({loan.keperluan}) - Tgl Pinjam: {loan.tanggalPinjam}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Tanggal Pengembalian Fisik</label>
              <input
                type="date"
                required
                value={tanggalKembali}
                onChange={(e) => setTanggalKembali(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
              />
            </div>
          </div>

          {/* If loan selected, show detail item checkers */}
          {selectedLoan && (
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-200">
                <div>
                  <span className="font-semibold text-slate-900 text-xs">
                    Rincian Alat Transaksi: {selectedLoan.noTransaksi}
                  </span>
                  <div className="text-[11px] text-slate-500">
                    Peminjam: <strong className="text-slate-800">{selectedLoan.namaPeminjam}</strong> &middot; PJ: {selectedLoan.penanggungJawab}
                  </div>
                </div>
                <div className="text-[11px] text-slate-600 bg-white px-2.5 py-1 rounded border border-slate-200">
                  Keperluan: {selectedLoan.keperluan}
                </div>
              </div>

              {/* Items Table in Loan */}
              <div className="space-y-3">
                {selectedLoan.items.map((it) => {
                  const sisa = it.jumlahPinjam - (it.jumlahKembaliBaik + it.jumlahKembaliRusak);
                  const itemState = returnItems[it.kodeBarang] || {
                    jumlahKembali: 0,
                    kondisi: 'Baik',
                    keteranganRusak: '',
                  };

                  return (
                    <div
                      key={it.kodeBarang}
                      className="p-3 bg-white rounded-lg border border-slate-200 space-y-2.5"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs">
                        <div>
                          <span className="font-mono font-bold text-slate-900">[{it.kodeBarang}]</span>{' '}
                          <span className="font-semibold text-slate-800">{it.namaBarang}</span>
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-500 font-mono">
                          <span>Total Pinjam: {it.jumlahPinjam}</span>
                          <span>&middot;</span>
                          <span className="text-emerald-700">Kembali: {it.jumlahKembaliBaik + it.jumlahKembaliRusak}</span>
                          <span>&middot;</span>
                          <span className="text-blue-700 font-bold">Sisa Pinjam: {sisa} {it.satuan}</span>
                        </div>
                      </div>

                      {sisa <= 0 ? (
                        <div className="text-emerald-700 font-medium text-[11px] flex items-center gap-1 bg-emerald-50 px-2 py-1 rounded border border-emerald-200">
                          <Check className="w-3.5 h-3.5" />
                          <span>Semua unit barang ini sudah lengkap dikembalikan.</span>
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-1">
                          {/* Qty to return */}
                          <div className="sm:col-span-3">
                            <label className="block text-[11px] text-slate-600 mb-0.5">Jumlah Dikembalikan</label>
                            <input
                              type="number"
                              min="0"
                              max={sisa}
                              value={itemState.jumlahKembali}
                              onChange={(e) =>
                                handleUpdateItemReturn(
                                  it.kodeBarang,
                                  'jumlahKembali',
                                  Math.min(sisa, Math.max(0, Number(e.target.value)))
                                )
                              }
                              className="w-full px-2.5 py-1.5 rounded border border-slate-300 font-mono text-xs font-bold text-slate-800"
                            />
                          </div>

                          {/* Condition */}
                          <div className="sm:col-span-4">
                            <label className="block text-[11px] text-slate-600 mb-0.5">Kondisi Barang</label>
                            <div className="flex items-center gap-2">
                              <label
                                className={`flex items-center gap-1.5 px-3 py-1.5 rounded cursor-pointer border text-xs font-semibold transition-colors flex-1 justify-center ${
                                  itemState.kondisi === 'Baik'
                                    ? 'bg-emerald-50 border-emerald-500 text-emerald-800'
                                    : 'bg-white border-slate-200 text-slate-600'
                                }`}
                              >
                                <input
                                  type="radio"
                                  name={`kondisi_${it.kodeBarang}`}
                                  checked={itemState.kondisi === 'Baik'}
                                  onChange={() =>
                                    handleUpdateItemReturn(it.kodeBarang, 'kondisi', 'Baik')
                                  }
                                  className="sr-only"
                                />
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                <span>Kembali Baik</span>
                              </label>

                              <label
                                className={`flex items-center gap-1.5 px-3 py-1.5 rounded cursor-pointer border text-xs font-semibold transition-colors flex-1 justify-center ${
                                  itemState.kondisi === 'Rusak'
                                    ? 'bg-rose-50 border-rose-500 text-rose-800'
                                    : 'bg-white border-slate-200 text-slate-600'
                                }`}
                              >
                                <input
                                  type="radio"
                                  name={`kondisi_${it.kodeBarang}`}
                                  checked={itemState.kondisi === 'Rusak'}
                                  onChange={() =>
                                    handleUpdateItemReturn(it.kodeBarang, 'kondisi', 'Rusak')
                                  }
                                  className="sr-only"
                                />
                                <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                                <span>Kembali Rusak</span>
                              </label>
                            </div>
                          </div>

                          {/* Notes if damaged */}
                          <div className="sm:col-span-5">
                            <label className="block text-[11px] text-slate-600 mb-0.5">
                              {itemState.kondisi === 'Rusak' ? (
                                <span className="text-rose-600 font-semibold">Keterangan Kerusakan (Wajib) *</span>
                              ) : (
                                <span>Keterangan / Kondisi</span>
                              )}
                            </label>
                            <input
                              type="text"
                              placeholder={
                                itemState.kondisi === 'Rusak'
                                  ? 'Contoh: Dinamo terbakar, nozzle patah, dll'
                                  : 'Kondisi normal siap pakai'
                              }
                              value={itemState.keteranganRusak}
                              onChange={(e) =>
                                handleUpdateItemReturn(it.kodeBarang, 'keteranganRusak', e.target.value)
                              }
                              className={`w-full px-2.5 py-1.5 rounded border text-xs ${
                                itemState.kondisi === 'Rusak'
                                  ? 'border-rose-300 bg-rose-50/30'
                                  : 'border-slate-300'
                              }`}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Submit Button */}
              <div className="pt-2 flex items-center justify-between border-t border-slate-200">
                <span className="text-xs text-slate-500">
                  Kembali Baik: otomatis menambah stok aktif &middot; Kembali Rusak: masuk ke Barang Rusak
                </span>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-xs"
                >
                  Simpan Pengembalian &amp; Perbarui Status Stok
                </button>
              </div>
            </div>
          )}
        </form>
      </div>

      {/* RIWAYAT TRANSAKSI PENGEMBALIAN */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari nomor pengembalian, peminjam, barang..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500/20"
            />
          </div>

          <div className="text-xs text-slate-500">
            Menampilkan <strong className="text-slate-800">{filteredHistory.length}</strong> transaksi pengembalian
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                <th className="py-3 px-3">No Pengembalian</th>
                <th className="py-3 px-3">No Peminjaman</th>
                <th className="py-3 px-3">Peminjam</th>
                <th className="py-3 px-3">Tgl Kembali</th>
                <th className="py-3 px-3">Rincian Barang Kembali</th>
                <th className="py-3 px-3">Dicatat Oleh</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredHistory.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    Belum ada riwayat pengembalian yang tercatat.
                  </td>
                </tr>
              ) : (
                filteredHistory.map((k) => (
                  <tr key={k.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-3 font-mono font-bold text-emerald-800">{k.noPengembalian}</td>
                    <td className="py-3 px-3 font-mono text-slate-700">{k.noTransaksiPinjam}</td>
                    <td className="py-3 px-3">
                      <div className="font-semibold text-slate-900">{k.namaPeminjam}</div>
                      <div className="text-[11px] text-slate-500">PJ: {k.penanggungJawab}</div>
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-600">{k.tanggalKembali}</td>
                    <td className="py-3 px-3">
                      <div className="space-y-1">
                        {k.items.map((it, idx) => (
                          <div key={idx} className="flex items-center gap-1.5 text-[11px]">
                            <span className="font-mono font-semibold text-slate-800">{it.jumlahKembali} {it.satuan}</span>
                            <span className="text-slate-900 font-medium">{it.namaBarang}</span>
                            <span
                              className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${
                                it.kondisi === 'Baik'
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                  : 'bg-rose-50 text-rose-700 border border-rose-200'
                              }`}
                            >
                              {it.kondisi}
                            </span>
                            {it.keteranganRusak && (
                              <span className="text-slate-400 italic">({it.keteranganRusak})</span>
                            )}
                          </div>
                        ))}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-600">{k.dicatatOleh}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
