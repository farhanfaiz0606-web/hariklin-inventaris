import React from 'react';
import {
  Boxes,
  CheckCircle2,
  ArrowUpRight,
  AlertTriangle,
  Wrench,
  ShoppingCart,
  PackagePlus,
  Repeat,
  RotateCcw,
  Clock,
  ChevronRight,
  Plus,
} from 'lucide-react';
import {
  MasterBarang,
  Peminjaman,
  Pengembalian,
  BarangMasuk,
  BarangRusak,
  Perbaikan,
  Pembelian,
  StockOpname,
} from '../types';
import { NavMenuKey } from '../components/Sidebar';

interface DashboardViewProps {
  masterBarang: MasterBarang[];
  peminjaman: Peminjaman[];
  pengembalian: Pengembalian[];
  barangMasuk: BarangMasuk[];
  barangRusak: BarangRusak[];
  perbaikan: Perbaikan[];
  pembelian: Pembelian[];
  stockOpname: StockOpname[];
  onNavigate: (menu: NavMenuKey) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  masterBarang,
  peminjaman,
  pengembalian,
  barangMasuk,
  barangRusak,
  perbaikan,
  pembelian,
  onNavigate,
}) => {
  // Compute the 9 core dashboard statistics
  const totalJenisBarang = masterBarang.length;
  const totalStokAktif = masterBarang.reduce((acc, it) => acc + (it.stokAktif || 0), 0);
  const totalDipinjam = masterBarang.reduce((acc, it) => acc + (it.dipinjam || 0), 0);
  const totalRusak = masterBarang.reduce((acc, it) => acc + (it.rusak || 0), 0);
  const totalPerbaikan = masterBarang.reduce((acc, it) => acc + (it.perbaikan || 0), 0);
  const totalMenungguBeli = masterBarang.reduce((acc, it) => acc + (it.menungguBeli || 0), 0);

  const totalBarangMasukQty = barangMasuk.reduce((acc, it) => acc + (it.jumlahMasuk || 0), 0);
  const totalTransaksiPinjam = peminjaman.length;
  
  // Total barang yang sudah kembali
  const totalSudahKembali = pengembalian.reduce((acc, it) => {
    const sum = it.items.reduce((s, i) => s + (i.jumlahKembali || 0), 0);
    return acc + sum;
  }, 0);

  // Compute alerts
  const today = new Date().toISOString().split('T')[0];
  const pinjamBelumKembali = peminjaman.filter(
    (p) => p.status !== 'Selesai' && p.tanggalRencanaKembali && p.tanggalRencanaKembali < today
  );
  const perbaikanPending = perbaikan.filter(
    (p) => p.status === 'Menunggu Persetujuan' || p.status === 'Menunggu Persetujuan Selesai'
  );
  const pembelianPending = pembelian.filter(
    (p) => p.status === 'Menunggu Persetujuan' || p.status === 'Belum Dibeli'
  );

  // Total inventory units in warehouse
  const totalUnitFisik = totalStokAktif + totalDipinjam + totalRusak + totalPerbaikan + totalMenungguBeli;

  const getPercentage = (val: number) => {
    if (totalUnitFisik <= 0) return 0;
    return Math.round((val / totalUnitFisik) * 100);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Quick Actions */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            Ringkasan Operasional & Inventaris Gudang
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Data inventaris real-time terhubung langsung dengan Google Spreadsheet Hariklin
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => onNavigate('peminjaman')}
            className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Pinjam Alat</span>
          </button>
          <button
            onClick={() => onNavigate('barangMasuk')}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <PackagePlus className="w-3.5 h-3.5" />
            <span>Barang Masuk</span>
          </button>
          <button
            onClick={() => onNavigate('pengembalian')}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-semibold transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Proses Kembali</span>
          </button>
        </div>
      </div>

      {/* 9 Core Statistic Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3.5">
        {/* 1. Total Jenis Barang */}
        <div
          onClick={() => onNavigate('masterBarang')}
          className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs hover:border-slate-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Total Jenis Barang</span>
            <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-700 group-hover:bg-slate-900 group-hover:text-white transition-colors">
              <Boxes className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900 tabular-nums">
              {totalJenisBarang}
            </span>
            <span className="text-xs text-slate-500">Item Master</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400 flex items-center gap-1">
            <span>Lihat katalog</span>
            <ChevronRight className="w-3 h-3" />
          </div>
        </div>

        {/* 2. Total Stok Aktif */}
        <div
          onClick={() => onNavigate('masterBarang')}
          className="bg-white rounded-xl border border-emerald-200 p-4 shadow-xs hover:border-emerald-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-emerald-800">Stok Barang Aktif</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-emerald-600 tabular-nums">
              {totalStokAktif}
            </span>
            <span className="text-xs text-emerald-700/80">Unit Siap Pakai</span>
          </div>
          <div className="mt-2 text-[11px] text-emerald-600 font-medium">
            {getPercentage(totalStokAktif)}% dari total aset
          </div>
        </div>

        {/* 3. Sedang Dipinjam */}
        <div
          onClick={() => onNavigate('peminjaman')}
          className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs hover:border-slate-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-600">Sedang Dipinjam</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-blue-600 tabular-nums">
              {totalDipinjam}
            </span>
            <span className="text-xs text-slate-500">Unit di Lapangan</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500">
            {peminjaman.filter((p) => p.status !== 'Selesai').length} transaksi aktif
          </div>
        </div>

        {/* 4. Total Barang Rusak */}
        <div
          onClick={() => onNavigate('barangRusak')}
          className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs hover:border-rose-200 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-600">Barang Rusak</span>
            <div className="w-8 h-8 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center group-hover:bg-rose-600 group-hover:text-white transition-colors">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-rose-600 tabular-nums">
              {totalRusak}
            </span>
            <span className="text-xs text-slate-500">Unit Non-Aktif</span>
          </div>
          <div className="mt-2 text-[11px] text-rose-600">
            Perlu perbaikan / beli
          </div>
        </div>

        {/* 5. Dalam Perbaikan */}
        <div
          onClick={() => onNavigate('perbaikan')}
          className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs hover:border-amber-200 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-600">Dalam Perbaikan</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center group-hover:bg-amber-600 group-hover:text-white transition-colors">
              <Wrench className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-amber-600 tabular-nums">
              {totalPerbaikan}
            </span>
            <span className="text-xs text-slate-500">Unit Sedang Diservis</span>
          </div>
          <div className="mt-2 text-[11px] text-amber-700">
            {perbaikan.filter((p) => p.status === 'Sementara Pengerjaan').length} sedang dikerjakan
          </div>
        </div>

        {/* 6. Menunggu Pembelian */}
        <div
          onClick={() => onNavigate('pembelian')}
          className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs hover:border-purple-200 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-600">Menunggu Pembelian</span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white transition-colors">
              <ShoppingCart className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-purple-600 tabular-nums">
              {totalMenungguBeli}
            </span>
            <span className="text-xs text-slate-500">Unit Pengadaan</span>
          </div>
          <div className="mt-2 text-[11px] text-purple-600">
            {pembelian.filter((p) => p.status !== 'Sudah Dibeli' && p.status !== 'Ditolak').length} pengajuan
          </div>
        </div>

        {/* 7. Total Barang Masuk */}
        <div
          onClick={() => onNavigate('barangMasuk')}
          className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs hover:border-slate-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-600">Total Barang Masuk</span>
            <div className="w-8 h-8 rounded-lg bg-teal-50 text-teal-600 flex items-center justify-center group-hover:bg-teal-600 group-hover:text-white transition-colors">
              <PackagePlus className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-teal-600 tabular-nums">
              {totalBarangMasukQty}
            </span>
            <span className="text-xs text-slate-500">Unit Diterima</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500">
            {barangMasuk.length} riwayat pengiriman
          </div>
        </div>

        {/* 8. Total Transaksi Peminjaman */}
        <div
          onClick={() => onNavigate('peminjaman')}
          className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs hover:border-slate-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-600">Transaksi Pinjam</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-colors">
              <Repeat className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-indigo-600 tabular-nums">
              {totalTransaksiPinjam}
            </span>
            <span className="text-xs text-slate-500">Surat Jalan</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500">
            Riwayat peminjaman alat
          </div>
        </div>

        {/* 9. Total Barang Sudah Kembali */}
        <div
          onClick={() => onNavigate('pengembalian')}
          className="col-span-2 md:col-span-1 bg-white rounded-xl border border-slate-200 p-4 shadow-xs hover:border-slate-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-600">Barang Kembali</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <RotateCcw className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-emerald-700 tabular-nums">
              {totalSudahKembali}
            </span>
            <span className="text-xs text-slate-500">Unit Kembali</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500">
            {pengembalian.length} proses pengembalian
          </div>
        </div>
      </div>

      {/* Actionable Notification Banners */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Notifikasi Peminjaman Jatuh Tempo / Belum Kembali */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-amber-500" />
                Jatuh Tempo Pengembalian
              </span>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-amber-50 text-amber-700 font-semibold border border-amber-200">
                {pinjamBelumKembali.length} Perhatian
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-2">
              {pinjamBelumKembali.length > 0
                ? `${pinjamBelumKembali.length} transaksi peminjaman telah melampaui tanggal rencana kembali.`
                : 'Semua alat pinjaman dalam masa sewa/kerja normal.'}
            </p>
          </div>
          {pinjamBelumKembali.length > 0 && (
            <button
              onClick={() => onNavigate('pengembalian')}
              className="mt-3 text-xs text-amber-700 font-semibold hover:text-amber-800 flex items-center gap-1"
            >
              <span>Proses pengembalian</span>
              <ChevronRight className="w-3 h-3" />
            </button>
          )}
        </div>

        {/* Notifikasi Perbaikan Belum Selesai */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Wrench className="w-4 h-4 text-blue-500" />
                Antrean Servis & Perbaikan
              </span>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-semibold border border-blue-200">
                {perbaikanPending.length} Menunggu
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-2">
              {perbaikanPending.length > 0
                ? `${perbaikanPending.length} tiket perbaikan membutuhkan persetujuan atau verifikasi ACC Admin.`
                : 'Tidak ada tiket perbaikan yang tertunda.'}
            </p>
          </div>
          {perbaikanPending.length > 0 && (
            <button
              onClick={() => onNavigate('perbaikan')}
              className="mt-3 text-xs text-blue-700 font-semibold hover:text-blue-800 flex items-center gap-1"
            >
              <span>Tinjau perbaikan</span>
              <ChevronRight className="w-3 h-3" />
            </button>
          )}
        </div>

        {/* Notifikasi Pembelian Belum Dilakukan */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <ShoppingCart className="w-4 h-4 text-purple-500" />
                Pengadaan & Pembelian
              </span>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-purple-50 text-purple-700 font-semibold border border-purple-200">
                {pembelianPending.length} Menunggu
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-2">
              {pembelianPending.length > 0
                ? `${pembelianPending.length} barang rusak membutuhkan tindak lanjut pembelian pengganti.`
                : 'Semua permintaan pembelian telah diselesaikan.'}
            </p>
          </div>
          {pembelianPending.length > 0 && (
            <button
              onClick={() => onNavigate('pembelian')}
              className="mt-3 text-xs text-purple-700 font-semibold hover:text-purple-800 flex items-center gap-1"
            >
              <span>Tinjau pembelian</span>
              <ChevronRight className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>

      {/* Visual Charts & Breakdown Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Kondisi Inventaris Breakdown (2 Columns) */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Proporsi Kondisi Inventaris Gudang</h2>
              <p className="text-xs text-slate-500">Distribusi status seluruh unit barang fisik ({totalUnitFisik} unit)</p>
            </div>
            <span className="text-xs font-mono font-medium text-slate-600 bg-slate-100 px-2.5 py-1 rounded-md">
              100% Tercatat
            </span>
          </div>

          {/* Progress Stack Bar */}
          <div className="h-4 w-full bg-slate-100 rounded-full overflow-hidden flex shadow-inner">
            <div
              style={{ width: `${getPercentage(totalStokAktif)}%` }}
              className="bg-emerald-500 h-full transition-all"
              title={`Stok Aktif: ${totalStokAktif} unit (${getPercentage(totalStokAktif)}%)`}
            />
            <div
              style={{ width: `${getPercentage(totalDipinjam)}%` }}
              className="bg-blue-500 h-full transition-all"
              title={`Dipinjam: ${totalDipinjam} unit (${getPercentage(totalDipinjam)}%)`}
            />
            <div
              style={{ width: `${getPercentage(totalRusak)}%` }}
              className="bg-rose-500 h-full transition-all"
              title={`Rusak: ${totalRusak} unit (${getPercentage(totalRusak)}%)`}
            />
            <div
              style={{ width: `${getPercentage(totalPerbaikan)}%` }}
              className="bg-amber-500 h-full transition-all"
              title={`Perbaikan: ${totalPerbaikan} unit (${getPercentage(totalPerbaikan)}%)`}
            />
            <div
              style={{ width: `${getPercentage(totalMenungguBeli)}%` }}
              className="bg-purple-500 h-full transition-all"
              title={`Menunggu Beli: ${totalMenungguBeli} unit (${getPercentage(totalMenungguBeli)}%)`}
            />
          </div>

          {/* Breakdown Items */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-5">
            <div className="p-3 rounded-lg bg-emerald-50/50 border border-emerald-100">
              <div className="flex items-center gap-1.5 text-xs text-emerald-800 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
                <span>Stok Aktif</span>
              </div>
              <div className="text-lg font-bold text-slate-900 mt-1 tabular-nums">{totalStokAktif}</div>
              <div className="text-[11px] text-slate-500">{getPercentage(totalStokAktif)}% dari total</div>
            </div>

            <div className="p-3 rounded-lg bg-blue-50/50 border border-blue-100">
              <div className="flex items-center gap-1.5 text-xs text-blue-800 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500 shrink-0" />
                <span>Dipinjam</span>
              </div>
              <div className="text-lg font-bold text-slate-900 mt-1 tabular-nums">{totalDipinjam}</div>
              <div className="text-[11px] text-slate-500">{getPercentage(totalDipinjam)}% dari total</div>
            </div>

            <div className="p-3 rounded-lg bg-rose-50/50 border border-rose-100">
              <div className="flex items-center gap-1.5 text-xs text-rose-800 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shrink-0" />
                <span>Rusak</span>
              </div>
              <div className="text-lg font-bold text-slate-900 mt-1 tabular-nums">{totalRusak}</div>
              <div className="text-[11px] text-slate-500">{getPercentage(totalRusak)}% dari total</div>
            </div>

            <div className="p-3 rounded-lg bg-amber-50/50 border border-amber-100">
              <div className="flex items-center gap-1.5 text-xs text-amber-800 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0" />
                <span>Perbaikan</span>
              </div>
              <div className="text-lg font-bold text-slate-900 mt-1 tabular-nums">{totalPerbaikan}</div>
              <div className="text-[11px] text-slate-500">{getPercentage(totalPerbaikan)}% dari total</div>
            </div>

            <div className="p-3 rounded-lg bg-purple-50/50 border border-purple-100">
              <div className="flex items-center gap-1.5 text-xs text-purple-800 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-500 shrink-0" />
                <span>Menunggu Beli</span>
              </div>
              <div className="text-lg font-bold text-slate-900 mt-1 tabular-nums">{totalMenungguBeli}</div>
              <div className="text-[11px] text-slate-500">{getPercentage(totalMenungguBeli)}% dari total</div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500 flex items-center justify-between">
            <span>Aturan: Barang rusak & perbaikan tidak dihitung sebagai stok aktif.</span>
            <button
              onClick={() => onNavigate('masterBarang')}
              className="text-emerald-600 hover:text-emerald-700 font-semibold"
            >
              Lihat Detail Master &rarr;
            </button>
          </div>
        </div>

        {/* Pergerakan Barang Masuk & Keluar (1 Column) */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Arus Logistik Barang</h2>
            <p className="text-xs text-slate-500 mt-0.5">Perbandingan volume sirkulasi barang</p>

            <div className="space-y-4 mt-5">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-medium text-slate-700">Barang Masuk (Penerimaan)</span>
                  <span className="font-bold text-emerald-600 font-mono">{totalBarangMasukQty} Unit</span>
                </div>
                <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div
                    style={{
                      width: `${Math.min(100, (totalBarangMasukQty / (totalBarangMasukQty + totalDipinjam || 1)) * 100)}%`,
                    }}
                    className="h-full bg-emerald-500"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-medium text-slate-700">Peminjaman (Keluar Lapangan)</span>
                  <span className="font-bold text-blue-600 font-mono">{totalDipinjam} Unit</span>
                </div>
                <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div
                    style={{
                      width: `${Math.min(100, (totalDipinjam / (totalBarangMasukQty + totalDipinjam || 1)) * 100)}%`,
                    }}
                    className="h-full bg-blue-500"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-medium text-slate-700">Pengembalian (Kembali Gudang)</span>
                  <span className="font-bold text-teal-600 font-mono">{totalSudahKembali} Unit</span>
                </div>
                <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div
                    style={{
                      width: `${Math.min(100, (totalSudahKembali / (totalDipinjam + totalSudahKembali || 1)) * 100)}%`,
                    }}
                    className="h-full bg-teal-500"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-5 p-3 rounded-lg bg-slate-50 border border-slate-200/60 text-xs text-slate-600">
            <span className="font-semibold text-slate-800">Tips Operasional:</span> Pastikan setiap alat yang keluar terbit dengan nomor Surat Jalan dan dicek fisiknya saat kembali.
          </div>
        </div>
      </div>

      {/* Riwayat Transaksi Terbaru */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Riwayat Transaksi Terbaru</h2>
            <p className="text-xs text-slate-500">Aktivitas peminjaman dan arus logistik mutakhir</p>
          </div>
          <button
            onClick={() => onNavigate('laporan')}
            className="text-xs text-emerald-600 hover:text-emerald-700 font-semibold"
          >
            Lihat Semua Laporan &rarr;
          </button>
        </div>

        {peminjaman.length === 0 && barangMasuk.length === 0 ? (
          <div className="text-center py-8 text-slate-400 text-xs">
            Belum ada transaksi terekam. Klik tombol "Pinjam Alat" atau "Barang Masuk" di atas untuk memulai.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 uppercase tracking-wider font-semibold">
                  <th className="py-2.5 px-3">No Transaksi</th>
                  <th className="py-2.5 px-3">Tipe</th>
                  <th className="py-2.5 px-3">Peminjam / Sumber</th>
                  <th className="py-2.5 px-3">Penanggung Jawab</th>
                  <th className="py-2.5 px-3">Jumlah Item</th>
                  <th className="py-2.5 px-3">Tanggal</th>
                  <th className="py-2.5 px-3 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {peminjaman.slice(0, 5).map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-3 font-mono font-semibold text-slate-900">{p.noTransaksi}</td>
                    <td className="py-3 px-3">
                      <span className="text-[11px] px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-medium border border-blue-100">
                        Peminjaman
                      </span>
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-800">{p.namaPeminjam}</td>
                    <td className="py-3 px-3 text-slate-600">{p.penanggungJawab}</td>
                    <td className="py-3 px-3 text-slate-600">{p.items.length} jenis alat</td>
                    <td className="py-3 px-3 text-slate-500 font-mono">{p.tanggalPinjam}</td>
                    <td className="py-3 px-3 text-right">
                      <span
                        className={`text-[11px] px-2 py-0.5 rounded font-semibold ${
                          p.status === 'Selesai'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : p.status === 'Sebagian'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : 'bg-blue-50 text-blue-700 border border-blue-200'
                        }`}
                      >
                        {p.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
