import {
  MasterBarang,
  Peminjaman,
  Pengembalian,
  BarangMasuk,
  BarangRusak,
  Perbaikan,
  Pembelian,
  StockOpname,
  User,
  LogAktivitas,
  GoogleSheetsConfig,
  StatusPerbaikan,
  StatusPembelian,
} from '../types';
import {
  INITIAL_MASTER_BARANG,
  INITIAL_BARANG_RUSAK,
  INITIAL_USERS,
} from '../data/initialCatalog';

const STORAGE_KEYS = {
  MASTER: 'hariklin_master_barang',
  MASUK: 'hariklin_barang_masuk',
  PINJAM: 'hariklin_peminjaman',
  KEMBALI: 'hariklin_pengembalian',
  RUSAK: 'hariklin_barang_rusak',
  PERBAIKAN: 'hariklin_perbaikan',
  BELI: 'hariklin_pembelian',
  OPNAME: 'hariklin_stock_opname',
  USERS: 'hariklin_users',
  LOGS: 'hariklin_logs',
  CURRENT_USER: 'hariklin_current_user',
  GSHEETS_CONFIG: 'hariklin_gsheets_config',
};

export class StorageService {
  // Load data or initialize defaults
  static getMasterBarang(): MasterBarang[] {
    const raw = localStorage.getItem(STORAGE_KEYS.MASTER);
    if (!raw) {
      this.setMasterBarang(INITIAL_MASTER_BARANG);
      return INITIAL_MASTER_BARANG;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_MASTER_BARANG;
    }
  }

  static setMasterBarang(data: MasterBarang[]) {
    localStorage.setItem(STORAGE_KEYS.MASTER, JSON.stringify(data));
  }

  static getPeminjaman(): Peminjaman[] {
    const raw = localStorage.getItem(STORAGE_KEYS.PINJAM);
    return raw ? JSON.parse(raw) : [];
  }

  static setPeminjaman(data: Peminjaman[]) {
    localStorage.setItem(STORAGE_KEYS.PINJAM, JSON.stringify(data));
  }

  static getPengembalian(): Pengembalian[] {
    const raw = localStorage.getItem(STORAGE_KEYS.KEMBALI);
    return raw ? JSON.parse(raw) : [];
  }

  static setPengembalian(data: Pengembalian[]) {
    localStorage.setItem(STORAGE_KEYS.KEMBALI, JSON.stringify(data));
  }

  static getBarangMasuk(): BarangMasuk[] {
    const raw = localStorage.getItem(STORAGE_KEYS.MASUK);
    return raw ? JSON.parse(raw) : [];
  }

  static setBarangMasuk(data: BarangMasuk[]) {
    localStorage.setItem(STORAGE_KEYS.MASUK, JSON.stringify(data));
  }

  static getBarangRusak(): BarangRusak[] {
    const raw = localStorage.getItem(STORAGE_KEYS.RUSAK);
    if (!raw) {
      this.setBarangRusak(INITIAL_BARANG_RUSAK);
      return INITIAL_BARANG_RUSAK;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_BARANG_RUSAK;
    }
  }

  static setBarangRusak(data: BarangRusak[]) {
    localStorage.setItem(STORAGE_KEYS.RUSAK, JSON.stringify(data));
  }

  static getPerbaikan(): Perbaikan[] {
    const raw = localStorage.getItem(STORAGE_KEYS.PERBAIKAN);
    return raw ? JSON.parse(raw) : [];
  }

  static setPerbaikan(data: Perbaikan[]) {
    localStorage.setItem(STORAGE_KEYS.PERBAIKAN, JSON.stringify(data));
  }

  static getPembelian(): Pembelian[] {
    const raw = localStorage.getItem(STORAGE_KEYS.BELI);
    return raw ? JSON.parse(raw) : [];
  }

  static setPembelian(data: Pembelian[]) {
    localStorage.setItem(STORAGE_KEYS.BELI, JSON.stringify(data));
  }

  static getStockOpname(): StockOpname[] {
    const raw = localStorage.getItem(STORAGE_KEYS.OPNAME);
    return raw ? JSON.parse(raw) : [];
  }

  static setStockOpname(data: StockOpname[]) {
    localStorage.setItem(STORAGE_KEYS.OPNAME, JSON.stringify(data));
  }

  static getUsers(): User[] {
    const raw = localStorage.getItem(STORAGE_KEYS.USERS);
    if (!raw) {
      this.setUsers(INITIAL_USERS);
      return INITIAL_USERS;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_USERS;
    }
  }

  static setUsers(data: User[]) {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(data));
  }

  static getCurrentUser(): User {
    const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    if (!raw) {
      const defaultUser = INITIAL_USERS[0];
      this.setCurrentUser(defaultUser);
      return defaultUser;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_USERS[0];
    }
  }

  static setCurrentUser(user: User | null) {
    if (!user) {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    } else {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    }
  }

  static getLogs(): LogAktivitas[] {
    const raw = localStorage.getItem(STORAGE_KEYS.LOGS);
    return raw ? JSON.parse(raw) : [];
  }

  static addLog(action: string, modul: string, detail: string, user: User) {
    const logs = this.getLogs();
    const newLog: LogAktivitas = {
      id: 'LOG-' + Date.now(),
      timestamp: new Date().toLocaleString('id-ID'),
      userId: user.id,
      username: user.namaLengkap || user.username,
      action,
      modul,
      detail,
    };
    logs.unshift(newLog);
    // keep max 500 logs
    if (logs.length > 500) logs.pop();
    localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(logs));
  }

  static getGSheetsConfig(): GoogleSheetsConfig {
    const raw = localStorage.getItem(STORAGE_KEYS.GSHEETS_CONFIG);
    if (raw) {
      try {
        return JSON.parse(raw);
      } catch {}
    }
    return {
      spreadsheetUrl: '',
      webAppUrl: '',
      isAutoSync: false,
      status: 'disconnected',
    };
  }

  static setGSheetsConfig(config: GoogleSheetsConfig) {
    localStorage.setItem(STORAGE_KEYS.GSHEETS_CONFIG, JSON.stringify(config));
  }

  // --- Reset to initial 75 items ---
  static resetToInitialCatalog(currentUser: User) {
    this.setMasterBarang(INITIAL_MASTER_BARANG);
    this.setBarangRusak(INITIAL_BARANG_RUSAK);
    this.setPeminjaman([]);
    this.setPengembalian([]);
    this.setBarangMasuk([]);
    this.setPerbaikan([]);
    this.setPembelian([]);
    this.setStockOpname([]);
    this.addLog('RESET_DATABASE', 'Master Barang', 'Mengembalikan database ke 75 inventaris awal bawaan PDF', currentUser);
  }

  // --- Transactions ---

  /**
   * Peminjaman Alat:
   * Validasi stok, kurangi stok aktif, tambah stok dipinjam
   */
  static createPeminjaman(
    data: Omit<Peminjaman, 'id' | 'noTransaksi' | 'createdAt' | 'status'>,
    currentUser: User
  ): { success: boolean; message: string; data?: Peminjaman } {
    const master = this.getMasterBarang();

    // 1. Validasi stok sebelum transaksi
    for (const item of data.items) {
      const brg = master.find((m) => m.kodeBarang === item.kodeBarang);
      if (!brg) {
        return { success: false, message: `Barang dengan kode ${item.kodeBarang} tidak ditemukan di Master Barang.` };
      }
      if (item.jumlahPinjam <= 0) {
        return { success: false, message: `Jumlah pinjam untuk ${brg.namaBarang} harus lebih dari 0.` };
      }
      if (item.jumlahPinjam > brg.stokAktif) {
        return {
          success: false,
          message: `Stok aktif tidak mencukupi untuk ${brg.namaBarang}. Tersedia: ${brg.stokAktif}, Diminta: ${item.jumlahPinjam}.`,
        };
      }
    }

    // 2. Potong stok aktif & tambahkan ke dipinjam
    for (const item of data.items) {
      const brg = master.find((m) => m.kodeBarang === item.kodeBarang)!;
      brg.stokAktif -= item.jumlahPinjam;
      brg.dipinjam += item.jumlahPinjam;
      brg.updatedAt = new Date().toISOString().split('T')[0];
    }
    this.setMasterBarang(master);

    // 3. Simpan transaksi peminjaman
    const count = this.getPeminjaman().length + 1;
    const yearMonth = new Date().toISOString().slice(2, 7).replace('-', '');
    const noTransaksi = `PINJ-${yearMonth}-${String(count).padStart(4, '0')}`;

    const newPinjam: Peminjaman = {
      id: 'PINJ-' + Date.now(),
      noTransaksi,
      tanggalPinjam: data.tanggalPinjam,
      tanggalRencanaKembali: data.tanggalRencanaKembali,
      namaPeminjam: data.namaPeminjam,
      penanggungJawab: data.penanggungJawab,
      keperluan: data.keperluan,
      keterangan: data.keterangan || '',
      status: 'Dipinjam',
      items: data.items.map((it) => ({
        ...it,
        jumlahKembaliBaik: 0,
        jumlahKembaliRusak: 0,
        statusItem: 'Dipinjam',
      })),
      dicatatOleh: currentUser.namaLengkap || currentUser.username,
      createdAt: new Date().toISOString(),
    };

    const pinjamList = this.getPeminjaman();
    pinjamList.unshift(newPinjam);
    this.setPeminjaman(pinjamList);

    this.addLog(
      'PEMINJAMAN_BARU',
      'Peminjaman Alat',
      `Transaksi ${noTransaksi} oleh ${data.namaPeminjam} (${data.items.length} jenis alat)`,
      currentUser
    );

    return { success: true, message: `Peminjaman ${noTransaksi} berhasil disimpan. Stok aktif otomatis berkurang.`, data: newPinjam };
  }

  /**
   * Pengembalian Alat:
   * Kembali Baik -> Tambah stok aktif, kurangi dipinjam
   * Kembali Rusak -> Tidak menambah stok aktif, kurangi dipinjam, masuk ke Barang Rusak
   */
  static processPengembalian(
    data: {
      peminjamanId: string;
      tanggalKembali: string;
      items: {
        kodeBarang: string;
        namaBarang: string;
        satuan: string;
        jumlahKembali: number;
        kondisi: 'Baik' | 'Rusak';
        keteranganRusak?: string;
      }[];
    },
    currentUser: User
  ): { success: boolean; message: string } {
    const pinjamList = this.getPeminjaman();
    const pinjam = pinjamList.find((p) => p.id === data.peminjamanId);
    if (!pinjam) {
      return { success: false, message: 'Transaksi peminjaman tidak ditemukan.' };
    }

    const master = this.getMasterBarang();
    const damagedList = this.getBarangRusak();

    for (const retItem of data.items) {
      if (retItem.jumlahKembali <= 0) continue;

      const pItem = pinjam.items.find((it) => it.kodeBarang === retItem.kodeBarang);
      if (!pItem) continue;

      const brg = master.find((m) => m.kodeBarang === retItem.kodeBarang);
      if (!brg) continue;

      const sisaPinjam = pItem.jumlahPinjam - (pItem.jumlahKembaliBaik + pItem.jumlahKembaliRusak);
      if (retItem.jumlahKembali > sisaPinjam) {
        return {
          success: false,
          message: `Jumlah pengembalian ${retItem.namaBarang} (${retItem.jumlahKembali}) melebihi sisa pinjaman (${sisaPinjam}).`,
        };
      }

      // Update counters in Peminjaman item
      if (retItem.kondisi === 'Baik') {
        pItem.jumlahKembaliBaik += retItem.jumlahKembali;
        // Kembali Baik -> tambah stok aktif
        brg.stokAktif += retItem.jumlahKembali;
        brg.dipinjam = Math.max(0, brg.dipinjam - retItem.jumlahKembali);
      } else {
        // Kembali Rusak -> tidak menambah stok aktif!
        pItem.jumlahKembaliRusak += retItem.jumlahKembali;
        brg.dipinjam = Math.max(0, brg.dipinjam - retItem.jumlahKembali);
        brg.rusak += retItem.jumlahKembali;

        // Otomatis masukkan ke daftar Barang Rusak
        const newDamaged: BarangRusak = {
          id: 'BR-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
          kodeBarang: brg.kodeBarang,
          namaBarang: brg.namaBarang,
          satuan: brg.satuan,
          jumlahRusak: retItem.jumlahKembali,
          tanggalKerusakan: data.tanggalKembali,
          sumberKerusakan: `Peminjaman ${pinjam.noTransaksi} (${pinjam.namaPeminjam})`,
          keterangan: retItem.keteranganRusak || 'Kerusakan saat peminjaman',
          statusPenanganan: 'Menunggu Keputusan',
          dicatatOleh: currentUser.namaLengkap || currentUser.username,
          createdAt: new Date().toISOString(),
        };
        damagedList.unshift(newDamaged);
      }

      // Check item status
      const totalReturned = pItem.jumlahKembaliBaik + pItem.jumlahKembaliRusak;
      if (totalReturned >= pItem.jumlahPinjam) {
        pItem.statusItem = 'Selesai';
      } else {
        pItem.statusItem = 'Sebagian';
      }
      brg.updatedAt = new Date().toISOString().split('T')[0];
    }

    // Check overall loan status
    const allDone = pinjam.items.every((it) => it.statusItem === 'Selesai');
    pinjam.status = allDone ? 'Selesai' : 'Sebagian';

    // Save Pengembalian transaction
    const kembCount = this.getPengembalian().length + 1;
    const yearMonth = new Date().toISOString().slice(2, 7).replace('-', '');
    const noPengembalian = `KEMB-${yearMonth}-${String(kembCount).padStart(4, '0')}`;

    const newKemb: Pengembalian = {
      id: 'KEMB-' + Date.now(),
      noPengembalian,
      peminjamanId: pinjam.id,
      noTransaksiPinjam: pinjam.noTransaksi,
      tanggalKembali: data.tanggalKembali,
      namaPeminjam: pinjam.namaPeminjam,
      penanggungJawab: pinjam.penanggungJawab,
      items: data.items.filter((i) => i.jumlahKembali > 0),
      dicatatOleh: currentUser.namaLengkap || currentUser.username,
      createdAt: new Date().toISOString(),
    };

    const kembList = this.getPengembalian();
    kembList.unshift(newKemb);

    this.setMasterBarang(master);
    this.setPeminjaman(pinjamList);
    this.setPengembalian(kembList);
    this.setBarangRusak(damagedList);

    this.addLog(
      'PENGEMBALIAN_PROSES',
      'Pengembalian Alat',
      `Pengembalian ${noPengembalian} untuk transaksi ${pinjam.noTransaksi} (Peminjam: ${pinjam.namaPeminjam})`,
      currentUser
    );

    return {
      success: true,
      message: `Pengembalian ${noPengembalian} berhasil diproses. ${
        data.items.some((i) => i.kondisi === 'Rusak')
          ? 'Barang rusak telah dialihkan ke menu Barang Rusak.'
          : 'Stok aktif telah diperbarui.'
      }`,
    };
  }

  /**
   * Barang Masuk:
   * Jika barang sudah ada, tambah stok aktif.
   * Jika barang baru, buat di Master Barang dan kode barang otomatis.
   */
  static processBarangMasuk(
    data: {
      kodeBarang?: string;
      namaBarang: string;
      kategori: string;
      satuan: string;
      jumlahMasuk: number;
      tanggalMasuk: string;
      sumberBarang: string;
      penanggungJawab: string;
      keterangan: string;
      notaFotoUrl?: string;
    },
    currentUser: User
  ): { success: boolean; message: string; item?: BarangMasuk } {
    if (data.jumlahMasuk <= 0) {
      return { success: false, message: 'Jumlah barang masuk harus lebih dari 0.' };
    }

    const master = this.getMasterBarang();
    let finalKodeBarang = data.kodeBarang?.trim();
    let isNewMaster = false;

    // Search if already exists in master by code or exact name
    let brg = master.find(
      (m) => (finalKodeBarang && m.kodeBarang.toLowerCase() === finalKodeBarang.toLowerCase()) ||
             m.namaBarang.toLowerCase() === data.namaBarang.trim().toLowerCase()
    );

    if (brg) {
      // Existing item: increase active and initial stock
      brg.stokAktif += data.jumlahMasuk;
      brg.stokAwal += data.jumlahMasuk;
      brg.updatedAt = new Date().toISOString().split('T')[0];
      finalKodeBarang = brg.kodeBarang;
    } else {
      // New item: create in master
      isNewMaster = true;
      if (!finalKodeBarang) {
        const nextNum = master.length + 1;
        finalKodeBarang = `BRG-${String(nextNum).padStart(3, '0')}`;
      }
      // Check duplicate code
      if (master.some((m) => m.kodeBarang.toLowerCase() === finalKodeBarang!.toLowerCase())) {
        return { success: false, message: `Kode barang ${finalKodeBarang} sudah digunakan!` };
      }

      const newMaster: MasterBarang = {
        id: finalKodeBarang,
        kodeBarang: finalKodeBarang,
        namaBarang: data.namaBarang.trim(),
        kategori: data.kategori || 'Alat Kebersihan & Sanitasi',
        satuan: data.satuan || 'Pcs',
        stokAwal: data.jumlahMasuk,
        stokAktif: data.jumlahMasuk,
        dipinjam: 0,
        rusak: 0,
        perbaikan: 0,
        menungguBeli: 0,
        keterangan: data.keterangan || 'Barang masuk baru',
        updatedAt: new Date().toISOString().split('T')[0],
      };
      master.push(newMaster);
    }

    this.setMasterBarang(master);

    // Save record in BarangMasuk
    const masukCount = this.getBarangMasuk().length + 1;
    const yearMonth = new Date().toISOString().slice(2, 7).replace('-', '');
    const noTransaksiMasuk = `BM-${yearMonth}-${String(masukCount).padStart(4, '0')}`;

    const newRecord: BarangMasuk = {
      id: 'BM-' + Date.now(),
      noTransaksiMasuk,
      kodeBarang: finalKodeBarang!,
      namaBarang: data.namaBarang.trim(),
      kategori: data.kategori,
      satuan: data.satuan,
      jumlahMasuk: data.jumlahMasuk,
      tanggalMasuk: data.tanggalMasuk,
      sumberBarang: data.sumberBarang,
      penanggungJawab: data.penanggungJawab,
      keterangan: data.keterangan,
      notaFotoUrl: data.notaFotoUrl,
      dicatatOleh: currentUser.namaLengkap || currentUser.username,
      createdAt: new Date().toISOString(),
    };

    const masukList = this.getBarangMasuk();
    masukList.unshift(newRecord);
    this.setBarangMasuk(masukList);

    this.addLog(
      'BARANG_MASUK',
      'Barang Masuk',
      `Penerimaan ${noTransaksiMasuk}: ${data.namaBarang} (+${data.jumlahMasuk} ${data.satuan}) dari ${data.sumberBarang}`,
      currentUser
    );

    return {
      success: true,
      message: `Barang Masuk ${noTransaksiMasuk} berhasil disimpan. ${
        isNewMaster ? 'Item baru otomatis ditambahkan ke Master Barang.' : 'Stok aktif barang berhasil ditambah.'
      }`,
      item: newRecord,
    };
  }

  /**
   * Alihkan Barang Rusak ke Perbaikan
   */
  static alihkanKePerbaikan(
    barangRusakId: string,
    payload: {
      penyebabKerusakan: string;
      keteranganPerbaikan: string;
      estimasiBiaya: number;
      namaPetugas: string;
    },
    currentUser: User
  ): { success: boolean; message: string } {
    const rusakList = this.getBarangRusak();
    const item = rusakList.find((r) => r.id === barangRusakId);
    if (!item) return { success: false, message: 'Barang rusak tidak ditemukan.' };

    const master = this.getMasterBarang();
    const brg = master.find((m) => m.kodeBarang === item.kodeBarang);
    if (brg) {
      brg.rusak = Math.max(0, brg.rusak - item.jumlahRusak);
      brg.perbaikan += item.jumlahRusak;
      brg.updatedAt = new Date().toISOString().split('T')[0];
      this.setMasterBarang(master);
    }

    const perbaikanCount = this.getPerbaikan().length + 1;
    const yearMonth = new Date().toISOString().slice(2, 7).replace('-', '');
    const noPerbaikan = `PBK-${yearMonth}-${String(perbaikanCount).padStart(4, '0')}`;

    const newPerbaikan: Perbaikan = {
      id: 'PBK-' + Date.now(),
      noPerbaikan,
      barangRusakId: item.id,
      kodeBarang: item.kodeBarang,
      namaBarang: item.namaBarang,
      satuan: item.satuan,
      jumlahBarang: item.jumlahRusak,
      tanggalKerusakan: item.tanggalKerusakan,
      penyebabKerusakan: payload.penyebabKerusakan,
      namaPetugas: payload.namaPetugas || currentUser.namaLengkap || currentUser.username,
      keteranganPerbaikan: payload.keteranganPerbaikan,
      estimasiBiaya: payload.estimasiBiaya || 0,
      status: 'Menunggu Persetujuan',
      createdAt: new Date().toISOString(),
    };

    item.statusPenanganan = 'Dialihkan ke Perbaikan';
    item.perbaikanId = newPerbaikan.id;
    this.setBarangRusak(rusakList);

    const perbaikanList = this.getPerbaikan();
    perbaikanList.unshift(newPerbaikan);
    this.setPerbaikan(perbaikanList);

    this.addLog(
      'ALIHKAN_PERBAIKAN',
      'Barang Rusak',
      `Barang ${item.namaBarang} (${item.jumlahRusak} ${item.satuan}) dialihkan ke perbaikan dengan nomor ${noPerbaikan}`,
      currentUser
    );

    return { success: true, message: `Tiket perbaikan ${noPerbaikan} dibuat. Menunggu persetujuan Admin.` };
  }

  /**
   * Alihkan Barang Rusak ke Pembelian
   */
  static alihkanKePembelian(
    barangRusakId: string,
    payload: {
      alasanPembelian: string;
      estimasiHarga: number;
      namaPengaju: string;
    },
    currentUser: User
  ): { success: boolean; message: string } {
    const rusakList = this.getBarangRusak();
    const item = rusakList.find((r) => r.id === barangRusakId);
    if (!item) return { success: false, message: 'Barang rusak tidak ditemukan.' };

    const master = this.getMasterBarang();
    const brg = master.find((m) => m.kodeBarang === item.kodeBarang);
    if (brg) {
      brg.rusak = Math.max(0, brg.rusak - item.jumlahRusak);
      brg.menungguBeli += item.jumlahRusak;
      brg.updatedAt = new Date().toISOString().split('T')[0];
      this.setMasterBarang(master);
    }

    const beliCount = this.getPembelian().length + 1;
    const yearMonth = new Date().toISOString().slice(2, 7).replace('-', '');
    const noPengadaan = `PO-${yearMonth}-${String(beliCount).padStart(4, '0')}`;

    const newPembelian: Pembelian = {
      id: 'PO-' + Date.now(),
      noPengadaan,
      barangRusakId: item.id,
      kodeBarang: item.kodeBarang,
      namaBarang: item.namaBarang,
      satuan: item.satuan,
      jumlahDibutuhkan: item.jumlahRusak,
      alasanPembelian: payload.alasanPembelian,
      tanggalPengajuan: new Date().toISOString().split('T')[0],
      namaPengaju: payload.namaPengaju || currentUser.namaLengkap || currentUser.username,
      estimasiHarga: payload.estimasiHarga || 0,
      status: 'Menunggu Persetujuan',
      createdAt: new Date().toISOString(),
    };

    item.statusPenanganan = 'Dialihkan ke Pembelian';
    item.pembelianId = newPembelian.id;
    this.setBarangRusak(rusakList);

    const pembelianList = this.getPembelian();
    pembelianList.unshift(newPembelian);
    this.setPembelian(pembelianList);

    this.addLog(
      'ALIHKAN_PEMBELIAN',
      'Barang Rusak',
      `Barang ${item.namaBarang} (${item.jumlahRusak} ${item.satuan}) diajukan pembelian pengganti (${noPengadaan})`,
      currentUser
    );

    return { success: true, message: `Pengajuan pembelian ${noPengadaan} dibuat. Menunggu persetujuan Admin.` };
  }

  /**
   * Update Status Perbaikan:
   * Petugas hanya bisa ubah Sementara Pengerjaan atau minta ACC selesai.
   * Admin yang bisa ACC Selesai -> Stok otomatis bertambah aktif kembali!
   */
  static updateStatusPerbaikan(
    perbaikanId: string,
    newStatus: StatusPerbaikan,
    options: {
      biayaAktual?: number;
      keteranganTambahan?: string;
      tanggalMulai?: string;
      tanggalSelesai?: string;
      alasanTolak?: string;
    },
    currentUser: User
  ): { success: boolean; message: string } {
    const list = this.getPerbaikan();
    const item = list.find((p) => p.id === perbaikanId);
    if (!item) return { success: false, message: 'Data perbaikan tidak ditemukan.' };

    const isAdmin = currentUser.role === 'ADMIN';

    // Role restrictions:
    // Only Admin can approve repair start
    if (newStatus === 'Disetujui untuk Diperbaiki' && !isAdmin) {
      return { success: false, message: 'Hanya Admin yang berhak menyetujui perbaikan.' };
    }
    // Only Admin can reject
    if (newStatus === 'Ditolak' && !isAdmin) {
      return { success: false, message: 'Hanya Admin yang berhak menolak perbaikan.' };
    }
    // CRITICAL RULE: Petugas cannot mark as 'Selesai Diperbaiki' directly; they submit 'Menunggu Persetujuan Selesai'
    if (newStatus === 'Selesai Diperbaiki' && !isAdmin) {
      return {
        success: false,
        message: 'Hanya Admin yang dapat memberikan ACC Selesai Diperbaiki. Petugas silakan pilih "Menunggu Persetujuan Selesai".',
      };
    }

    const prevStatus = item.status;
    item.status = newStatus;

    if (options.biayaAktual !== undefined) item.biayaAktual = options.biayaAktual;
    if (options.tanggalMulai) item.tanggalMulai = options.tanggalMulai;
    if (options.tanggalSelesai) item.tanggalSelesai = options.tanggalSelesai;
    if (options.alasanTolak) item.ditolakAlasan = options.alasanTolak;

    if (newStatus === 'Disetujui untuk Diperbaiki') {
      item.disetujuiOleh = currentUser.namaLengkap || currentUser.username;
    }

    // ACC Selesai Diperbaiki: ATURAN OTOMATIS
    if (newStatus === 'Selesai Diperbaiki' && prevStatus !== 'Selesai Diperbaiki') {
      item.accSelesaiOleh = currentUser.namaLengkap || currentUser.username;
      item.accSelesaiAt = new Date().toISOString();

      const master = this.getMasterBarang();
      const brg = master.find((m) => m.kodeBarang === item.kodeBarang);
      if (brg) {
        brg.perbaikan = Math.max(0, brg.perbaikan - item.jumlahBarang);
        brg.stokAktif += item.jumlahBarang;
        brg.updatedAt = new Date().toISOString().split('T')[0];
        this.setMasterBarang(master);
      }

      // Update linked BarangRusak status
      if (item.barangRusakId) {
        const rusakList = this.getBarangRusak();
        const rItem = rusakList.find((r) => r.id === item.barangRusakId);
        if (rItem) {
          rItem.statusPenanganan = 'Selesai Diperbaiki';
          this.setBarangRusak(rusakList);
        }
      }
    }

    this.setPerbaikan(list);

    this.addLog(
      'UPDATE_PERBAIKAN',
      'Perbaikan Barang',
      `Tiket ${item.noPerbaikan} (${item.namaBarang}) diubah status menjadi "${newStatus}"`,
      currentUser
    );

    return {
      success: true,
      message:
        newStatus === 'Selesai Diperbaiki'
          ? `Perbaikan disetujui selesai oleh Admin. ${item.jumlahBarang} ${item.satuan} ${item.namaBarang} otomatis kembali ke Stok Aktif!`
          : `Status perbaikan ${item.noPerbaikan} berhasil diperbarui ke "${newStatus}".`,
    };
  }

  /**
   * Update Status Pembelian:
   * ACC Admin untuk 'Sudah Dibeli' -> Stok pengganti otomatis aktif!
   */
  static updateStatusPembelian(
    pembelianId: string,
    newStatus: StatusPembelian,
    options: {
      hargaAktual?: number;
      buktiPembelianUrl?: string;
      alasanTolak?: string;
    },
    currentUser: User
  ): { success: boolean; message: string } {
    const list = this.getPembelian();
    const item = list.find((p) => p.id === pembelianId);
    if (!item) return { success: false, message: 'Data pembelian tidak ditemukan.' };

    const isAdmin = currentUser.role === 'ADMIN';

    if ((newStatus === 'Disetujui untuk Dibeli' || newStatus === 'Ditolak') && !isAdmin) {
      return { success: false, message: 'Hanya Admin yang berhak menyetujui atau menolak pembelian.' };
    }

    const prevStatus = item.status;
    item.status = newStatus;

    if (options.hargaAktual !== undefined) item.hargaAktual = options.hargaAktual;
    if (options.buktiPembelianUrl) item.buktiPembelianUrl = options.buktiPembelianUrl;
    if (options.alasanTolak) item.ditolakAlasan = options.alasanTolak;

    if (newStatus === 'Disetujui untuk Dibeli') {
      item.disetujuiOleh = currentUser.namaLengkap || currentUser.username;
    }

    // ATURAN OTOMATIS: Sudah Dibeli & Diterima dengan ACC Admin
    if (newStatus === 'Sudah Dibeli' && prevStatus !== 'Sudah Dibeli') {
      item.accDiterimaOleh = currentUser.namaLengkap || currentUser.username;
      item.tanggalDiterima = new Date().toISOString().split('T')[0];

      const master = this.getMasterBarang();
      const brg = master.find((m) => m.kodeBarang === item.kodeBarang);
      if (brg) {
        brg.menungguBeli = Math.max(0, brg.menungguBeli - item.jumlahDibutuhkan);
        brg.stokAktif += item.jumlahDibutuhkan;
        brg.stokAwal += item.jumlahDibutuhkan;
        brg.updatedAt = new Date().toISOString().split('T')[0];
        this.setMasterBarang(master);
      }

      if (item.barangRusakId) {
        const rusakList = this.getBarangRusak();
        const rItem = rusakList.find((r) => r.id === item.barangRusakId);
        if (rItem) {
          rItem.statusPenanganan = 'Diganti Baru';
          this.setBarangRusak(rusakList);
        }
      }
    }

    this.setPembelian(list);

    this.addLog(
      'UPDATE_PEMBELIAN',
      'Pembelian Barang',
      `Pengadaan ${item.noPengadaan} (${item.namaBarang}) status menjadi "${newStatus}"`,
      currentUser
    );

    return {
      success: true,
      message:
        newStatus === 'Sudah Dibeli'
          ? `Barang baru telah diterima & di-ACC Admin. ${item.jumlahDibutuhkan} ${item.satuan} ${item.namaBarang} otomatis masuk ke Stok Aktif!`
          : `Status pembelian ${item.noPengadaan} berhasil diperbarui ke "${newStatus}".`,
    };
  }

  /**
   * Stock Opname:
   * Input stok fisik, hitung selisih.
   * Admin approves penyesuaian -> Stok aktif berubah sesuai fisik.
   */
  static createStockOpname(
    data: {
      kodeBarang: string;
      stokFisik: number;
      catatan: string;
    },
    currentUser: User
  ): { success: boolean; message: string } {
    const master = this.getMasterBarang();
    const brg = master.find((m) => m.kodeBarang === data.kodeBarang);
    if (!brg) return { success: false, message: 'Barang tidak ditemukan.' };

    const opnameCount = this.getStockOpname().length + 1;
    const yearMonth = new Date().toISOString().slice(2, 7).replace('-', '');
    const noOpname = `SOP-${yearMonth}-${String(opnameCount).padStart(4, '0')}`;

    const selisih = data.stokFisik - brg.stokAktif;

    const newOpname: StockOpname = {
      id: 'SOP-' + Date.now(),
      noOpname,
      tanggalOpname: new Date().toISOString().split('T')[0],
      kodeBarang: brg.kodeBarang,
      namaBarang: brg.namaBarang,
      satuan: brg.satuan,
      stokSistem: brg.stokAktif,
      stokFisik: data.stokFisik,
      selisih,
      statusPenyesuaian: 'Menunggu Persetujuan Admin',
      dicatatOleh: currentUser.namaLengkap || currentUser.username,
      catatan: data.catatan || '',
      createdAt: new Date().toISOString(),
    };

    const opnameList = this.getStockOpname();
    opnameList.unshift(newOpname);
    this.setStockOpname(opnameList);

    this.addLog(
      'INPUT_STOCK_OPNAME',
      'Stock Opname',
      `Pemeriksaan fisik ${brg.namaBarang}: Sistem ${brg.stokAktif}, Fisik ${data.stokFisik} (Selisih: ${selisih})`,
      currentUser
    );

    return {
      success: true,
      message: `Pemeriksaan ${noOpname} tersimpan dengan selisih ${selisih > 0 ? '+' : ''}${selisih} ${brg.satuan}. Menunggu persetujuan penyesuaian oleh Admin.`,
    };
  }

  static createMultiStockOpname(
    items: {
      kodeBarang: string;
      stokFisik: number;
      catatan: string;
    }[],
    currentUser: User
  ): { success: boolean; message: string; count: number } {
    const master = this.getMasterBarang();
    const opnameList = this.getStockOpname();
    let savedCount = 0;
    const yearMonth = new Date().toISOString().slice(2, 7).replace('-', '');

    for (const data of items) {
      const brg = master.find((m) => m.kodeBarang === data.kodeBarang);
      if (!brg) continue;

      const opnameCount = opnameList.length + 1;
      const noOpname = `SOP-${yearMonth}-${String(opnameCount).padStart(4, '0')}`;
      const selisih = data.stokFisik - brg.stokAktif;

      const newOpname: StockOpname = {
        id: 'SOP-' + Date.now() + '-' + Math.floor(Math.random() * 1000) + '-' + savedCount,
        noOpname,
        tanggalOpname: new Date().toISOString().split('T')[0],
        kodeBarang: brg.kodeBarang,
        namaBarang: brg.namaBarang,
        satuan: brg.satuan,
        stokSistem: brg.stokAktif,
        stokFisik: data.stokFisik,
        selisih,
        statusPenyesuaian: 'Menunggu Persetujuan Admin',
        dicatatOleh: currentUser.namaLengkap || currentUser.username,
        catatan: data.catatan || 'Opname Manual Multi Barang',
        createdAt: new Date().toISOString(),
      };

      opnameList.unshift(newOpname);
      savedCount++;
    }

    this.setStockOpname(opnameList);
    this.addLog(
      'INPUT_STOCK_OPNAME_MULTI',
      'Stock Opname',
      `Audit fisik serentak (Opname Multi) untuk ${savedCount} jenis barang`,
      currentUser
    );

    return {
      success: true,
      message: `Berhasil mencatat audit fisik untuk ${savedCount} barang. Seluruh data masuk antrean persetujuan penyesuaian stok Admin.`,
      count: savedCount,
    };
  }

  static approveAllPendingStockOpname(
    currentUser: User
  ): { success: boolean; message: string; count: number } {
    if (currentUser.role !== 'ADMIN') {
      return { success: false, message: 'Hanya Admin yang berhak menyetujui penyesuaian stok opname.', count: 0 };
    }

    const list = this.getStockOpname();
    const master = this.getMasterBarang();
    let adjustedCount = 0;

    for (const item of list) {
      if (item.statusPenyesuaian === 'Menunggu Persetujuan Admin') {
        item.statusPenyesuaian = 'Disetujui & Disesuaikan';
        item.disetujuiOleh = currentUser.namaLengkap || currentUser.username;

        const brg = master.find((m) => m.kodeBarang === item.kodeBarang);
        if (brg) {
          brg.stokAktif = item.stokFisik;
          brg.updatedAt = new Date().toISOString().split('T')[0];
        }
        adjustedCount++;
      }
    }

    this.setStockOpname(list);
    this.setMasterBarang(master);

    this.addLog(
      'APPROVE_ALL_STOCK_OPNAME',
      'Stock Opname',
      `Admin menyetujui sekaligus penyesuaian ${adjustedCount} hasil stock opname`,
      currentUser
    );

    return {
      success: true,
      message: `Semua (${adjustedCount}) hasil stock opname disetujui. Saldo stok aktif di Master Barang telah disesuaikan!`,
      count: adjustedCount,
    };
  }

  static approveStockOpname(
    opnameId: string,
    action: 'SETUJUI' | 'TOLAK',
    currentUser: User
  ): { success: boolean; message: string } {
    if (currentUser.role !== 'ADMIN') {
      return { success: false, message: 'Hanya Admin yang berhak menyetujui penyesuaian stok opname.' };
    }

    const list = this.getStockOpname();
    const item = list.find((o) => o.id === opnameId);
    if (!item) return { success: false, message: 'Data stock opname tidak ditemukan.' };

    if (action === 'SETUJUI') {
      item.statusPenyesuaian = 'Disetujui & Disesuaikan';
      item.disetujuiOleh = currentUser.namaLengkap || currentUser.username;

      // Adjust master stock to physical count
      const master = this.getMasterBarang();
      const brg = master.find((m) => m.kodeBarang === item.kodeBarang);
      if (brg) {
        brg.stokAktif = item.stokFisik;
        brg.updatedAt = new Date().toISOString().split('T')[0];
        this.setMasterBarang(master);
      }
    } else {
      item.statusPenyesuaian = 'Ditolak';
      item.disetujuiOleh = currentUser.namaLengkap || currentUser.username;
    }

    this.setStockOpname(list);

    this.addLog(
      'APPROVE_STOCK_OPNAME',
      'Stock Opname',
      `Persetujuan penyesuaian stok ${item.noOpname} (${item.namaBarang}) oleh Admin: ${action}`,
      currentUser
    );

    return {
      success: true,
      message:
        action === 'SETUJUI'
          ? `Penyesuaian stok disetujui. Stok aktif ${item.namaBarang} kini disesuaikan menjadi ${item.stokFisik} ${item.satuan}.`
          : `Penyesuaian stok ${item.noOpname} ditolak. Stok sistem tidak diubah.`,
    };
  }

  /**
   * Validasi format Web App URL
   */
  static validateWebAppUrl(url: string): { isValid: boolean; warning?: string } {
    if (!url || !url.trim()) {
      return { isValid: false, warning: 'URL Google Apps Script Web App belum diisi.' };
    }
    const trimmed = url.trim();
    if (trimmed.includes('docs.google.com/spreadsheets')) {
      return {
        isValid: false,
        warning: 'URL yang dimasukkan adalah link dokumen Google Spreadsheet biasa, bukan link Web App Google Apps Script. Di spreadsheet Anda, buka menu Ekstensi > Apps Script > Deploy > New deployment > Web app, lalu salin URL yang berakhiran /exec.',
      };
    }
    if (trimmed.includes('script.google.com') && trimmed.includes('/edit')) {
      return {
        isValid: false,
        warning: 'URL yang dimasukkan adalah link editor kode Apps Script. Anda harus melakukan Deploy: klik Deploy (Terapkan) > New deployment > pilih Web app (Who has access: Anyone) > Deploy, lalu salin URL Web App yang berakhiran /exec.',
      };
    }
    if (!trimmed.includes('/exec')) {
      return {
        isValid: false,
        warning: 'Tautan Web App Google Apps Script harus berakhiran "/exec" (bukan /dev atau /edit).',
      };
    }
    return { isValid: true };
  }

  /**
   * Uji Ping Koneksi ke Google Apps Script
   */
  static async testGoogleAppsScriptConnection(customUrl?: string): Promise<{ success: boolean; message: string }> {
    const config = this.getGSheetsConfig();
    const url = (customUrl || config.webAppUrl || '').trim();

    const validation = this.validateWebAppUrl(url);
    if (!validation.isValid) {
      return { success: false, message: validation.warning || 'URL tidak valid.' };
    }

    try {
      const pingUrl = `${url}${url.includes('?') ? '&' : '?'}action=ping&_t=${Date.now()}`;
      const res = await fetch(pingUrl, {
        method: 'GET',
        headers: { Accept: 'application/json' },
      });
      const data = await res.json();
      if (data.success) {
        return { success: true, message: 'Koneksi berhasil! Google Apps Script merespons dengan normal.' };
      }
      return { success: false, message: data.message || 'Google Apps Script merespons tetapi gagal memproses aksi.' };
    } catch (err: any) {
      return {
        success: false,
        message:
          'Koneksi gagal (Failed to fetch). Penyebab utama: Saat Deploy Web App di Google Apps Script, opsi "Who has access" (Siapa yang memiliki akses) belum diubah menjadi "Anyone" (Siapa saja) atau izin akun Google belum disetujui.',
      };
    }
  }

  /**
   * Sync with Google Sheets Apps Script Web App
   */
  static async syncWithGoogleAppsScript(): Promise<{ success: boolean; message: string }> {
    const config = this.getGSheetsConfig();
    const validation = this.validateWebAppUrl(config.webAppUrl);
    if (!validation.isValid) {
      config.status = 'disconnected';
      config.errorMessage = validation.warning;
      this.setGSheetsConfig(config);
      return { success: false, message: validation.warning || 'URL Web App tidak valid.' };
    }

    config.status = 'syncing';
    this.setGSheetsConfig(config);

    try {
      const payload = {
        masterBarang: this.getMasterBarang(),
        barangMasuk: this.getBarangMasuk(),
        peminjaman: this.getPeminjaman(),
        pengembalian: this.getPengembalian(),
        stockOpname: this.getStockOpname(),
        barangRusak: this.getBarangRusak(),
        perbaikan: this.getPerbaikan(),
        wajibBeli: this.getPembelian(),
        users: this.getUsers(),
        logAktivitas: this.getLogs(),
      };

      const res = await fetch(config.webAppUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' }, // avoids preflight in Google Apps Script
        body: JSON.stringify({
          action: 'sync_all',
          payload,
        }),
      });

      const json = await res.json();
      if (json.success) {
        config.status = 'connected';
        config.lastSyncTimestamp = new Date().toLocaleString('id-ID');
        config.errorMessage = undefined;
        this.setGSheetsConfig(config);
        return { success: true, message: 'Sinkronisasi 12 Sheet ke Google Spreadsheet berhasil!' };
      } else {
        throw new Error(json.error || json.message || 'Gagal sinkronisasi');
      }
    } catch (err: any) {
      config.status = 'error';
      const isCorsOrAuth =
        err.message?.includes('Failed to fetch') ||
        err.name === 'TypeError' ||
        err.message?.includes('NetworkError');

      config.errorMessage = isCorsOrAuth
        ? 'Akses ditolak (Failed to fetch). Pastikan saat Deploy Web App opsi "Who has access" disetel ke "Anyone" (Siapa saja), bukan "Only myself".'
        : err.message || 'Gagal menghubungi server Apps Script';

      this.setGSheetsConfig(config);
      return { success: false, message: `Sinkronisasi gagal: ${config.errorMessage}` };
    }
  }
}
