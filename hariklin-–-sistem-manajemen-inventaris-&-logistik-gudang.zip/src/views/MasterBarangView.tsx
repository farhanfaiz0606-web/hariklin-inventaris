import React, { useState, useMemo } from 'react';
import {
  Search,
  Plus,
  Download,
  Edit2,
  Trash2,
  Eye,
  X,
  CheckCircle,
  AlertCircle,
  MapPin,
} from 'lucide-react';
import { MasterBarang, User, Peminjaman, BarangRusak, Perbaikan } from '../types';
import { exportToCSV } from '../utils/exportUtils';

interface MasterBarangViewProps {
  masterBarang: MasterBarang[];
  onSaveItem: (item: MasterBarang, isNew: boolean) => void;
  onDeleteItem: (kodeBarang: string) => void;
  currentUser: User;
  peminjamanList: Peminjaman[];
  barangRusakList: BarangRusak[];
  perbaikanList: Perbaikan[];
}

export const MasterBarangView: React.FC<MasterBarangViewProps> = ({
  masterBarang,
  onSaveItem,
  onDeleteItem,
  currentUser,
  peminjamanList,
  barangRusakList,
  perbaikanList,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('SEMUA');
  const [selectedCondition, setSelectedCondition] = useState('SEMUA');

  // Modals state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MasterBarang | null>(null);
  const [detailItem, setDetailItem] = useState<MasterBarang | null>(null);
  const [itemToDelete, setItemToDelete] = useState<MasterBarang | null>(null);

  // Form State
  const [formData, setFormData] = useState<{
    kodeBarang: string;
    namaBarang: string;
    kategori: string;
    satuan: string;
    stokAwal: number;
    stokAktif: number;
    keterangan: string;
    lokasiRak: string;
  }>({
    kodeBarang: '',
    namaBarang: '',
    kategori: 'Alat Kebersihan & Sanitasi',
    satuan: 'Pcs',
    stokAwal: 1,
    stokAktif: 1,
    keterangan: '',
    lokasiRak: '',
  });

  // Extract unique categories
  const categories = useMemo(() => {
    const set = new Set<string>();
    masterBarang.forEach((item) => {
      if (item.kategori) set.add(item.kategori);
    });
    return Array.from(set).sort();
  }, [masterBarang]);

  // Filtered List
  const filteredList = useMemo(() => {
    return masterBarang.filter((item) => {
      const matchSearch =
        item.namaBarang.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.kodeBarang.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (item.keterangan && item.keterangan.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchCategory =
        selectedCategory === 'SEMUA' || item.kategori === selectedCategory;

      let matchCondition = true;
      if (selectedCondition === 'SIAP_PAKAI') {
        matchCondition = item.stokAktif > 0;
      } else if (selectedCondition === 'DIPINJAM') {
        matchCondition = item.dipinjam > 0;
      } else if (selectedCondition === 'RUSAK') {
        matchCondition = item.rusak > 0;
      } else if (selectedCondition === 'PERBAIKAN') {
        matchCondition = item.perbaikan > 0;
      } else if (selectedCondition === 'MENUNGGU_BELI') {
        matchCondition = item.menungguBeli > 0;
      } else if (selectedCondition === 'HABIS') {
        matchCondition = item.stokAktif === 0;
      }

      return matchSearch && matchCategory && matchCondition;
    });
  }, [masterBarang, searchTerm, selectedCategory, selectedCondition]);

  const handleOpenAdd = () => {
    const nextNum = masterBarang.length + 1;
    const generatedCode = `BRG-${String(nextNum).padStart(3, '0')}`;
    setFormData({
      kodeBarang: generatedCode,
      namaBarang: '',
      kategori: 'Alat Kebersihan & Sanitasi',
      satuan: 'Pcs',
      stokAwal: 1,
      stokAktif: 1,
      keterangan: '',
      lokasiRak: '',
    });
    setEditingItem(null);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (item: MasterBarang) => {
    setEditingItem(item);
    setFormData({
      kodeBarang: item.kodeBarang,
      namaBarang: item.namaBarang,
      kategori: item.kategori,
      satuan: item.satuan,
      stokAwal: item.stokAwal,
      stokAktif: item.stokAktif,
      keterangan: item.keterangan || '',
      lokasiRak: item.lokasiRak || '',
    });
    setIsModalOpen(true);
  };

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.namaBarang.trim()) {
      alert('Nama barang wajib diisi!');
      return;
    }

    if (editingItem) {
      // Update
      const updated: MasterBarang = {
        ...editingItem,
        namaBarang: formData.namaBarang.trim(),
        kategori: formData.kategori,
        satuan: formData.satuan,
        stokAwal: Number(formData.stokAwal),
        stokAktif: Number(formData.stokAktif),
        keterangan: formData.keterangan.trim(),
        lokasiRak: formData.lokasiRak.trim(),
        updatedAt: new Date().toISOString().split('T')[0],
      };
      onSaveItem(updated, false);
    } else {
      // Create new
      const newItem: MasterBarang = {
        id: formData.kodeBarang,
        kodeBarang: formData.kodeBarang.trim(),
        namaBarang: formData.namaBarang.trim(),
        kategori: formData.kategori,
        satuan: formData.satuan,
        stokAwal: Number(formData.stokAwal),
        stokAktif: Number(formData.stokAktif),
        dipinjam: 0,
        rusak: 0,
        perbaikan: 0,
        menungguBeli: 0,
        keterangan: formData.keterangan.trim(),
        lokasiRak: formData.lokasiRak.trim(),
        updatedAt: new Date().toISOString().split('T')[0],
      };
      onSaveItem(newItem, true);
    }

    setIsModalOpen(false);
  };

  const handleExport = () => {
    const dataToExport = filteredList.map((it) => ({
      'Kode Barang': it.kodeBarang,
      'Nama Barang': it.namaBarang,
      Kategori: it.kategori,
      Satuan: it.satuan,
      'Stok Awal': it.stokAwal,
      'Stok Aktif': it.stokAktif,
      'Jumlah Dipinjam': it.dipinjam,
      'Jumlah Rusak': it.rusak,
      'Dalam Perbaikan': it.perbaikan,
      'Menunggu Pembelian': it.menungguBeli,
      'Lokasi Rak': it.lokasiRak || '-',
      Keterangan: it.keterangan || '-',
    }));
    exportToCSV('Master_Barang_Hariklin', dataToExport);
  };

  // History for detailed item
  const itemLoans = useMemo(() => {
    if (!detailItem) return [];
    return peminjamanList.filter((p) =>
      p.items.some((it) => it.kodeBarang === detailItem.kodeBarang)
    );
  }, [detailItem, peminjamanList]);

  const itemDamages = useMemo(() => {
    if (!detailItem) return [];
    return barangRusakList.filter((r) => r.kodeBarang === detailItem.kodeBarang);
  }, [detailItem, barangRusakList]);

  const itemRepairs = useMemo(() => {
    if (!detailItem) return [];
    return perbaikanList.filter((pbk) => pbk.kodeBarang === detailItem.kodeBarang);
  }, [detailItem, perbaikanList]);

  return (
    <div className="space-y-5">
      {/* Header View */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Master Data Barang</h1>
            <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
              {masterBarang.length} Item Terdaftar
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Pusat database seluruh inventaris gudang Hariklin (termasuk 75 inventaris bawaan)
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold border border-slate-200 transition-colors"
            title="Export Excel / CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Excel</span>
          </button>

          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Tambah Barang</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari kode, nama, atau keterangan..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
          />
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
          >
            <option value="SEMUA">Semua Kategori</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          {/* Condition Filter */}
          <select
            value={selectedCondition}
            onChange={(e) => setSelectedCondition(e.target.value)}
            className="px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
          >
            <option value="SEMUA">Semua Kondisi</option>
            <option value="SIAP_PAKAI">Siap Dipinjam (Stok Aktif &gt; 0)</option>
            <option value="DIPINJAM">Sedang Dipinjam</option>
            <option value="RUSAK">Ada Barang Rusak</option>
            <option value="PERBAIKAN">Dalam Perbaikan</option>
            <option value="MENUNGGU_BELI">Menunggu Pembelian</option>
            <option value="HABIS">Stok Habis (0)</option>
          </select>
        </div>
      </div>

      {/* Table Data Master */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider">
                <th className="py-3 px-3">No</th>
                <th className="py-3 px-3">Kode</th>
                <th className="py-3 px-3">Nama Barang</th>
                <th className="py-3 px-3">Kategori</th>
                <th className="py-3 px-3">Satuan</th>
                <th className="py-3 px-3 text-right">Stok Awal</th>
                <th className="py-3 px-3 text-right font-bold text-emerald-800 bg-emerald-50/50">
                  Stok Aktif
                </th>
                <th className="py-3 px-3 text-right text-blue-700">Dipinjam</th>
                <th className="py-3 px-3 text-right text-rose-700">Rusak</th>
                <th className="py-3 px-3 text-right text-amber-700">Perbaikan</th>
                <th className="py-3 px-3 text-right text-purple-700">Wajib Beli</th>
                <th className="py-3 px-3">Lokasi / Rak</th>
                <th className="py-3 px-3 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan={13} className="py-8 text-center text-slate-400">
                    Tidak ada barang yang cocok dengan kriteria pencarian.
                  </td>
                </tr>
              ) : (
                filteredList.map((item, idx) => (
                  <tr
                    key={item.kodeBarang}
                    className="hover:bg-slate-50/90 transition-colors"
                  >
                    <td className="py-2.5 px-3 text-slate-400 font-mono text-[11px]">{idx + 1}</td>
                    <td className="py-2.5 px-3 font-mono font-bold text-slate-900">{item.kodeBarang}</td>
                    <td className="py-2.5 px-3 font-medium text-slate-900">
                      <div>{item.namaBarang}</div>
                      {item.keterangan && (
                        <div className="text-[10px] text-slate-400 truncate max-w-[200px]">
                          {item.keterangan}
                        </div>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">
                      <span className="text-[11px] px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                        {item.kategori}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">{item.satuan}</td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-500">
                      {item.stokAwal}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-emerald-700 bg-emerald-50/40">
                      {item.stokAktif}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-blue-600">
                      {item.dipinjam > 0 ? item.dipinjam : '-'}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-rose-600">
                      {item.rusak > 0 ? item.rusak : '-'}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-amber-600">
                      {item.perbaikan > 0 ? item.perbaikan : '-'}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-purple-600">
                      {item.menungguBeli > 0 ? item.menungguBeli : '-'}
                    </td>
                    <td className="py-2.5 px-3 text-slate-500 text-[11px]">
                      {item.lokasiRak ? (
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-slate-400" />
                          <span>{item.lokasiRak}</span>
                        </span>
                      ) : (
                        '-'
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => setDetailItem(item)}
                          className="p-1 rounded text-slate-400 hover:text-slate-800 hover:bg-slate-100"
                          title="Detail Riwayat Barang"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleOpenEdit(item)}
                          className="p-1 rounded text-slate-400 hover:text-emerald-700 hover:bg-slate-100"
                          title="Edit Barang"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        {currentUser.role === 'ADMIN' && (
                          <button
                            onClick={() => setItemToDelete(item)}
                            className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                            title="Hapus Barang (Khusus Admin)"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL: Tambah / Edit Barang */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-lg overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b border-slate-200">
              <h3 className="font-bold text-slate-900 text-sm">
                {editingItem ? 'Edit Data Barang' : 'Tambah Barang Baru'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="p-4 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Kode Barang</label>
                  <input
                    type="text"
                    required
                    readOnly={!!editingItem}
                    value={formData.kodeBarang}
                    onChange={(e) => setFormData({ ...formData, kodeBarang: e.target.value })}
                    className={`w-full px-3 py-2 rounded-lg border text-xs font-mono ${
                      editingItem
                        ? 'bg-slate-100 text-slate-600 cursor-not-allowed'
                        : 'border-slate-300 focus:ring-2 focus:ring-emerald-500/20'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">Satuan</label>
                  <input
                    type="text"
                    required
                    placeholder="Pcs / Set / Unit / Jerigen"
                    value={formData.satuan}
                    onChange={(e) => setFormData({ ...formData, satuan: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500/20"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Nama Barang</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: set vacum ekstraktor crisbow"
                  value={formData.namaBarang}
                  onChange={(e) => setFormData({ ...formData, namaBarang: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Kategori</label>
                <input
                  type="text"
                  list="categories-list"
                  required
                  placeholder="Pilih atau ketik kategori baru"
                  value={formData.kategori}
                  onChange={(e) => setFormData({ ...formData, kategori: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500/20"
                />
                <datalist id="categories-list">
                  <option value="Mesin & Peralatan Elektrik" />
                  <option value="Alat Kebersihan & Sanitasi" />
                  <option value="Perlengkapan Pest Control" />
                  <option value="Bahan Pembersih & Kimia" />
                  <option value="Perkakas & Alat Pertukangan" />
                  <option value="APD & Perlengkapan Kerja" />
                  <option value="Sarana & Inventaris Kantor" />
                </datalist>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Stok Awal</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    required
                    value={formData.stokAwal}
                    onChange={(e) => setFormData({ ...formData, stokAwal: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">Stok Aktif</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    required
                    value={formData.stokAktif}
                    onChange={(e) => setFormData({ ...formData, stokAktif: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Lokasi Rak / Penempatan</label>
                <input
                  type="text"
                  placeholder="Contoh: Rak Mesin A-02 / Gudang Belakang"
                  value={formData.lokasiRak}
                  onChange={(e) => setFormData({ ...formData, lokasiRak: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Keterangan Tambahan</label>
                <textarea
                  rows={2}
                  placeholder="Catatan kondisi fisik, merk, atau spesifikasi..."
                  value={formData.keterangan}
                  onChange={(e) => setFormData({ ...formData, keterangan: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3.5 py-2 rounded-lg border border-slate-200 text-slate-700 font-semibold hover:bg-slate-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold shadow-xs"
                >
                  {editingItem ? 'Simpan Perubahan' : 'Tambah ke Master'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Konfirmasi Hapus Barang (Khusus Admin) */}
      {itemToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-md p-5 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-3">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-900 text-base">Hapus Barang dari Master?</h3>
            <p className="text-xs text-slate-500 mt-1.5">
              Anda akan menghapus data <strong className="text-slate-800">{itemToDelete.namaBarang}</strong> ({itemToDelete.kodeBarang}). Tindakan ini hanya dapat dilakukan oleh Admin dan tercatat dalam log aktivitas.
            </p>

            <div className="mt-5 flex items-center justify-center gap-2">
              <button
                onClick={() => setItemToDelete(null)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-50"
              >
                Batal
              </button>
              <button
                onClick={() => {
                  onDeleteItem(itemToDelete.kodeBarang);
                  setItemToDelete(null);
                }}
                className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold shadow-xs"
              >
                Ya, Hapus Data
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Detail Riwayat Barang */}
      {detailItem && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-slate-200 bg-slate-50">
              <div>
                <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
                  {detailItem.kodeBarang}
                </span>
                <h3 className="font-bold text-slate-900 text-base mt-1">{detailItem.namaBarang}</h3>
              </div>
              <button
                onClick={() => setDetailItem(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 text-xs">
              {/* Status Grid */}
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                <div className="p-2.5 rounded-lg bg-slate-100 text-center">
                  <div className="text-[10px] text-slate-500 font-medium">Stok Awal</div>
                  <div className="text-sm font-bold text-slate-800 font-mono mt-0.5">{detailItem.stokAwal}</div>
                </div>
                <div className="p-2.5 rounded-lg bg-emerald-50 text-center border border-emerald-200">
                  <div className="text-[10px] text-emerald-800 font-medium">Stok Aktif</div>
                  <div className="text-sm font-bold text-emerald-700 font-mono mt-0.5">{detailItem.stokAktif}</div>
                </div>
                <div className="p-2.5 rounded-lg bg-blue-50 text-center">
                  <div className="text-[10px] text-blue-700 font-medium">Dipinjam</div>
                  <div className="text-sm font-bold text-blue-700 font-mono mt-0.5">{detailItem.dipinjam}</div>
                </div>
                <div className="p-2.5 rounded-lg bg-rose-50 text-center">
                  <div className="text-[10px] text-rose-700 font-medium">Rusak</div>
                  <div className="text-sm font-bold text-rose-700 font-mono mt-0.5">{detailItem.rusak}</div>
                </div>
                <div className="p-2.5 rounded-lg bg-amber-50 text-center">
                  <div className="text-[10px] text-amber-700 font-medium">Perbaikan</div>
                  <div className="text-sm font-bold text-amber-700 font-mono mt-0.5">{detailItem.perbaikan}</div>
                </div>
                <div className="p-2.5 rounded-lg bg-purple-50 text-center">
                  <div className="text-[10px] text-purple-700 font-medium">Wajib Beli</div>
                  <div className="text-sm font-bold text-purple-700 font-mono mt-0.5">{detailItem.menungguBeli}</div>
                </div>
              </div>

              {/* General Info */}
              <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div>
                  <span className="text-slate-500">Kategori:</span>{' '}
                  <span className="font-semibold text-slate-800">{detailItem.kategori}</span>
                </div>
                <div>
                  <span className="text-slate-500">Satuan:</span>{' '}
                  <span className="font-semibold text-slate-800">{detailItem.satuan}</span>
                </div>
                <div>
                  <span className="text-slate-500">Lokasi Rak:</span>{' '}
                  <span className="font-semibold text-slate-800">{detailItem.lokasiRak || '-'}</span>
                </div>
                <div>
                  <span className="text-slate-500">Pembaruan Terakhir:</span>{' '}
                  <span className="font-mono text-slate-700">{detailItem.updatedAt}</span>
                </div>
              </div>

              {/* Riwayat Peminjaman */}
              <div>
                <h4 className="font-bold text-slate-800 text-xs mb-2">Riwayat Peminjaman Alat ({itemLoans.length})</h4>
                {itemLoans.length === 0 ? (
                  <p className="text-slate-400 italic">Belum ada riwayat peminjaman untuk barang ini.</p>
                ) : (
                  <div className="space-y-1.5">
                    {itemLoans.slice(0, 5).map((l) => (
                      <div key={l.id} className="p-2 rounded border border-slate-200 flex justify-between items-center text-xs">
                        <div>
                          <span className="font-mono font-semibold text-slate-800">{l.noTransaksi}</span>
                          <span className="text-slate-500 mx-1.5">&middot;</span>
                          <span>{l.namaPeminjam} ({l.keperluan})</span>
                        </div>
                        <span className="font-mono text-slate-500">{l.tanggalPinjam}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Riwayat Kerusakan & Perbaikan */}
              <div>
                <h4 className="font-bold text-slate-800 text-xs mb-2">Riwayat Kerusakan & Perbaikan</h4>
                {itemDamages.length === 0 && itemRepairs.length === 0 ? (
                  <p className="text-slate-400 italic">Tidak ada catatan kerusakan/perbaikan.</p>
                ) : (
                  <div className="space-y-1.5">
                    {itemDamages.map((dmg) => (
                      <div key={dmg.id} className="p-2 rounded bg-rose-50/60 border border-rose-200 flex justify-between items-center text-xs">
                        <div>
                          <span className="font-semibold text-rose-800">Rusak ({dmg.jumlahRusak} {dmg.satuan}):</span>{' '}
                          <span className="text-rose-700">{dmg.keterangan}</span>
                        </div>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-white text-rose-700 border border-rose-200">
                          {dmg.statusPenanganan}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="p-3 border-t border-slate-200 bg-slate-50 flex justify-end">
              <button
                onClick={() => setDetailItem(null)}
                className="px-4 py-1.5 rounded-lg bg-slate-800 text-white font-semibold text-xs"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
