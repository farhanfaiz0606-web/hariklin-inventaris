export type UserRole = 'ADMIN' | 'PETUGAS';

export interface UserPermissions {
  dashboard: boolean;
  masterBarang: boolean;
  peminjaman: boolean;
  pengembalian: boolean;
  barangMasuk: boolean;
  barangRusak: boolean;
  perbaikan: boolean;
  pembelian: boolean;
  stockOpname: boolean;
  laporan: boolean;
  kelolaAkses?: boolean; // Only true for ADMIN
}

export interface User {
  id: string;
  username: string;
  namaLengkap: string;
  email: string;
  role: UserRole;
  status: 'AKTIF' | 'NONAKTIF';
  passwordHash?: string;
  permissions: UserPermissions;
  terakhirLogin?: string;
  createdAt: string;
}

export interface MasterBarang {
  id: string;
  kodeBarang: string;
  namaBarang: string;
  kategori: string;
  satuan: string;
  stokAwal: number;
  stokAktif: number;
  dipinjam: number;
  rusak: number;
  perbaikan: number;
  menungguBeli: number;
  keterangan: string;
  lokasiRak?: string;
  fotoUrl?: string;
  updatedAt: string;
}

export interface PeminjamanItem {
  kodeBarang: string;
  namaBarang: string;
  satuan: string;
  jumlahPinjam: number;
  jumlahKembaliBaik: number;
  jumlahKembaliRusak: number;
  statusItem: 'Dipinjam' | 'Sebagian' | 'Selesai';
}

export interface Peminjaman {
  id: string;
  noTransaksi: string;
  tanggalPinjam: string;
  tanggalRencanaKembali: string;
  namaPeminjam: string;
  penanggungJawab: string;
  keperluan: string; // keperluan pembersihan apa
  keterangan: string;
  status: 'Dipinjam' | 'Sebagian' | 'Selesai';
  items: PeminjamanItem[];
  dicatatOleh: string;
  createdAt: string;
}

export interface PengembalianItem {
  kodeBarang: string;
  namaBarang: string;
  satuan: string;
  jumlahKembali: number;
  kondisi: 'Baik' | 'Rusak';
  keteranganRusak?: string;
}

export interface Pengembalian {
  id: string;
  noPengembalian: string;
  peminjamanId: string;
  noTransaksiPinjam: string;
  tanggalKembali: string;
  namaPeminjam: string;
  penanggungJawab: string;
  items: PengembalianItem[];
  dicatatOleh: string;
  createdAt: string;
}

export interface BarangMasuk {
  id: string;
  noTransaksiMasuk: string;
  kodeBarang: string;
  namaBarang: string;
  kategori: string;
  satuan: string;
  jumlahMasuk: number;
  tanggalMasuk: string;
  sumberBarang: string;
  penanggungJawab: string;
  keterangan: string;
  notaFotoUrl?: string;
  dicatatOleh: string;
  createdAt: string;
}

export type StatusPenangananRusak = 
  | 'Menunggu Keputusan' 
  | 'Dialihkan ke Perbaikan' 
  | 'Dialihkan ke Pembelian' 
  | 'Selesai Diperbaiki' 
  | 'Diganti Baru';

export interface BarangRusak {
  id: string;
  kodeBarang: string;
  namaBarang: string;
  satuan: string;
  jumlahRusak: number;
  tanggalKerusakan: string;
  sumberKerusakan: string;
  keterangan: string;
  statusPenanganan: StatusPenangananRusak;
  perbaikanId?: string;
  pembelianId?: string;
  dicatatOleh: string;
  createdAt: string;
}

export type StatusPerbaikan = 
  | 'Menunggu Persetujuan' 
  | 'Disetujui untuk Diperbaiki' 
  | 'Sementara Pengerjaan' 
  | 'Menunggu Persetujuan Selesai' 
  | 'Selesai Diperbaiki' 
  | 'Ditolak';

export interface Perbaikan {
  id: string;
  noPerbaikan: string;
  barangRusakId?: string;
  kodeBarang: string;
  namaBarang: string;
  satuan: string;
  jumlahBarang: number;
  tanggalKerusakan: string;
  penyebabKerusakan: string;
  namaPetugas: string;
  keteranganPerbaikan: string;
  estimasiBiaya: number;
  biayaAktual?: number;
  tanggalMulai?: string;
  tanggalSelesai?: string;
  status: StatusPerbaikan;
  disetujuiOleh?: string;
  ditolakAlasan?: string;
  accSelesaiOleh?: string;
  accSelesaiAt?: string;
  createdAt: string;
}

export type StatusPembelian = 
  | 'Menunggu Persetujuan' 
  | 'Disetujui untuk Dibeli' 
  | 'Belum Dibeli' 
  | 'Sudah Dibeli' 
  | 'Ditolak';

export interface Pembelian {
  id: string;
  noPengadaan: string;
  barangRusakId?: string;
  kodeBarang: string;
  namaBarang: string;
  satuan: string;
  jumlahDibutuhkan: number;
  alasanPembelian: string;
  tanggalPengajuan: string;
  namaPengaju: string;
  estimasiHarga: number;
  hargaAktual?: number;
  status: StatusPembelian;
  buktiPembelianUrl?: string;
  disetujuiOleh?: string;
  ditolakAlasan?: string;
  accDiterimaOleh?: string;
  tanggalDiterima?: string;
  createdAt: string;
}

export type StatusStockOpname = 
  | 'Menunggu Persetujuan Admin' 
  | 'Disetujui & Disesuaikan' 
  | 'Ditolak';

export interface StockOpname {
  id: string;
  noOpname: string;
  tanggalOpname: string;
  kodeBarang: string;
  namaBarang: string;
  satuan: string;
  stokSistem: number;
  stokFisik: number;
  selisih: number;
  statusPenyesuaian: StatusStockOpname;
  dicatatOleh: string;
  disetujuiOleh?: string;
  catatan: string;
  createdAt: string;
}

export interface LogAktivitas {
  id: string;
  timestamp: string;
  userId: string;
  username: string;
  action: string;
  modul: string;
  detail: string;
}

export interface GoogleSheetsConfig {
  spreadsheetUrl: string;
  webAppUrl: string;
  isAutoSync: boolean;
  lastSyncTimestamp?: string;
  status: 'connected' | 'disconnected' | 'syncing' | 'error';
  errorMessage?: string;
}
