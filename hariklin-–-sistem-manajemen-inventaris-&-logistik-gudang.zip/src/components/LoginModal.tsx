import React, { useState } from 'react';
import { X, User as UserIcon, Shield, Check, Lock } from 'lucide-react';
import { User } from '../types';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: User[];
  currentUser: User;
  onSelectUser: (user: User) => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  users,
  currentUser,
  onSelectUser,
}) => {
  const [selectedUserId, setSelectedUserId] = useState<string>(currentUser.id);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleSwitch = (user: User) => {
    if (user.status !== 'AKTIF') {
      setErrorMsg(`Akun @${user.username} sedang dinonaktifkan oleh Administrator!`);
      setTimeout(() => setErrorMsg(''), 4000);
      return;
    }
    onSelectUser(user);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-md overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-white p-1 border border-slate-200 flex items-center justify-center shrink-0">
              <img src="/hariklin-logo.jpg" alt="HARIKLIN" className="w-full h-full object-contain" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Ganti Akun Pengguna</h3>
              <p className="text-xs text-slate-500">Pilih profil akun yang bertugas saat ini</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-600 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMsg && (
          <div className="mx-4 mt-3 p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium">
            {errorMsg}
          </div>
        )}

        {/* User list */}
        <div className="p-4 space-y-2.5 max-h-80 overflow-y-auto">
          {users.map((u) => {
            const isCurrent = u.id === currentUser.id;
            const isInactive = u.status !== 'AKTIF';

            return (
              <div
                key={u.id}
                onClick={() => !isInactive && handleSwitch(u)}
                className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                  isCurrent
                    ? 'bg-emerald-50 border-emerald-300 ring-2 ring-emerald-500/20'
                    : isInactive
                    ? 'bg-slate-50 border-slate-200 opacity-60 cursor-not-allowed'
                    : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs ${
                      u.role === 'ADMIN'
                        ? 'bg-slate-900 text-white'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {u.role === 'ADMIN' ? (
                      <Shield className="w-4 h-4" />
                    ) : (
                      <UserIcon className="w-4 h-4" />
                    )}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 text-xs">{u.namaLengkap}</span>
                      <span
                        className={`text-[10px] font-mono px-1.5 py-0.2 rounded font-semibold ${
                          u.role === 'ADMIN'
                            ? 'bg-slate-900 text-white'
                            : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        }`}
                      >
                        {u.role}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono">@{u.username}</div>
                  </div>
                </div>

                <div>
                  {isCurrent ? (
                    <span className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" />
                      Aktif
                    </span>
                  ) : isInactive ? (
                    <span className="text-[11px] text-rose-600 font-semibold flex items-center gap-1">
                      <Lock className="w-3 h-3" />
                      Non-aktif
                    </span>
                  ) : (
                    <span className="text-xs text-slate-400 group-hover:text-slate-700">Pilih &rarr;</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg border border-slate-200 text-slate-700 font-semibold text-xs hover:bg-slate-100"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
