/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  MasterBarang,
  Peminjaman,
  Pengembalian,
  BarangMasuk,
  BarangRusak,
  Perbaikan,
  Pembelian,
  StockOpname,
  User,
  LogAktivitas,
  GoogleSheetsConfig,
  StatusPerbaikan,
  StatusPembelian,
} from './types';
import { StorageService } from './services/storageService';
import { Header } from './components/Header';
import { Sidebar, NavMenuKey } from './components/Sidebar';
import { DashboardView } from './views/DashboardView';
import { MasterBarangView } from './views/MasterBarangView';
import { PeminjamanView } from './views/PeminjamanView';
import { PengembalianView } from './views/PengembalianView';
import { BarangMasukView } from './views/BarangMasukView';
import { BarangRusakView } from './views/BarangRusakView';
import { PerbaikanView } from './views/PerbaikanView';
import { PembelianView } from './views/PembelianView';
import { StockOpnameView } from './views/StockOpnameView';
import { LaporanView } from './views/LaporanView';
import { KelolaAksesView } from './views/KelolaAksesView';
import { PrintLabelModal } from './components/PrintLabelModal';
import { PrintSuratJalanModal } from './components/PrintSuratJalanModal';
import { DatabaseSetupModal } from './components/DatabaseSetupModal';
import { LoginModal } from './components/LoginModal';
import { CheckCircle2, AlertCircle, X } from 'lucide-react';

export default function App() {
  // Database & Local State
  const [masterBarang, setMasterBarang] = useState<MasterBarang[]>([]);
  const [peminjaman, setPeminjaman] = useState<Peminjaman[]>([]);
  const [pengembalian, setPengembalian] = useState<Pengembalian[]>([]);
  const [barangMasuk, setBarangMasuk] = useState<BarangMasuk[]>([]);
  const [barangRusak, setBarangRusak] = useState<BarangRusak[]>([]);
  const [perbaikan, setPerbaikan] = useState<Perbaikan[]>([]);
  const [pembelian, setPembelian] = useState<Pembelian[]>([]);
  const [stockOpname, setStockOpname] = useState<StockOpname[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User>(StorageService.getCurrentUser());
  const [logs, setLogs] = useState<LogAktivitas[]>([]);
  const [sheetsConfig, setSheetsConfig] = useState<GoogleSheetsConfig>(StorageService.getGSheetsConfig());

  // UI State
  const [activeMenu, setActiveMenu] = useState<NavMenuKey>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  // Modals
  const [isLabelModalOpen, setIsLabelModalOpen] = useState(false);
  const [isSuratJalanModalOpen, setIsSuratJalanModalOpen] = useState(false);
  const [selectedLoanForPrint, setSelectedLoanForPrint] = useState<Peminjaman | null>(null);
  const [isDbModalOpen, setIsDbModalOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // Toast notification
  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => {
      setToast(null);
    }, 4500);
  };

  // Reload all data from storage
  const reloadData = () => {
    setMasterBarang(StorageService.getMasterBarang());
    setPeminjaman(StorageService.getPeminjaman());
    setPengembalian(StorageService.getPengembalian());
    setBarangMasuk(StorageService.getBarangMasuk());
    setBarangRusak(StorageService.getBarangRusak());
    setPerbaikan(StorageService.getPerbaikan());
    setPembelian(StorageService.getPembelian());
    setStockOpname(StorageService.getStockOpname());
    setUsers(StorageService.getUsers());
    setLogs(StorageService.getLogs());
    setSheetsConfig(StorageService.getGSheetsConfig());
    const user = StorageService.getCurrentUser();
    setCurrentUser(user);
  };

  useEffect(() => {
    reloadData();
  }, []);

  // Compute live badge counters
  const badgeCounts = useMemo(() => {
    return {
      pinjamAktif: peminjaman.filter((p) => p.status !== 'Selesai').length,
      barangRusak: barangRusak.filter((r) => r.statusPenanganan === 'Menunggu Keputusan').length,
      perbaikanPending: perbaikan.filter(
        (pbk) => pbk.status === 'Menunggu Persetujuan' || pbk.status === 'Menunggu Persetujuan Selesai'
      ).length,
      pembelianPending: pembelian.filter(
        (po) => po.status === 'Menunggu Persetujuan' || po.status === 'Belum Dibeli'
      ).length,
      opnamePending: stockOpname.filter((s) => s.statusPenyesuaian === 'Menunggu Persetujuan Admin').length,
    };
  }, [peminjaman, barangRusak, perbaikan, pembelian, stockOpname]);

  // Ensure current user is permitted to view activeMenu
  useEffect(() => {
    if (currentUser.role === 'ADMIN') return;
    if (activeMenu === 'kelolaAkses') {
      setActiveMenu('dashboard');
      return;
    }
    const hasPermission = currentUser.permissions[activeMenu as keyof typeof currentUser.permissions];
    if (hasPermission === false) {
      // Find first permitted menu
      const firstPermitted = (Object.keys(currentUser.permissions) as (keyof typeof currentUser.permissions)[]).find(
        (k) => currentUser.permissions[k] === true
      );
      setActiveMenu((firstPermitted as NavMenuKey) || 'dashboard');
    }
  }, [currentUser, activeMenu]);

  // Handler: Peminjaman
  const handleCreatePeminjaman = (data: Omit<Peminjaman, 'id' | 'noTransaksi' | 'createdAt' | 'status'>) => {
    const res = StorageService.createPeminjaman(data, currentUser);
    if (res.success) {
      reloadData();
      showToast('success', res.message);
      if (res.data) {
        setSelectedLoanForPrint(res.data);
      }
    } else {
      showToast('error', res.message);
    }
  };

  // Handler: Pengembalian
  const handleProcessPengembalian = (data: {
    peminjamanId: string;
    tanggalKembali: string;
    items: {
      kodeBarang: string;
      namaBarang: string;
      satuan: string;
      jumlahKembali: number;
      kondisi: 'Baik' | 'Rusak';
      keteranganRusak?: string;
    }[];
  }) => {
    const res = StorageService.processPengembalian(data, currentUser);
    if (res.success) {
      reloadData();
      showToast('success', res.message);
    } else {
      showToast('error', res.message);
    }
  };

  // Handler: Barang Masuk
  const handleProcessBarangMasuk = (data: {
    kodeBarang?: string;
    namaBarang: string;
    kategori: string;
    satuan: string;
    jumlahMasuk: number;
    tanggalMasuk: string;
    sumberBarang: string;
    penanggungJawab: string;
    keterangan: string;
    notaFotoUrl?: string;
  }) => {
    const res = StorageService.processBarangMasuk(data, currentUser);
    if (res.success) {
      reloadData();
      showToast('success', res.message);
    } else {
      showToast('error', res.message);
    }
  };

  // Handler: Alihkan ke Perbaikan
  const handleAlihkanKePerbaikan = (
    barangRusakId: string,
    payload: {
      penyebabKerusakan: string;
      keteranganPerbaikan: string;
      estimasiBiaya: number;
      namaPetugas: string;
    }
  ) => {
    const res = StorageService.alihkanKePerbaikan(barangRusakId, payload, currentUser);
    if (res.success) {
      reloadData();
      showToast('success', res.message);
    } else {
      showToast('error', res.message);
    }
  };

  // Handler: Alihkan ke Pembelian
  const handleAlihkanKePembelian = (
    barangRusakId: string,
    payload: {
      alasanPembelian: string;
      estimasiHarga: number;
      namaPengaju: string;
    }
  ) => {
    const res = StorageService.alihkanKePembelian(barangRusakId, payload, currentUser);
    if (res.success) {
      reloadData();
      showToast('success', res.message);
    } else {
      showToast('error', res.message);
    }
  };

  // Handler: Manual Damage Report
  const handleManualReportDamage = (data: {
    kodeBarang: string;
    jumlahRusak: number;
    tanggalKerusakan: string;
    sumberKerusakan: string;
    keterangan: string;
  }) => {
    const master = StorageService.getMasterBarang();
    const brg = master.find((m) => m.kodeBarang === data.kodeBarang);
    if (!brg) {
      showToast('error', 'Barang tidak ditemukan di Master.');
      return;
    }

    // Deduct active stock and increase damaged stock
    brg.stokAktif = Math.max(0, brg.stokAktif - data.jumlahRusak);
    brg.rusak += data.jumlahRusak;
    brg.updatedAt = new Date().toISOString().split('T')[0];
    StorageService.setMasterBarang(master);

    const damagedList = StorageService.getBarangRusak();
    const newDamaged: BarangRusak = {
      id: 'BR-' + Date.now(),
      kodeBarang: brg.kodeBarang,
      namaBarang: brg.namaBarang,
      satuan: brg.satuan,
      jumlahRusak: data.jumlahRusak,
      tanggalKerusakan: data.tanggalKerusakan,
      sumberKerusakan: data.sumberKerusakan,
      keterangan: data.keterangan,
      statusPenanganan: 'Menunggu Keputusan',
      dicatatOleh: currentUser.namaLengkap || currentUser.username,
      createdAt: new Date().toISOString(),
    };
    damagedList.unshift(newDamaged);
    StorageService.setBarangRusak(damagedList);

    StorageService.addLog(
      'LAPOR_KERUSAKAN_MANUAL',
      'Barang Rusak',
      `Kerusakan dilaporkan: ${brg.namaBarang} (${data.jumlahRusak} ${brg.satuan}). ${data.keterangan}`,
      currentUser
    );

    reloadData();
    showToast('success', `Kerusakan ${brg.namaBarang} tercatat. Stok aktif telah disesuaikan.`);
  };

  // Handler: Update Perbaikan
  const handleUpdateStatusPerbaikan = (
    perbaikanId: string,
    newStatus: StatusPerbaikan,
    options: {
      biayaAktual?: number;
      keteranganTambahan?: string;
      tanggalMulai?: string;
      tanggalSelesai?: string;
      alasanTolak?: string;
    }
  ) => {
    const res = StorageService.updateStatusPerbaikan(perbaikanId, newStatus, options, currentUser);
    if (res.success) {
      reloadData();
      showToast('success', res.message);
    } else {
      showToast('error', res.message);
    }
  };

  // Handler: Update Pembelian
  const handleUpdateStatusPembelian = (
    pembelianId: string,
    newStatus: StatusPembelian,
    options: {
      hargaAktual?: number;
      buktiPembelianUrl?: string;
      alasanTolak?: string;
    }
  ) => {
    const res = StorageService.updateStatusPembelian(pembelianId, newStatus, options, currentUser);
    if (res.success) {
      reloadData();
      showToast('success', res.message);
    } else {
      showToast('error', res.message);
    }
  };

  // Handler: Stock Opname
  const handleCreateOpname = (data: {
    kodeBarang: string;
    stokFisik: number;
    catatan: string;
  }) => {
    const res = StorageService.createStockOpname(data, currentUser);
    if (res.success) {
      reloadData();
      showToast('success', res.message);
    } else {
      showToast('error', res.message);
    }
  };

  const handleCreateMultiOpname = (
    items: {
      kodeBarang: string;
      stokFisik: number;
      catatan: string;
    }[]
  ) => {
    const res = StorageService.createMultiStockOpname(items, currentUser);
    if (res.success) {
      reloadData();
      showToast('success', res.message);
    } else {
      showToast('error', res.message);
    }
  };

  const handleApproveOpname = (opnameId: string, action: 'SETUJUI' | 'TOLAK') => {
    const res = StorageService.approveStockOpname(opnameId, action, currentUser);
    if (res.success) {
      reloadData();
      showToast('success', res.message);
    } else {
      showToast('error', res.message);
    }
  };

  const handleApproveAllOpname = () => {
    const res = StorageService.approveAllPendingStockOpname(currentUser);
    if (res.success) {
      reloadData();
      showToast('success', res.message);
    } else {
      showToast('error', res.message);
    }
  };

  // Handler: Master Barang Save & Delete
  const handleSaveMasterItem = (item: MasterBarang, isNew: boolean) => {
    const master = StorageService.getMasterBarang();
    if (isNew) {
      master.push(item);
      StorageService.addLog('TAMBAH_MASTER_BARANG', 'Master Barang', `Tambah barang baru: ${item.namaBarang} (${item.kodeBarang})`, currentUser);
    } else {
      const idx = master.findIndex((m) => m.kodeBarang === item.kodeBarang);
      if (idx >= 0) {
        master[idx] = item;
        StorageService.addLog('EDIT_MASTER_BARANG', 'Master Barang', `Update data barang: ${item.namaBarang} (${item.kodeBarang})`, currentUser);
      }
    }
    StorageService.setMasterBarang(master);
    reloadData();
    showToast('success', `Data barang ${item.namaBarang} berhasil disimpan.`);
  };

  const handleDeleteMasterItem = (kodeBarang: string) => {
    if (currentUser.role !== 'ADMIN') {
      showToast('error', 'Hanya Admin yang berhak menghapus data dari Master Barang.');
      return;
    }
    let master = StorageService.getMasterBarang();
    const target = master.find((m) => m.kodeBarang === kodeBarang);
    master = master.filter((m) => m.kodeBarang !== kodeBarang);
    StorageService.setMasterBarang(master);
    StorageService.addLog('HAPUS_MASTER_BARANG', 'Master Barang', `Hapus barang: ${target?.namaBarang || kodeBarang}`, currentUser);
    reloadData();
    showToast('success', `Barang ${target?.namaBarang || kodeBarang} berhasil dihapus dari Master Barang.`);
  };

  // Handler: Users Save & Toggle
  const handleSaveUser = (user: User, isNew: boolean) => {
    const currentUsers = StorageService.getUsers();
    if (isNew) {
      currentUsers.push(user);
      StorageService.addLog('BUAT_USER', 'Kelola Akses', `Membuat akun baru: @${user.username} (${user.namaLengkap})`, currentUser);
    } else {
      const idx = currentUsers.findIndex((u) => u.id === user.id);
      if (idx >= 0) {
        currentUsers[idx] = user;
        StorageService.addLog('EDIT_USER', 'Kelola Akses', `Memperbarui izin akses akun @${user.username}`, currentUser);
      }
    }
    StorageService.setUsers(currentUsers);
    reloadData();
    showToast('success', `Akun @${user.username} berhasil disimpan.`);
  };

  const handleToggleUserStatus = (userId: string) => {
    const currentUsers = StorageService.getUsers();
    const u = currentUsers.find((user) => user.id === userId);
    if (!u) return;

    u.status = u.status === 'AKTIF' ? 'NONAKTIF' : 'AKTIF';
    StorageService.setUsers(currentUsers);
    StorageService.addLog(
      'UBAH_STATUS_USER',
      'Kelola Akses',
      `Status akun @${u.username} diubah menjadi ${u.status}`,
      currentUser
    );
    reloadData();
    showToast('success', `Status akun @${u.username} kini: ${u.status}`);
  };

  // Handler: Sync Now
  const handleSyncNow = async () => {
    setIsSyncing(true);
    const res = await StorageService.syncWithGoogleAppsScript();
    setIsSyncing(false);
    reloadData();
    if (res.success) {
      showToast('success', res.message);
    } else {
      showToast('error', res.message);
    }
  };

  // Handler: Reset Database to 75 Initial Items
  const handleResetDatabase = () => {
    StorageService.resetToInitialCatalog(currentUser);
    reloadData();
    showToast('success', 'Database berhasil dikembalikan ke 75 inventaris awal bawaan PDF.');
  };

  // Render view router
  const renderCurrentView = () => {
    switch (activeMenu) {
      case 'dashboard':
        return (
          <DashboardView
            masterBarang={masterBarang}
            peminjaman={peminjaman}
            pengembalian={pengembalian}
            barangMasuk={barangMasuk}
            barangRusak={barangRusak}
            perbaikan={perbaikan}
            pembelian={pembelian}
            stockOpname={stockOpname}
            onNavigate={(menu) => setActiveMenu(menu)}
          />
        );

      case 'masterBarang':
        return (
          <MasterBarangView
            masterBarang={masterBarang}
            onSaveItem={handleSaveMasterItem}
            onDeleteItem={handleDeleteMasterItem}
            currentUser={currentUser}
            peminjamanList={peminjaman}
            barangRusakList={barangRusak}
            perbaikanList={perbaikan}
          />
        );

      case 'peminjaman':
        return (
          <PeminjamanView
            masterBarang={masterBarang}
            peminjamanList={peminjaman}
            onCreatePeminjaman={handleCreatePeminjaman}
            onPrintSuratJalan={(loan) => {
              setSelectedLoanForPrint(loan);
              setIsSuratJalanModalOpen(true);
            }}
            currentUser={currentUser}
          />
        );

      case 'pengembalian':
        return (
          <PengembalianView
            peminjamanList={peminjaman}
            pengembalianList={pengembalian}
            onProcessPengembalian={handleProcessPengembalian}
            currentUser={currentUser}
          />
        );

      case 'barangMasuk':
        return (
          <BarangMasukView
            masterBarang={masterBarang}
            barangMasukList={barangMasuk}
            onProcessBarangMasuk={handleProcessBarangMasuk}
            currentUser={currentUser}
          />
        );

      case 'barangRusak':
        return (
          <BarangRusakView
            barangRusakList={barangRusak}
            masterBarang={masterBarang}
            onAlihkanKePerbaikan={handleAlihkanKePerbaikan}
            onAlihkanKePembelian={handleAlihkanKePembelian}
            onManualReportDamage={handleManualReportDamage}
            currentUser={currentUser}
          />
        );

      case 'perbaikan':
        return (
          <PerbaikanView
            perbaikanList={perbaikan}
            onUpdateStatusPerbaikan={handleUpdateStatusPerbaikan}
            currentUser={currentUser}
          />
        );

      case 'pembelian':
        return (
          <PembelianView
            pembelianList={pembelian}
            masterBarang={masterBarang}
            onUpdateStatusPembelian={handleUpdateStatusPembelian}
            currentUser={currentUser}
          />
        );

      case 'stockOpname':
        return (
          <StockOpnameView
            stockOpnameList={stockOpname}
            masterBarang={masterBarang}
            onCreateOpname={handleCreateOpname}
            onCreateMultiOpname={handleCreateMultiOpname}
            onApproveOpname={handleApproveOpname}
            onApproveAllOpname={handleApproveAllOpname}
            currentUser={currentUser}
          />
        );

      case 'laporan':
        return (
          <LaporanView
            masterBarang={masterBarang}
            peminjamanList={peminjaman}
            pengembalianList={pengembalian}
            barangMasukList={barangMasuk}
            barangRusakList={barangRusak}
            perbaikanList={perbaikan}
            pembelianList={pembelian}
            stockOpnameList={stockOpname}
            logsList={logs}
            currentUser={currentUser}
          />
        );

      case 'kelolaAkses':
        if (currentUser.role !== 'ADMIN') return null;
        return (
          <KelolaAksesView
            users={users}
            onSaveUser={handleSaveUser}
            onToggleUserStatus={handleToggleUserStatus}
            currentUser={currentUser}
            sheetsConfig={sheetsConfig}
            onSaveSheetsConfig={(cfg) => {
              StorageService.setGSheetsConfig(cfg);
              setSheetsConfig(cfg);
            }}
            onTestSync={handleSyncNow}
            onResetDatabase={handleResetDatabase}
            isSyncing={isSyncing}
          />
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 selection:bg-emerald-500 selection:text-white">
      {/* Toast Notification */}
      {toast && (
        <div
          className={`fixed bottom-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-lg border text-xs font-semibold animate-in slide-in-from-bottom duration-200 no-print ${
            toast.type === 'success'
              ? 'bg-slate-900 text-white border-slate-800'
              : 'bg-rose-900 text-white border-rose-800'
          }`}
        >
          {toast.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-300 shrink-0" />
          )}
          <span>{toast.message}</span>
          <button onClick={() => setToast(null)} className="ml-2 text-slate-400 hover:text-white">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Header */}
      <Header
        currentUser={currentUser}
        onLogout={() => setIsLoginModalOpen(true)}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
        onOpenLabelModal={() => setIsLabelModalOpen(true)}
        onOpenSuratJalanModal={() => setIsSuratJalanModalOpen(true)}
        onOpenDbModal={() => setIsDbModalOpen(true)}
        sheetsConfig={sheetsConfig}
        onSyncNow={handleSyncNow}
        isSyncing={isSyncing}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
      />

      {/* Main Workspace: Sidebar + Content */}
      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          activeMenu={activeMenu}
          onSelectMenu={(menu) => setActiveMenu(menu)}
          currentUser={currentUser}
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
          badgeCounts={badgeCounts}
        />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 max-w-[1600px] w-full">
          {renderCurrentView()}
        </main>
      </div>

      {/* Global Modals */}
      <PrintLabelModal
        isOpen={isLabelModalOpen}
        onClose={() => setIsLabelModalOpen(false)}
        masterBarang={masterBarang}
      />

      <PrintSuratJalanModal
        isOpen={isSuratJalanModalOpen}
        onClose={() => {
          setIsSuratJalanModalOpen(false);
          setSelectedLoanForPrint(null);
        }}
        peminjamanList={peminjaman}
        initialLoan={selectedLoanForPrint}
      />

      <DatabaseSetupModal
        isOpen={isDbModalOpen}
        onClose={() => setIsDbModalOpen(false)}
        sheetsConfig={sheetsConfig}
        onSaveConfig={(cfg) => {
          StorageService.setGSheetsConfig(cfg);
          setSheetsConfig(cfg);
          showToast('success', 'Pengaturan Google Spreadsheet disimpan.');
        }}
        onTestSync={handleSyncNow}
        isSyncing={isSyncing}
      />

      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        users={users}
        currentUser={currentUser}
        onSelectUser={(u) => {
          StorageService.setCurrentUser(u);
          setCurrentUser(u);
          showToast('success', `Berhasil beralih ke akun: ${u.namaLengkap} (${u.role})`);
        }}
      />
    </div>
  );
}
