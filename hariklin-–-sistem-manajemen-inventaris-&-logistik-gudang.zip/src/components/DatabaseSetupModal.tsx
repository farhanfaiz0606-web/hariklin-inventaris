import React, { useState } from 'react';
import {
  X,
  Database,
  RefreshCw,
  Copy,
  Check,
  ExternalLink,
  ShieldCheck,
  FileCode,
  FileSpreadsheet,
  Download,
  AlertTriangle,
  HelpCircle,
  Activity,
} from 'lucide-react';
import { GoogleSheetsConfig } from '../types';
import { GOOGLE_APPS_SCRIPT_CODE } from '../services/googleAppsScriptCode';
import { StorageService } from '../services/storageService';
import { copyTableToSpreadsheetClipboard, exportToCSV } from '../utils/exportUtils';

interface DatabaseSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  sheetsConfig: GoogleSheetsConfig;
  onSaveConfig: (config: GoogleSheetsConfig) => void;
  onTestSync: () => Promise<void>;
  isSyncing: boolean;
}

export const DatabaseSetupModal: React.FC<DatabaseSetupModalProps> = ({
  isOpen,
  onClose,
  sheetsConfig,
  onSaveConfig,
  onTestSync,
  isSyncing,
}) => {
  const [webAppUrl, setWebAppUrl] = useState(sheetsConfig.webAppUrl || '');
  const [spreadsheetUrl, setSpreadsheetUrl] = useState(sheetsConfig.spreadsheetUrl || '');
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedDataMsg, setCopiedDataMsg] = useState('');
  const [feedbackMsg, setFeedbackMsg] = useState('');
  const [isTestingPing, setIsTestingPing] = useState(false);
  const [pingResult, setPingResult] = useState<{ success: boolean; message: string } | null>(null);

  if (!isOpen) return null;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(GOOGLE_APPS_SCRIPT_CODE);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2500);
  };

  const handleCopyMasterBarangTabular = async () => {
    const items = StorageService.getMasterBarang();
    const success = await copyTableToSpreadsheetClipboard(items);
    if (success) {
      setCopiedDataMsg('Data 75 barang berhasil disalin! Buka Google Spreadsheet > Klik cell A1 > Tekan Ctrl+V (Paste).');
      setTimeout(() => setCopiedDataMsg(''), 6000);
    }
  };

  const handleDownloadMasterCSV = () => {
    exportToCSV('Master_Barang_Hariklin_75Item', StorageService.getMasterBarang());
  };

  const handleTestPing = async () => {
    setIsTestingPing(true);
    setPingResult(null);
    const res = await StorageService.testGoogleAppsScriptConnection(webAppUrl);
    setIsTestingPing(false);
    setPingResult(res);
  };

  const validation = webAppUrl ? StorageService.validateWebAppUrl(webAppUrl) : { isValid: true };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveConfig({
      ...sheetsConfig,
      webAppUrl: webAppUrl.trim(),
      spreadsheetUrl: spreadsheetUrl.trim(),
    });
    setFeedbackMsg('Konfigurasi URL Google Apps Script disimpan!');
    setTimeout(() => setFeedbackMsg(''), 3000);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-2xl max-h-[92vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-emerald-600" />
            <h3 className="font-bold text-slate-900 text-sm">Status &amp; Koneksi Google Spreadsheet</h3>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-600 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-5 text-xs">
          {/* SECTION 1: SOLUSI INSTAN MENGISI DATA KE SPREADSHEET */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 space-y-3">
            <div className="flex items-start justify-between gap-2">
              <div>
                <span className="font-bold text-emerald-950 text-xs flex items-center gap-1.5">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                  Isi Data Langsung ke Google Spreadsheet (100% Instan)
                </span>
                <p className="text-[11px] text-emerald-800 mt-1 leading-relaxed">
                  Jika web belum tersambung ke Apps Script, Anda dapat langsung memasukkan seluruh 75 data barang ke Google Spreadsheet Anda detik ini juga tanpa hambatan:
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-1">
              <button
                type="button"
                onClick={handleCopyMasterBarangTabular}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold text-xs shadow-xs flex items-center gap-1.5"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Salin 75 Data Barang (Siap Paste di Spreadsheet)</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadMasterCSV}
                className="px-3.5 py-2 bg-white hover:bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-lg font-semibold text-xs shadow-2xs flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5 text-emerald-600" />
                <span>Download File CSV Master Barang</span>
              </button>
            </div>

            {copiedDataMsg && (
              <div className="p-2.5 rounded-lg bg-emerald-600 text-white text-[11px] font-medium flex items-center gap-2 animate-in fade-in">
                <Check className="w-4 h-4 shrink-0 text-emerald-200" />
                <span>{copiedDataMsg}</span>
              </div>
            )}
          </div>

          {/* SECTION 2: STATUS & PENGATURAN KONEKSI GOOGLE APPS SCRIPT */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[11px] text-slate-500">Status Database:</span>
                <div className="flex items-center gap-2 mt-0.5">
                  <span
                    className={`w-2.5 h-2.5 rounded-full ${
                      sheetsConfig.status === 'connected'
                        ? 'bg-emerald-500'
                        : sheetsConfig.status === 'syncing'
                        ? 'bg-blue-500 animate-pulse'
                        : sheetsConfig.status === 'error'
                        ? 'bg-rose-500'
                        : 'bg-amber-400'
                    }`}
                  />
                  <span className="font-bold text-slate-900 text-xs uppercase">
                    {sheetsConfig.status === 'connected'
                      ? 'Terhubung dengan Google Apps Script'
                      : sheetsConfig.status === 'syncing'
                      ? 'Sedang Menyinkronkan...'
                      : sheetsConfig.status === 'error'
                      ? 'Koneksi Terkendala'
                      : 'Belum Terhubung'}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleTestPing}
                  disabled={isTestingPing || !webAppUrl}
                  className="px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg text-slate-700 font-semibold text-[11px] flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Activity className={`w-3.5 h-3.5 ${isTestingPing ? 'animate-spin text-purple-600' : 'text-slate-500'}`} />
                  <span>{isTestingPing ? 'Mengecek...' : 'Uji Ping'}</span>
                </button>

                <button
                  type="button"
                  onClick={onTestSync}
                  disabled={isSyncing}
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold text-xs shadow-xs flex items-center gap-1.5 disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>{isSyncing ? 'Menyinkronkan...' : 'Sinkronkan Sekarang'}</span>
                </button>
              </div>
            </div>

            {pingResult && (
              <div
                className={`p-2.5 rounded-lg border text-xs flex items-center gap-2 ${
                  pingResult.success
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : 'bg-rose-50 border-rose-200 text-rose-800'
                }`}
              >
                {pingResult.success ? (
                  <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                )}
                <span>{pingResult.message}</span>
              </div>
            )}

            {sheetsConfig.errorMessage && (
              <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-[11px] flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">Kendala Terdeteksi: </span>
                  <span>{sheetsConfig.errorMessage}</span>
                </div>
              </div>
            )}
          </div>

          {/* SECTION 3: FORM URL APPS SCRIPT */}
          <form onSubmit={handleSave} className="space-y-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Google Apps Script Web App URL *
              </label>
              <input
                type="url"
                required
                placeholder="https://script.google.com/macros/s/AKfycb.../exec"
                value={webAppUrl}
                onChange={(e) => setWebAppUrl(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs focus:ring-2 focus:ring-emerald-500/20"
              />
              {!validation.isValid && validation.warning && (
                <p className="text-rose-600 text-[11px] mt-1 font-medium flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                  <span>{validation.warning}</span>
                </p>
              )}
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Tautan Dokumen Google Spreadsheet (Untuk Membuka Lembar Kerja)
              </label>
              <input
                type="url"
                placeholder="https://docs.google.com/spreadsheets/d/.../edit"
                value={spreadsheetUrl}
                onChange={(e) => setSpreadsheetUrl(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>

            {feedbackMsg && (
              <div className="p-2.5 rounded bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span>{feedbackMsg}</span>
              </div>
            )}

            <div className="flex items-center justify-between pt-1">
              {spreadsheetUrl ? (
                <a
                  href={spreadsheetUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs text-emerald-700 hover:underline flex items-center gap-1 font-semibold"
                >
                  <span>Buka Lembar Kerja Google Spreadsheet</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              ) : (
                <div />
              )}

              <button
                type="submit"
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold text-xs"
              >
                Simpan Tautan
              </button>
            </div>
          </form>

          {/* SECTION 4: KENAPA TIDAK BISA TERSAMBUNG? (TROUBLESHOOTING GUIDE) */}
          <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 space-y-2">
            <span className="font-bold text-amber-950 flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-amber-700" />
              Mengapa Web Tidak Mau Tersambung? (Pemeriksaan 3 Menit)
            </span>
            <ul className="list-disc list-inside space-y-1 text-slate-700 leading-relaxed text-[11px]">
              <li>
                <strong>Opsi Akses (Paling Sering):</strong> Saat Deploy Web App di Google Apps Script, opsi <em>"Who has access"</em> <strong>WAJIB dipilih "Anyone" (Siapa saja)</strong>. Jika dipilih "Only myself", Google akan memblokir kiriman data dari web.
              </li>
              <li>
                <strong>Tautan Berakhiran /exec:</strong> Pastikan tautan yang disalin adalah link Web App yang berakhiran <code>/exec</code>, bukan tautan dokumen spreadsheet (<code>docs.google.com/spreadsheets</code>) atau tautan editor (<code>/edit</code>).
              </li>
              <li>
                <strong>Izin Akun Google:</strong> Pastikan saat pertama kali deploy telah mengeklik <em>Review Permissions &gt; Akun Anda &gt; Advanced &gt; Go to Untitled project (unsafe) &gt; Allow</em>.
              </li>
            </ul>
          </div>

          {/* SECTION 5: KODE CODE.GS */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-900 flex items-center gap-1.5">
                <FileCode className="w-4 h-4 text-emerald-600" />
                Kode Backend Google Apps Script (Code.gs)
              </span>
              <button
                type="button"
                onClick={handleCopyCode}
                className="px-3 py-1 bg-white hover:bg-slate-100 border border-slate-300 rounded text-slate-700 font-semibold text-[11px] flex items-center gap-1"
              >
                {copiedCode ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                <span>{copiedCode ? 'Tersalin!' : 'Salin Code.gs'}</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-500">
              Tempelkan kode ini di menu <strong>Ekstensi &gt; Apps Script</strong> pada Google Spreadsheet Anda.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 text-white font-semibold text-xs"
          >
            Selesai
          </button>
        </div>
      </div>
    </div>
  );
};
