import React, { useState } from 'react';
import {
  ShieldCheck,
  UserPlus,
  Edit2,
  Lock,
  Unlock,
  Database,
  Copy,
  Check,
  RefreshCw,
  ExternalLink,
  Shield,
  User as UserIcon,
  AlertCircle,
  FileCode,
  RotateCcw,
  FileSpreadsheet,
  Download,
  AlertTriangle,
  HelpCircle,
  Activity,
} from 'lucide-react';
import { User, UserRole, UserPermissions, GoogleSheetsConfig } from '../types';
import { GOOGLE_APPS_SCRIPT_CODE } from '../services/googleAppsScriptCode';
import { copyTableToSpreadsheetClipboard, exportToCSV } from '../utils/exportUtils';
import { StorageService } from '../services/storageService';

interface KelolaAksesViewProps {
  users: User[];
  onSaveUser: (user: User, isNew: boolean) => void;
  onToggleUserStatus: (userId: string) => void;
  currentUser: User;
  sheetsConfig: GoogleSheetsConfig;
  onSaveSheetsConfig: (config: GoogleSheetsConfig) => void;
  onTestSync: () => Promise<void>;
  onResetDatabase: () => void;
  isSyncing: boolean;
}

export const KelolaAksesView: React.FC<KelolaAksesViewProps> = ({
  users,
  onSaveUser,
  onToggleUserStatus,
  currentUser,
  sheetsConfig,
  onSaveSheetsConfig,
  onTestSync,
  onResetDatabase,
  isSyncing,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'PENGGUNA' | 'DATABASE_GAS'>('PENGGUNA');
  const [copiedCode, setCopiedCode] = useState(false);

  // Form State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  const [username, setUsername] = useState('');
  const [namaLengkap, setNamaLengkap] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>('PETUGAS');
  const [permissions, setPermissions] = useState<UserPermissions>({
    dashboard: true,
    masterBarang: true,
    peminjaman: true,
    pengembalian: true,
    barangMasuk: true,
    barangRusak: true,
    perbaikan: true,
    pembelian: false,
    stockOpname: true,
    laporan: true,
  });

  // Spreadsheet URL configuration state
  const [webAppUrl, setWebAppUrl] = useState(sheetsConfig.webAppUrl || '');
  const [spreadsheetUrl, setSpreadsheetUrl] = useState(sheetsConfig.spreadsheetUrl || '');
  const [saveSuccessMsg, setSaveSuccessMsg] = useState('');
  const [copiedDataMsg, setCopiedDataMsg] = useState('');
  const [isTestingPing, setIsTestingPing] = useState(false);
  const [pingResult, setPingResult] = useState<{ success: boolean; message: string } | null>(null);

  const handleCopyMasterBarangTabular = async () => {
    const items = StorageService.getMasterBarang();
    const success = await copyTableToSpreadsheetClipboard(items);
    if (success) {
      setCopiedDataMsg('Data 75 barang berhasil disalin! Buka Google Spreadsheet > Klik cell A1 > Tekan Ctrl+V (Paste).');
      setTimeout(() => setCopiedDataMsg(''), 6000);
    }
  };

  const handleDownloadMasterCSV = () => {
    exportToCSV('Master_Barang_Hariklin_75Item', StorageService.getMasterBarang());
  };

  const handleTestPing = async () => {
    setIsTestingPing(true);
    setPingResult(null);
    const res = await StorageService.testGoogleAppsScriptConnection(webAppUrl);
    setIsTestingPing(false);
    setPingResult(res);
  };

  const validation = webAppUrl ? StorageService.validateWebAppUrl(webAppUrl) : { isValid: true };

  const menuCheckboxes: { key: keyof UserPermissions; label: string; desc: string }[] = [
    { key: 'dashboard', label: 'Dashboard', desc: 'Melihat ringkasan statistik dan grafik inventaris' },
    { key: 'masterBarang', label: 'Master Barang', desc: 'Melihat dan mengelola database katalog barang' },
    { key: 'peminjaman', label: 'Peminjaman Alat', desc: 'Menginput peminjaman alat lapangan dan cetak surat jalan' },
    { key: 'pengembalian', label: 'Pengembalian Alat', desc: 'Menerima pengembalian alat baik maupun rusak' },
    { key: 'barangMasuk', label: 'Barang Masuk', desc: 'Mencatat penerimaan barang baru dari vendor' },
    { key: 'barangRusak', label: 'Barang Rusak', desc: 'Melihat dan menindaklanjuti inventaris rusak' },
    { key: 'perbaikan', label: 'Perbaikan Barang', desc: 'Mengerjakan tiket servis dan mengajukan perbaikan selesai' },
    { key: 'pembelian', label: 'Pembelian Barang', desc: 'Mengajukan atau memproses pembelian barang baru' },
    { key: 'stockOpname', label: 'Stock Opname', desc: 'Melakukan audit fisik inventaris di rak gudang' },
    { key: 'laporan', label: 'Laporan', desc: 'Melihat dan mengekspor rekapitulasi data' },
  ];

  const handleOpenAddUser = () => {
    setEditingUser(null);
    setUsername('');
    setNamaLengkap('');
    setEmail('');
    setRole('PETUGAS');
    setPermissions({
      dashboard: true,
      masterBarang: true,
      peminjaman: true,
      pengembalian: true,
      barangMasuk: false,
      barangRusak: true,
      perbaikan: true,
      pembelian: false,
      stockOpname: false,
      laporan: false,
    });
    setIsModalOpen(true);
  };

  const handleOpenEditUser = (user: User) => {
    setEditingUser(user);
    setUsername(user.username);
    setNamaLengkap(user.namaLengkap);
    setEmail(user.email);
    setRole(user.role);
    setPermissions({ ...user.permissions });
    setIsModalOpen(true);
  };

  const handleTogglePermission = (key: keyof UserPermissions) => {
    setPermissions((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const handleSubmitUserForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !namaLengkap.trim()) {
      alert('Username dan nama lengkap wajib diisi!');
      return;
    }

    if (editingUser) {
      const updated: User = {
        ...editingUser,
        username: username.trim(),
        namaLengkap: namaLengkap.trim(),
        email: email.trim(),
        role,
        permissions: role === 'ADMIN' ? { ...permissions, kelolaAkses: true } : { ...permissions, kelolaAkses: false },
      };
      onSaveUser(updated, false);
    } else {
      const newUser: User = {
        id: 'USR-' + Date.now(),
        username: username.trim().toLowerCase(),
        namaLengkap: namaLengkap.trim(),
        email: email.trim(),
        role,
        status: 'AKTIF',
        permissions: role === 'ADMIN' ? { ...permissions, kelolaAkses: true } : { ...permissions, kelolaAkses: false },
        createdAt: new Date().toISOString().split('T')[0],
      };
      onSaveUser(newUser, true);
    }

    setIsModalOpen(false);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(GOOGLE_APPS_SCRIPT_CODE);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2500);
  };

  const handleSaveGSheetsSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSheetsConfig({
      ...sheetsConfig,
      webAppUrl: webAppUrl.trim(),
      spreadsheetUrl: spreadsheetUrl.trim(),
    });
    setSaveSuccessMsg('Konfigurasi URL Google Apps Script berhasil disimpan!');
    setTimeout(() => setSaveSuccessMsg(''), 3000);
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Kelola Akses &amp; Integrasi Database</h1>
            <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
              Khusus Admin
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Manajemen akun petugas, izin akses per-menu dengan checkbox, dan pengaturan Google Spreadsheet &amp; Apps Script
          </p>
        </div>

        {/* Subtab Buttons */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
          <button
            onClick={() => setActiveSubTab('PENGGUNA')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${
              activeSubTab === 'PENGGUNA'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Akun &amp; Hak Akses
          </button>
          <button
            onClick={() => setActiveSubTab('DATABASE_GAS')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${
              activeSubTab === 'DATABASE_GAS'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Google Spreadsheet &amp; Apps Script
          </button>
        </div>
      </div>

      {/* SUBTAB 1: DAFTAR PENGGUNA & HAK AKSES */}
      {activeSubTab === 'PENGGUNA' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="text-xs text-slate-600">
              Terdapat <strong className="text-slate-900">{users.length}</strong> pengguna terdaftar.
            </div>

            <button
              onClick={handleOpenAddUser}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Tambah Akun Petugas</span>
            </button>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                    <th className="py-3 px-3">Username</th>
                    <th className="py-3 px-3">Nama Lengkap</th>
                    <th className="py-3 px-3">Email</th>
                    <th className="py-3 px-3 text-center">Role</th>
                    <th className="py-3 px-3">Menu Diizinkan</th>
                    <th className="py-3 px-3 text-center">Status Akun</th>
                    <th className="py-3 px-3 text-center">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {users.map((u) => {
                    const activeCount = Object.values(u.permissions).filter(Boolean).length;

                    return (
                      <tr key={u.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-3 font-mono font-bold text-slate-900">{u.username}</td>
                        <td className="py-3 px-3 font-semibold text-slate-900">{u.namaLengkap}</td>
                        <td className="py-3 px-3 text-slate-600">{u.email || '-'}</td>
                        <td className="py-3 px-3 text-center">
                          <span
                            className={`text-[11px] px-2 py-0.5 rounded font-mono font-bold ${
                              u.role === 'ADMIN'
                                ? 'bg-slate-900 text-white'
                                : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            }`}
                          >
                            {u.role}
                          </span>
                        </td>
                        <td className="py-3 px-3">
                          {u.role === 'ADMIN' ? (
                            <span className="text-[11px] font-semibold text-slate-900">
                              Seluruh Menu (Akses Penuh)
                            </span>
                          ) : (
                            <div className="text-[11px] text-slate-600">
                              <span className="font-semibold text-slate-800">{activeCount} Menu:</span>{' '}
                              {Object.entries(u.permissions)
                                .filter(([k, v]) => v && k !== 'kelolaAkses')
                                .map(([k]) => k)
                                .join(', ')}
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-3 text-center">
                          <span
                            className={`text-[11px] px-2 py-0.5 rounded font-semibold ${
                              u.status === 'AKTIF'
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : 'bg-rose-50 text-rose-700 border border-rose-200'
                            }`}
                          >
                            {u.status}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => handleOpenEditUser(u)}
                              className="p-1.5 rounded text-slate-500 hover:text-emerald-700 hover:bg-slate-100"
                              title="Edit Hak Akses Akun"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            {u.id !== currentUser.id && (
                              <button
                                onClick={() => onToggleUserStatus(u.id)}
                                className={`p-1.5 rounded transition-colors ${
                                  u.status === 'AKTIF'
                                    ? 'text-rose-600 hover:bg-rose-50'
                                    : 'text-emerald-600 hover:bg-emerald-50'
                                }`}
                                title={u.status === 'AKTIF' ? 'Nonaktifkan Akun' : 'Aktifkan Akun'}
                              >
                                {u.status === 'AKTIF' ? (
                                  <Lock className="w-3.5 h-3.5" />
                                ) : (
                                  <Unlock className="w-3.5 h-3.5" />
                                )}
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: INTEGRASI GOOGLE APPS SCRIPT & DATABASE */}
      {activeSubTab === 'DATABASE_GAS' && (
        <div className="space-y-6">
          {/* SECTION 1: SOLUSI INSTAN MENGISI DATA KE SPREADSHEET */}
          <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-xl border border-emerald-200 p-5 shadow-xs space-y-3.5">
            <div>
              <h2 className="text-sm font-bold text-emerald-950 flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                <span>Isi Data Langsung ke Google Spreadsheet (100% Instan &amp; Pasti Berhasil)</span>
              </h2>
              <p className="text-xs text-emerald-800 mt-1 leading-relaxed">
                Jika web belum tersambung ke Google Apps Script karena kendala izin akun Google, Anda dapat mengisi seluruh 75 data Master Barang langsung ke Google Spreadsheet Anda detik ini juga:
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-1">
              <button
                type="button"
                onClick={handleCopyMasterBarangTabular}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold text-xs shadow-xs flex items-center gap-1.5"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Salin 75 Data Barang (Siap Paste di Spreadsheet)</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadMasterCSV}
                className="px-4 py-2 bg-white hover:bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-lg font-semibold text-xs shadow-2xs flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5 text-emerald-600" />
                <span>Download File CSV Master Barang</span>
              </button>
            </div>

            {copiedDataMsg && (
              <div className="p-3 rounded-lg bg-emerald-600 text-white text-xs font-medium flex items-center gap-2 animate-in fade-in">
                <Check className="w-4 h-4 shrink-0 text-emerald-200" />
                <span>{copiedDataMsg}</span>
              </div>
            )}
          </div>

          {/* SECTION 2: STATUS & PENGATURAN KONEKSI GOOGLE APPS SCRIPT */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
              <div>
                <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-600" />
                  <span>Pengaturan Koneksi Google Apps Script Web App</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Masukkan Web App URL yang berakhiran <code>/exec</code> untuk sinkronisasi otomatis dua arah.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleTestPing}
                  disabled={isTestingPing || !webAppUrl}
                  className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg text-slate-700 font-semibold text-xs flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Activity className={`w-3.5 h-3.5 ${isTestingPing ? 'animate-spin text-purple-600' : 'text-slate-500'}`} />
                  <span>{isTestingPing ? 'Mengecek...' : 'Uji Ping Koneksi'}</span>
                </button>
              </div>
            </div>

            {pingResult && (
              <div
                className={`p-3 rounded-lg border text-xs flex items-center gap-2.5 ${
                  pingResult.success
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : 'bg-rose-50 border-rose-200 text-rose-800'
                }`}
              >
                {pingResult.success ? (
                  <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                )}
                <span>{pingResult.message}</span>
              </div>
            )}

            <form onSubmit={handleSaveGSheetsSettings} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Google Apps Script Web App URL *
                </label>
                <input
                  type="url"
                  required
                  placeholder="https://script.google.com/macros/s/AKfycbx.../exec"
                  value={webAppUrl}
                  onChange={(e) => setWebAppUrl(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs focus:ring-2 focus:ring-emerald-500/20"
                />
                {!validation.isValid && validation.warning && (
                  <p className="text-rose-600 text-[11px] mt-1.5 font-medium flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>{validation.warning}</span>
                  </p>
                )}
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Google Spreadsheet Document URL (Untuk Akses Cepat Lembar Kerja)
                </label>
                <input
                  type="url"
                  placeholder="https://docs.google.com/spreadsheets/d/.../edit"
                  value={spreadsheetUrl}
                  onChange={(e) => setSpreadsheetUrl(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              {saveSuccessMsg && (
                <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>{saveSuccessMsg}</span>
                </div>
              )}

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-xs"
                >
                  Simpan Konfigurasi
                </button>

                <button
                  type="button"
                  onClick={onTestSync}
                  disabled={isSyncing}
                  className="px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs shadow-xs flex items-center gap-1.5 disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>{isSyncing ? 'Menyinkronkan...' : 'Uji Sinkronisasi Sekarang'}</span>
                </button>

                {spreadsheetUrl && (
                  <a
                    href={spreadsheetUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3.5 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 font-semibold text-xs flex items-center gap-1.5"
                  >
                    <span>Buka Google Spreadsheet</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            </form>
          </div>

          {/* SECTION 3: MENGAPA WEB TIDAK MAU TERSAMBUNG? (TROUBLESHOOTING GUIDE) */}
          <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-5 text-xs space-y-3">
            <h3 className="font-bold text-amber-950 flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-amber-700" />
              <span>Mengapa Web Tidak Mau Tersambung dengan Spreadsheet? (Cek Hal Berikut)</span>
            </h3>
            <ul className="list-disc list-inside space-y-1.5 text-slate-700 leading-relaxed text-[11px]">
              <li>
                <strong>Opsi Akses (Paling Sering Terjadi):</strong> Saat Anda mengeklik <em>Deploy &gt; New deployment &gt; Web app</em> di Google Apps Script, pastikan opsi <strong>"Who has access" (Siapa yang memiliki akses)</strong> disetel ke <strong>"Anyone" (Siapa saja)</strong>. Jika disetel "Only myself", Google akan memblokir request koneksi browser dengan error <em>Failed to fetch</em>.
              </li>
              <li>
                <strong>Tautan Berakhiran /exec:</strong> Pastikan tautan yang Anda masukkan ke kolom di atas berakhiran <code>/exec</code>, bukan tautan dokumen Google Spreadsheet (<code>docs.google.com/spreadsheets/...</code>) atau link editor kode (<code>script.google.com/d/.../edit</code>).
              </li>
              <li>
                <strong>Izin Akses Google (Authorization):</strong> Saat pertama kali Deploy, Google akan meminta persetujuan akun Google Anda. Klik <em>Review Permissions &gt; Pilih Akun &gt; Advanced &gt; Go to Untitled project (unsafe) &gt; Allow</em>.
              </li>
              <li>
                <strong>Deploy Ulang Jika Mengubah Kode:</strong> Jika ada perubahan pada script, klik <em>Deploy &gt; Manage deployments &gt; Edit &gt; Version: New version &gt; Deploy</em>.
              </li>
            </ul>
          </div>

          {/* Code.gs Viewer & Instructions */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
              <div>
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-emerald-600" />
                  <span>Kode Backend Google Apps Script (Code.gs)</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Salin dan tempelkan kode ini ke Apps Script Editor di Google Spreadsheet Anda.
                </p>
              </div>

              <button
                onClick={handleCopyCode}
                className="flex items-center gap-1.5 px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold transition-colors shrink-0"
              >
                {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedCode ? 'Tersalin ke Clipboard!' : 'Salin Seluruh Kode'}</span>
              </button>
            </div>

            {/* Step-by-step installation instructions */}
            <div className="mt-4 p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-2">
              <span className="font-bold text-slate-800">Langkah Pemasangan di Google Spreadsheet:</span>
              <ol className="list-decimal list-inside space-y-1 text-slate-600 leading-relaxed">
                <li>Buka Google Spreadsheet Anda &rarr; Klik menu <strong>Ekstensi &gt; Apps Script</strong>.</li>
                <li>Hapus kode bawaan, lalu <strong>Tempel (Paste)</strong> kode <code>Code.gs</code> di bawah ini.</li>
                <li>Simpan proyek, pilih fungsi <code>setupAllSheets</code> lalu klik <strong>Jalankan (Run)</strong> untuk membuat 12 sheet otomatis.</li>
                <li>Klik tombol <strong>Deploy &gt; New deployment</strong> &rarr; Pilih tipe <strong>Web app</strong>.</li>
                <li>Atur <em>Execute as: Me</em> dan <em>Who has access: Anyone</em> &rarr; Klik Deploy.</li>
                <li>Salin <strong>Web App URL</strong> yang dihasilkan dan tempelkan ke kolom URL di atas.</li>
              </ol>
            </div>

            {/* Code Box */}
            <div className="mt-4 relative rounded-lg border border-slate-800 bg-slate-950 p-4 font-mono text-[11px] text-slate-300 max-h-72 overflow-y-auto">
              <pre>{GOOGLE_APPS_SCRIPT_CODE}</pre>
            </div>
          </div>

          {/* Reset / Maintenance Zone */}
          <div className="bg-rose-50/50 rounded-xl border border-rose-200 p-5">
            <h3 className="text-sm font-bold text-rose-900 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600" />
              <span>Zona Pemulihan &amp; Reset Inventaris 75 Item Bawaan</span>
            </h3>
            <p className="text-xs text-rose-700 mt-1">
              Jika data rusak atau Anda ingin memulihkan 75 inventaris asli dari dokumen PDF Hariklin, Anda dapat mengklik tombol di bawah ini. Tindakan ini akan mengembalikan data katalog ke kondisi awal.
            </p>

            <button
              onClick={() => {
                if (confirm('Yakin ingin mereset seluruh database inventaris ke 75 item awal bawaan dokumen PDF? Data transaksi saat ini akan dibersihkan.')) {
                  onResetDatabase();
                  alert('Database berhasil dipulihkan ke 75 inventaris awal!');
                }
              }}
              className="mt-3 flex items-center gap-1.5 px-3.5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset ke 75 Inventaris Awal PDF</span>
            </button>
          </div>
        </div>
      )}

      {/* MODAL: Tambah / Edit Pengguna & Matriks Hak Akses Checkbox */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-xl max-h-[90vh] overflow-hidden flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-slate-200 bg-slate-50">
              <h3 className="font-bold text-slate-900 text-sm">
                {editingUser ? `Kelola Akses: ${editingUser.namaLengkap}` : 'Buat Akun Petugas Baru'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <Check className="sr-only" />
                <span className="font-bold text-sm">✕</span>
              </button>
            </div>

            <form onSubmit={handleSubmitUserForm} className="p-5 overflow-y-auto space-y-4 text-xs">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Username Login *</label>
                  <input
                    type="text"
                    required
                    readOnly={!!editingUser}
                    placeholder="misal: ahmad_gudang"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className={`w-full px-3 py-2 rounded-lg border font-mono text-xs ${
                      editingUser ? 'bg-slate-100 text-slate-500' : 'border-slate-300'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Nama Lengkap *</label>
                  <input
                    type="text"
                    required
                    placeholder="misal: Ahmad Fauzi"
                    value={namaLengkap}
                    onChange={(e) => setNamaLengkap(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Email</label>
                  <input
                    type="email"
                    placeholder="nama@hariklin.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Role Akun *</label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value as UserRole)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs bg-white font-semibold"
                  >
                    <option value="PETUGAS">PETUGAS (Hak akses dibatasi via checkbox)</option>
                    <option value="ADMIN">ADMIN (Akses penuh seluruh sistem &amp; persetujuan)</option>
                  </select>
                </div>
              </div>

              {/* Matriks Hak Akses Checkbox */}
              <div className="pt-2">
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-slate-800 font-bold text-xs">
                    Pengaturan Hak Akses Menu (Checkbox)
                  </label>
                  {role === 'ADMIN' && (
                    <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      Role Admin otomatis memiliki semua izin
                    </span>
                  )}
                </div>

                <div className="bg-slate-50 rounded-xl border border-slate-200 p-3 space-y-2">
                  {menuCheckboxes.map((item) => {
                    const isChecked = role === 'ADMIN' ? true : permissions[item.key] === true;
                    return (
                      <label
                        key={item.key}
                        className={`flex items-start gap-2.5 p-2 rounded-lg cursor-pointer transition-colors ${
                          isChecked ? 'bg-white shadow-2xs border border-slate-200' : 'hover:bg-slate-100/70'
                        }`}
                      >
                        <input
                          type="checkbox"
                          disabled={role === 'ADMIN'}
                          checked={isChecked}
                          onChange={() => handleTogglePermission(item.key)}
                          className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                        />
                        <div className="flex-1">
                          <div className="font-semibold text-slate-900 text-xs">{item.label}</div>
                          <div className="text-[11px] text-slate-500">{item.desc}</div>
                        </div>
                      </label>
                    );
                  })}

                  <div className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-200/50 text-slate-400">
                    <input type="checkbox" disabled checked={role === 'ADMIN'} className="mt-0.5 w-4 h-4 rounded" />
                    <div className="flex-1">
                      <div className="font-semibold text-xs">Kelola Akses (Khusus Admin)</div>
                      <div className="text-[11px]">Menu konfigurasi hak akses tidak tersedia untuk Petugas.</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 font-semibold hover:bg-slate-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold shadow-xs"
                >
                  {editingUser ? 'Simpan Izin Akses' : 'Buat Akun Pengguna'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
