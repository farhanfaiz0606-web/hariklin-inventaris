/**
 * Export and Print Utilities for HARIKLIN
 */

export function exportToCSV(filename: string, rows: Record<string, any>[], columnMap?: Record<string, string>) {
  if (!rows || !rows.length) {
    return;
  }

  const keys = Object.keys(rows[0]);
  const headers = keys.map((k) => (columnMap && columnMap[k] ? columnMap[k] : k));

  const csvRows: string[] = [];
  csvRows.push(headers.map(escapeCSVField).join(','));

  for (const row of rows) {
    const values = keys.map((k) => {
      let val = row[k];
      if (typeof val === 'object' && val !== null) {
        val = JSON.stringify(val);
      }
      return escapeCSVField(val !== undefined && val !== null ? String(val) : '');
    });
    csvRows.push(values.join(','));
  }

  // Prepend UTF-8 BOM so Excel opens accents and special characters without issue
  const csvContent = '\uFEFF' + csvRows.join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Salin data tabel ke clipboard dalam format TSV (Tab Separated Values)
 * Saat di-paste ke Google Spreadsheet / Excel, langsung otomatis terbagi rapi per kolom & baris!
 */
export async function copyTableToSpreadsheetClipboard(rows: Record<string, any>[], columnMap?: Record<string, string>): Promise<boolean> {
  if (!rows || !rows.length) return false;

  const keys = Object.keys(rows[0]);
  const headers = keys.map((k) => (columnMap && columnMap[k] ? columnMap[k] : k));

  const tsvLines: string[] = [];
  tsvLines.push(headers.join('\t'));

  for (const row of rows) {
    const values = keys.map((k) => {
      let val = row[k];
      if (typeof val === 'object' && val !== null) {
        val = JSON.stringify(val);
      }
      // Replace tabs and newlines inside cells to avoid breaking columns
      return val !== undefined && val !== null ? String(val).replace(/[\t\r\n]/g, ' ') : '';
    });
    tsvLines.push(values.join('\t'));
  }

  try {
    await navigator.clipboard.writeText(tsvLines.join('\n'));
    return true;
  } catch {
    return false;
  }
}

function escapeCSVField(val: string): string {
  if (val.includes(',') || val.includes('"') || val.includes('\n') || val.includes('\r')) {
    return `"${val.replace(/"/g, '""')}"`;
  }
  return val;
}

export function formatRupiah(num: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0,
  }).format(num);
}
