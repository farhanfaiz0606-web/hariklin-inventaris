import React, { useState } from 'react';
import {
  RefreshCw,
  Printer,
  FileCheck2,
  Database,
  LogOut,
  User as UserIcon,
  Shield,
  Menu,
} from 'lucide-react';
import { User, GoogleSheetsConfig } from '../types';

interface HeaderProps {
  currentUser: User;
  onLogout: () => void;
  onOpenLoginModal: () => void;
  onOpenLabelModal: () => void;
  onOpenSuratJalanModal: () => void;
  onOpenDbModal: () => void;
  sheetsConfig: GoogleSheetsConfig;
  onSyncNow: () => Promise<void>;
  isSyncing: boolean;
  onToggleSidebar?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onLogout,
  onOpenLoginModal,
  onOpenLabelModal,
  onOpenSuratJalanModal,
  onOpenDbModal,
  sheetsConfig,
  onSyncNow,
  isSyncing,
  onToggleSidebar,
}) => {
  const [logoError, setLogoError] = useState(false);

  const getStatusColor = () => {
    switch (sheetsConfig.status) {
      case 'connected':
        return 'text-emerald-700 bg-emerald-50 border-emerald-200';
      case 'syncing':
        return 'text-blue-700 bg-blue-50 border-blue-200';
      case 'error':
        return 'text-amber-700 bg-amber-50 border-amber-200';
      default:
        return 'text-slate-600 bg-slate-100 border-slate-200';
    }
  };

  const getStatusLabel = () => {
    switch (sheetsConfig.status) {
      case 'connected':
        return 'Google Spreadsheet Terhubung';
      case 'syncing':
        return 'Menyinkronkan...';
      case 'error':
        return 'Koneksi Error';
      default:
        return 'Mode Lokal (Siap Hubungkan)';
    }
  };

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-40 no-print">
      <div className="px-4 lg:px-6 py-3 flex items-center justify-between gap-4">
        {/* Brand & Title */}
        <div className="flex items-center gap-3">
          {onToggleSidebar && (
            <button
              onClick={onToggleSidebar}
              className="lg:hidden p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
              title="Menu Navigasi"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-white p-1 flex items-center justify-center shrink-0 shadow-sm overflow-hidden">
              {!logoError ? (
                <img
                  src="/hariklin-logo.jpg"
                  alt="HARIKLIN Logo"
                  className="w-full h-full object-contain"
                  onError={() => setLogoError(true)}
                />
              ) : (
                <span className="text-emerald-600 font-extrabold text-sm tracking-tighter">HK</span>
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold tracking-tight text-lg text-white">HARIKLIN</span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  GUDANG & LOGISTIK
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Sistem Manajemen Inventaris & Logistik Terpadu
              </p>
            </div>
          </div>
        </div>

        {/* Action Controls & Account */}
        <div className="flex items-center gap-2 lg:gap-3 shrink-0">
          {/* Status Database */}
          <button
            onClick={onOpenDbModal}
            className={`hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-colors ${getStatusColor()}`}
            title="Klik untuk konfigurasi Google Spreadsheet & Apps Script"
          >
            <Database className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate max-w-[150px]">{getStatusLabel()}</span>
          </button>

          {/* Sync Button */}
          <button
            onClick={onSyncNow}
            disabled={isSyncing}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium transition-colors disabled:opacity-60 shadow-sm"
            title="Sinkronkan data dengan Google Spreadsheet"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">{isSyncing ? 'Menyinkronkan...' : 'Sinkronkan'}</span>
          </button>

          {/* Cetak Label */}
          <button
            onClick={onOpenLabelModal}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors"
            title="Cetak Label Barcode / QR Inventaris"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak Label</span>
          </button>

          {/* Cetak Surat Jalan Peminjaman */}
          <button
            onClick={onOpenSuratJalanModal}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors"
            title="Cetak Bukti Peminjaman (Surat Jalan)"
          >
            <FileCheck2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Cetak Peminjaman</span>
          </button>

          {/* User Account / Switch */}
          <div className="h-6 w-px bg-slate-800 mx-1 hidden sm:block" />

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenLoginModal}
              className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 text-left transition-colors"
              title="Ganti Akun Pengguna"
            >
              <div className="w-6 h-6 rounded-full bg-emerald-600/30 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                {currentUser.role === 'ADMIN' ? (
                  <Shield className="w-3.5 h-3.5" />
                ) : (
                  <UserIcon className="w-3.5 h-3.5" />
                )}
              </div>
              <div className="hidden md:block leading-tight">
                <div className="text-xs font-medium text-white truncate max-w-[120px]">
                  {currentUser.namaLengkap || currentUser.username}
                </div>
                <div className="text-[10px] text-emerald-400 font-mono font-semibold">
                  {currentUser.role}
                </div>
              </div>
            </button>

            <button
              onClick={onLogout}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
              title="Keluar Akun"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
