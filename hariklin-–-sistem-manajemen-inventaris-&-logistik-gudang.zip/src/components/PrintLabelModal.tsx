import React, { useState } from 'react';
import { X, Printer, CheckSquare, Square, Search } from 'lucide-react';
import { MasterBarang } from '../types';

interface PrintLabelModalProps {
  isOpen: boolean;
  onClose: () => void;
  masterBarang: MasterBarang[];
}

export const PrintLabelModal: React.FC<PrintLabelModalProps> = ({
  isOpen,
  onClose,
  masterBarang,
}) => {
  const [selectedCodes, setSelectedCodes] = useState<string[]>(
    masterBarang.slice(0, 12).map((m) => m.kodeBarang)
  );
  const [searchTerm, setSearchTerm] = useState('');

  if (!isOpen) return null;

  const handleToggleCode = (code: string) => {
    setSelectedCodes((prev) =>
      prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]
    );
  };

  const handleSelectAll = () => {
    if (selectedCodes.length === masterBarang.length) {
      setSelectedCodes([]);
    } else {
      setSelectedCodes(masterBarang.map((m) => m.kodeBarang));
    }
  };

  const selectedItems = masterBarang.filter((m) => selectedCodes.includes(m.kodeBarang));

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-4xl max-h-[92vh] overflow-hidden flex flex-col">
        {/* Header (hidden in print) */}
        <div className="flex items-center justify-between p-4 border-b border-slate-200 bg-slate-50 no-print">
          <div>
            <h3 className="font-bold text-slate-900 text-sm">Cetak Label Barcode &amp; Rak Gudang</h3>
            <p className="text-xs text-slate-500">Pilih barang untuk mencetak stiker barcode inventaris</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              disabled={selectedItems.length === 0}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shadow-xs disabled:opacity-50"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak Sekarang ({selectedItems.length})</span>
            </button>
            <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-600 rounded">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Selection Area (hidden in print) */}
        <div className="p-4 border-b border-slate-200 bg-white space-y-3 no-print">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari nama atau kode barang..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 text-xs"
              />
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleSelectAll}
                className="flex items-center gap-1 text-slate-700 font-semibold hover:text-emerald-700"
              >
                {selectedCodes.length === masterBarang.length ? (
                  <CheckSquare className="w-4 h-4 text-emerald-600" />
                ) : (
                  <Square className="w-4 h-4 text-slate-400" />
                )}
                <span>Pilih Semua ({masterBarang.length})</span>
              </button>
              <span className="text-slate-400">|</span>
              <span className="text-slate-500">{selectedItems.length} label dipilih</span>
            </div>
          </div>

          {/* Quick chips selector */}
          <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto pt-1">
            {masterBarang
              .filter(
                (m) =>
                  m.namaBarang.toLowerCase().includes(searchTerm.toLowerCase()) ||
                  m.kodeBarang.toLowerCase().includes(searchTerm.toLowerCase())
              )
              .map((m) => {
                const isSelected = selectedCodes.includes(m.kodeBarang);
                return (
                  <button
                    key={m.kodeBarang}
                    onClick={() => handleToggleCode(m.kodeBarang)}
                    className={`px-2 py-1 rounded text-[11px] font-medium border transition-colors ${
                      isSelected
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-800'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    [{m.kodeBarang}] {m.namaBarang}
                  </button>
                );
              })}
          </div>
        </div>

        {/* Printable Label Grid */}
        <div className="p-6 overflow-y-auto flex-1 bg-slate-100/60 print:bg-white print:p-0">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 print:grid-cols-3 print:gap-3">
            {selectedItems.map((item) => (
              <div
                key={item.kodeBarang}
                className="bg-white border-2 border-slate-900 rounded-lg p-3 text-slate-900 flex flex-col justify-between shadow-2xs print:border-slate-800 print:shadow-none print:break-inside-avoid"
              >
                <div>
                  <div className="flex items-center justify-between border-b border-slate-300 pb-1 mb-1.5">
                    <div className="flex items-center gap-1.5">
                      <img src="/hariklin-logo.jpg" alt="Logo" className="w-3.5 h-3.5 object-contain" />
                      <span className="font-extrabold text-[11px] tracking-tight text-emerald-800">
                        HARIKLIN
                      </span>
                    </div>
                    <span className="font-mono text-[10px] font-bold text-slate-500">
                      {item.satuan}
                    </span>
                  </div>

                  <div className="font-bold text-xs text-slate-900 line-clamp-2 leading-tight">
                    {item.namaBarang}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5">{item.kategori}</div>
                </div>

                <div className="mt-3 pt-2 border-t border-dashed border-slate-300">
                  {/* Pseudo Barcode lines */}
                  <div className="h-9 w-full flex items-center justify-center gap-0.5 bg-slate-50 px-2 py-1 rounded border border-slate-200">
                    <div className="w-1 h-full bg-black" />
                    <div className="w-0.5 h-full bg-black" />
                    <div className="w-1.5 h-full bg-black" />
                    <div className="w-0.5 h-full bg-black" />
                    <div className="w-2 h-full bg-black" />
                    <div className="w-0.5 h-full bg-black" />
                    <div className="w-1 h-full bg-black" />
                    <div className="w-2 h-full bg-black" />
                    <div className="w-0.5 h-full bg-black" />
                    <div className="w-1.5 h-full bg-black" />
                    <div className="w-0.5 h-full bg-black" />
                    <div className="w-1 h-full bg-black" />
                    <div className="w-2 h-full bg-black" />
                    <div className="w-0.5 h-full bg-black" />
                    <div className="w-1.5 h-full bg-black" />
                    <div className="w-1 h-full bg-black" />
                  </div>

                  <div className="flex items-center justify-between mt-1 text-[10px] font-mono font-bold text-slate-800">
                    <span>{item.kodeBarang}</span>
                    <span className="text-slate-500 text-[9px]">{item.lokasiRak || 'Gudang'}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer (hidden in print) */}
        <div className="p-3 border-t border-slate-200 bg-slate-50 flex justify-end gap-2 no-print">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg border border-slate-200 text-slate-700 font-semibold text-xs hover:bg-slate-100"
          >
            Tutup
          </button>
          <button
            onClick={handlePrint}
            disabled={selectedItems.length === 0}
            className="px-5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-xs"
          >
            Cetak Label
          </button>
        </div>
      </div>
    </div>
  );
};
