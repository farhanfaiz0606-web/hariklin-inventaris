import React, { useState } from 'react';
import {
  Plus,
  Trash2,
  Printer,
  Search,
  CheckCircle2,
  Calendar,
  UserCheck,
  FileSpreadsheet,
} from 'lucide-react';
import { MasterBarang, Peminjaman, User } from '../types';
import { exportToCSV } from '../utils/exportUtils';

interface PeminjamanViewProps {
  masterBarang: MasterBarang[];
  peminjamanList: Peminjaman[];
  onCreatePeminjaman: (data: Omit<Peminjaman, 'id' | 'noTransaksi' | 'createdAt' | 'status'>) => void;
  onPrintSuratJalan: (peminjaman: Peminjaman) => void;
  currentUser: User;
}

export const PeminjamanView: React.FC<PeminjamanViewProps> = ({
  masterBarang,
  peminjamanList,
  onCreatePeminjaman,
  onPrintSuratJalan,
  currentUser,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);

  // Form Fields
  const [namaPeminjam, setNamaPeminjam] = useState('');
  const [penanggungJawab, setPenanggungJawab] = useState(currentUser.namaLengkap || currentUser.username);
  const [keperluan, setKeperluan] = useState('');
  const [tanggalPinjam, setTanggalPinjam] = useState(new Date().toISOString().split('T')[0]);
  const [tanggalRencanaKembali, setTanggalRencanaKembali] = useState(
    new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0]
  );
  const [keterangan, setKeterangan] = useState('');

  // Selected multi-items
  const [selectedItems, setSelectedItems] = useState<
    {
      kodeBarang: string;
      namaBarang: string;
      satuan: string;
      stokTersedia: number;
      jumlahPinjam: number;
    }[]
  >([]);

  // Item selector in form
  const [tempKode, setTempKode] = useState('');
  const [tempJumlah, setTempJumlah] = useState<number>(1);

  // Available items with stokAktif > 0
  const availableItems = masterBarang.filter((m) => m.stokAktif > 0);

  const handleAddItemToForm = () => {
    if (!tempKode) {
      alert('Pilih barang terlebih dahulu!');
      return;
    }
    const brg = masterBarang.find((m) => m.kodeBarang === tempKode);
    if (!brg) return;

    if (tempJumlah <= 0) {
      alert('Jumlah pinjam harus lebih dari 0!');
      return;
    }

    if (tempJumlah > brg.stokAktif) {
      alert(`Stok tidak mencukupi! Tersedia hanya ${brg.stokAktif} ${brg.satuan}.`);
      return;
    }

    // Check if already in list
    const existingIndex = selectedItems.findIndex((it) => it.kodeBarang === tempKode);
    if (existingIndex >= 0) {
      const updated = [...selectedItems];
      const newQty = updated[existingIndex].jumlahPinjam + tempJumlah;
      if (newQty > brg.stokAktif) {
        alert(`Total pinjam melebihi stok aktif (${brg.stokAktif} ${brg.satuan})!`);
        return;
      }
      updated[existingIndex].jumlahPinjam = newQty;
      setSelectedItems(updated);
    } else {
      setSelectedItems([
        ...selectedItems,
        {
          kodeBarang: brg.kodeBarang,
          namaBarang: brg.namaBarang,
          satuan: brg.satuan,
          stokTersedia: brg.stokAktif,
          jumlahPinjam: tempJumlah,
        },
      ]);
    }

    // Reset temp
    setTempKode('');
    setTempJumlah(1);
  };

  const handleRemoveItem = (index: number) => {
    const updated = [...selectedItems];
    updated.splice(index, 1);
    setSelectedItems(updated);
  };

  const handleSubmitPeminjaman = (e: React.FormEvent) => {
    e.preventDefault();
    if (!namaPeminjam.trim()) {
      alert('Nama peminjam wajib diisi!');
      return;
    }
    if (!keperluan.trim()) {
      alert('Keperluan pembersihan wajib diisi!');
      return;
    }
    if (selectedItems.length === 0) {
      alert('Pilih minimal 1 jenis barang untuk dipinjam!');
      return;
    }

    // Validate stocks one more time
    for (const it of selectedItems) {
      const brg = masterBarang.find((m) => m.kodeBarang === it.kodeBarang);
      if (!brg || it.jumlahPinjam > brg.stokAktif) {
        alert(`Stok untuk ${it.namaBarang} tidak mencukupi saat ini.`);
        return;
      }
    }

    onCreatePeminjaman({
      tanggalPinjam,
      tanggalRencanaKembali,
      namaPeminjam: namaPeminjam.trim(),
      penanggungJawab: penanggungJawab.trim(),
      keperluan: keperluan.trim(),
      keterangan: keterangan.trim(),
      items: selectedItems.map((it) => ({
        kodeBarang: it.kodeBarang,
        namaBarang: it.namaBarang,
        satuan: it.satuan,
        jumlahPinjam: it.jumlahPinjam,
        jumlahKembaliBaik: 0,
        jumlahKembaliRusak: 0,
        statusItem: 'Dipinjam',
      })),
      dicatatOleh: currentUser.namaLengkap || currentUser.username,
    });

    // Reset form
    setSelectedItems([]);
    setNamaPeminjam('');
    setKeperluan('');
    setKeterangan('');
    setIsFormOpen(false);
  };

  // Filtered loans list
  const filteredLoans = peminjamanList.filter(
    (p) =>
      p.noTransaksi.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.namaPeminjam.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.penanggungJawab.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.keperluan.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.items.some((it) => it.namaBarang.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleExport = () => {
    const exportRows: any[] = [];
    peminjamanList.forEach((p) => {
      p.items.forEach((it) => {
        exportRows.push({
          'No Transaksi': p.noTransaksi,
          'Tanggal Pinjam': p.tanggalPinjam,
          'Rencana Kembali': p.tanggalRencanaKembali,
          'Nama Peminjam': p.namaPeminjam,
          'Penanggung Jawab': p.penanggungJawab,
          'Keperluan Pembersihan': p.keperluan,
          'Kode Barang': it.kodeBarang,
          'Nama Barang': it.namaBarang,
          'Jumlah Pinjam': it.jumlahPinjam,
          'Kembali Baik': it.jumlahKembaliBaik,
          'Kembali Rusak': it.jumlahKembaliRusak,
          Status: p.status,
          Keterangan: p.keterangan || '-',
        });
      });
    });
    exportToCSV('Laporan_Peminjaman_Hariklin', exportRows);
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Peminjaman Alat & Mesin</h1>
            <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
              {peminjamanList.filter((p) => p.status !== 'Selesai').length} Transaksi Aktif
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Formulir peminjaman multi-item dengan validasi stok real-time dan penerbitan Surat Jalan
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold border border-slate-200 transition-colors"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => setIsFormOpen(!isFormOpen)}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{isFormOpen ? 'Tutup Formulir' : 'Form Peminjaman Baru'}</span>
          </button>
        </div>
      </div>

      {/* FORMULIR PEMINJAMAN MULTI-ITEM */}
      {isFormOpen && (
        <div className="bg-white rounded-xl border border-emerald-300 p-5 shadow-md animate-in fade-in duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Formulir Peminjaman Alat (Multi-Item)</h2>
              <p className="text-xs text-slate-500">Stok aktif akan otomatis terpotong begitu peminjaman disimpan</p>
            </div>
            <span className="text-xs font-mono text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md font-semibold border border-emerald-200">
              No. Otomatis: PINJ-{new Date().toISOString().slice(2, 7).replace('-', '')}-XXXX
            </span>
          </div>

          <form onSubmit={handleSubmitPeminjaman} className="mt-4 space-y-4 text-xs">
            {/* General Info Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Nama Peminjam *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Tim Lapangan / Ahmad Yani"
                  value={namaPeminjam}
                  onChange={(e) => setNamaPeminjam(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Penanggung Jawab Gudang / SPV *</label>
                <input
                  type="text"
                  required
                  placeholder="Nama Penanggung Jawab"
                  value={penanggungJawab}
                  onChange={(e) => setPenanggungJawab(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Keperluan Pembersihan *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Deep Cleaning Gedung A Lt. 3 / Cuci Karpet"
                  value={keperluan}
                  onChange={(e) => setKeperluan(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Tanggal Pinjam</label>
                <input
                  type="date"
                  required
                  value={tanggalPinjam}
                  onChange={(e) => setTanggalPinjam(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Tanggal Rencana Kembali</label>
                <input
                  type="date"
                  required
                  value={tanggalRencanaKembali}
                  onChange={(e) => setTanggalRencanaKembali(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Keterangan / Lokasi Proyek</label>
                <input
                  type="text"
                  placeholder="Catatan tambahan lokasi proyek..."
                  value={keterangan}
                  onChange={(e) => setKeterangan(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>
            </div>

            {/* Item Selection Box */}
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
              <div className="font-semibold text-slate-800 text-xs flex items-center justify-between">
                <span>Pilih Barang Dari Master (Tersedia: {availableItems.length} item)</span>
                <span className="text-[11px] text-slate-500">Stok aktif otomatis tertera</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-2">
                <div className="md:col-span-8">
                  <select
                    value={tempKode}
                    onChange={(e) => setTempKode(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs bg-white"
                  >
                    <option value="">-- Pilih Barang dari Master --</option>
                    {availableItems.map((m) => (
                      <option key={m.kodeBarang} value={m.kodeBarang}>
                        [{m.kodeBarang}] {m.namaBarang} (Stok Tersedia: {m.stokAktif} {m.satuan})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="md:col-span-2">
                  <input
                    type="number"
                    min="1"
                    placeholder="Jumlah"
                    value={tempJumlah}
                    onChange={(e) => setTempJumlah(Math.max(1, Number(e.target.value)))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-mono"
                  />
                </div>

                <div className="md:col-span-2">
                  <button
                    type="button"
                    onClick={handleAddItemToForm}
                    className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center justify-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Tambahkan</span>
                  </button>
                </div>
              </div>

              {/* Selected Items Table */}
              <div className="mt-3 bg-white rounded-lg border border-slate-200 overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-600 font-semibold border-b border-slate-200">
                      <th className="py-2 px-3">Kode</th>
                      <th className="py-2 px-3">Nama Barang</th>
                      <th className="py-2 px-3 text-right">Stok Tersedia</th>
                      <th className="py-2 px-3 text-right">Jumlah Pinjam</th>
                      <th className="py-2 px-3">Satuan</th>
                      <th className="py-2 px-3 text-center">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {selectedItems.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-4 text-center text-slate-400 italic">
                          Belum ada barang ditambahkan ke daftar peminjaman ini.
                        </td>
                      </tr>
                    ) : (
                      selectedItems.map((item, idx) => (
                        <tr key={item.kodeBarang} className="hover:bg-slate-50">
                          <td className="py-2 px-3 font-mono font-semibold text-slate-800">{item.kodeBarang}</td>
                          <td className="py-2 px-3 font-medium text-slate-900">{item.namaBarang}</td>
                          <td className="py-2 px-3 text-right font-mono text-slate-500">{item.stokTersedia}</td>
                          <td className="py-2 px-3 text-right font-mono font-bold text-blue-700 bg-blue-50/40">
                            {item.jumlahPinjam}
                          </td>
                          <td className="py-2 px-3 text-slate-600">{item.satuan}</td>
                          <td className="py-2 px-3 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveItem(idx)}
                              className="p-1 text-slate-400 hover:text-rose-600 rounded"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Submit Action */}
            <div className="flex items-center justify-between pt-2">
              <div className="text-[11px] text-slate-500">
                Total item terpilih: <strong className="text-slate-800">{selectedItems.length} jenis</strong>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 font-semibold hover:bg-slate-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={selectedItems.length === 0}
                  className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold shadow-xs disabled:opacity-50"
                >
                  Simpan Transaksi & Kurangi Stok Aktif
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* DAFTAR TRANSAKSI PEMINJAMAN */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Search header */}
        <div className="p-4 border-b border-slate-200 flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari transaksi, peminjam, barang..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500/20"
            />
          </div>

          <div className="text-xs text-slate-500">
            Menampilkan <strong className="text-slate-800">{filteredLoans.length}</strong> transaksi peminjaman
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                <th className="py-3 px-3">No Transaksi</th>
                <th className="py-3 px-3">Peminjam</th>
                <th className="py-3 px-3">Keperluan Pembersihan</th>
                <th className="py-3 px-3">Daftar Alat Dipinjam</th>
                <th className="py-3 px-3">Tgl Pinjam</th>
                <th className="py-3 px-3">Rencana Kembali</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-3 text-center">Cetak</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredLoans.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    Belum ada data peminjaman yang cocok.
                  </td>
                </tr>
              ) : (
                filteredLoans.map((loan) => {
                  const isOverdue =
                    loan.status !== 'Selesai' &&
                    loan.tanggalRencanaKembali &&
                    loan.tanggalRencanaKembali < new Date().toISOString().split('T')[0];

                  return (
                    <tr key={loan.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-3 font-mono font-bold text-slate-900">{loan.noTransaksi}</td>
                      <td className="py-3 px-3">
                        <div className="font-semibold text-slate-900">{loan.namaPeminjam}</div>
                        <div className="text-[11px] text-slate-500">PJ: {loan.penanggungJawab}</div>
                      </td>
                      <td className="py-3 px-3 text-slate-700">{loan.keperluan}</td>
                      <td className="py-3 px-3">
                        <div className="space-y-1">
                          {loan.items.map((it, idx) => (
                            <div key={idx} className="flex items-center gap-1.5 text-[11px]">
                              <span className="font-mono font-semibold text-slate-700">{it.jumlahPinjam} {it.satuan}</span>
                              <span className="text-slate-900 font-medium">{it.namaBarang}</span>
                              {(it.jumlahKembaliBaik > 0 || it.jumlahKembaliRusak > 0) && (
                                <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1 rounded">
                                  (Kembali: {it.jumlahKembaliBaik} baik{it.jumlahKembaliRusak > 0 ? `, ${it.jumlahKembaliRusak} rusak` : ''})
                                </span>
                              )}
                            </div>
                          ))}
                        </div>
                      </td>
                      <td className="py-3 px-3 font-mono text-slate-600">{loan.tanggalPinjam}</td>
                      <td className="py-3 px-3 font-mono">
                        <span className={isOverdue ? 'text-rose-600 font-bold' : 'text-slate-600'}>
                          {loan.tanggalRencanaKembali}
                        </span>
                        {isOverdue && (
                          <span className="block text-[10px] text-rose-600 font-semibold">
                            Terlambat
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-center">
                        <span
                          className={`text-[11px] px-2 py-0.5 rounded font-semibold ${
                            loan.status === 'Selesai'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : loan.status === 'Sebagian'
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : 'bg-blue-50 text-blue-700 border border-blue-200'
                          }`}
                        >
                          {loan.status}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-center">
                        <button
                          onClick={() => onPrintSuratJalan(loan)}
                          className="p-1.5 rounded-lg text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 transition-colors inline-flex items-center gap-1"
                          title="Cetak Surat Jalan Bukti Peminjaman"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span className="text-[11px] font-medium hidden sm:inline">Surat Jalan</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
