import React, { useState, useMemo } from 'react';
import {
  FileText,
  Download,
  Printer,
  Search,
  Filter,
  Boxes,
  ArrowUpRight,
  ArrowDownLeft,
  PackagePlus,
  AlertTriangle,
  Wrench,
  ShoppingCart,
  ClipboardCheck,
  Activity,
} from 'lucide-react';
import {
  MasterBarang,
  Peminjaman,
  Pengembalian,
  BarangMasuk,
  BarangRusak,
  Perbaikan,
  Pembelian,
  StockOpname,
  LogAktivitas,
  User,
} from '../types';
import { exportToCSV, formatRupiah } from '../utils/exportUtils';

type ReportTab =
  | 'masterBarang'
  | 'stokAktif'
  | 'barangMasuk'
  | 'peminjaman'
  | 'pengembalian'
  | 'barangRusak'
  | 'perbaikan'
  | 'pembelian'
  | 'stockOpname'
  | 'logAktivitas';

interface LaporanViewProps {
  masterBarang: MasterBarang[];
  peminjamanList: Peminjaman[];
  pengembalianList: Pengembalian[];
  barangMasukList: BarangMasuk[];
  barangRusakList: BarangRusak[];
  perbaikanList: Perbaikan[];
  pembelianList: Pembelian[];
  stockOpnameList: StockOpname[];
  logsList: LogAktivitas[];
  currentUser: User;
}

export const LaporanView: React.FC<LaporanViewProps> = ({
  masterBarang,
  peminjamanList,
  pengembalianList,
  barangMasukList,
  barangRusakList,
  perbaikanList,
  pembelianList,
  stockOpnameList,
  logsList,
  currentUser,
}) => {
  const [activeTab, setActiveTab] = useState<ReportTab>('masterBarang');
  const [searchTerm, setSearchTerm] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('SEMUA');

  const categories = useMemo(() => {
    const set = new Set<string>();
    masterBarang.forEach((m) => {
      if (m.kategori) set.add(m.kategori);
    });
    return Array.from(set).sort();
  }, [masterBarang]);

  const reportTabs: { key: ReportTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { key: 'masterBarang', label: 'Master Barang', icon: Boxes },
    { key: 'stokAktif', label: 'Stok Aktif', icon: Boxes },
    { key: 'barangMasuk', label: 'Barang Masuk', icon: PackagePlus },
    { key: 'peminjaman', label: 'Peminjaman', icon: ArrowUpRight },
    { key: 'pengembalian', label: 'Pengembalian', icon: ArrowDownLeft },
    { key: 'barangRusak', label: 'Barang Rusak', icon: AlertTriangle },
    { key: 'perbaikan', label: 'Perbaikan', icon: Wrench },
    { key: 'pembelian', label: 'Pembelian', icon: ShoppingCart },
    { key: 'stockOpname', label: 'Stock Opname', icon: ClipboardCheck },
    { key: 'logAktivitas', label: 'Log Aktivitas', icon: Activity },
  ];

  // Filter helper for date
  const isDateInRange = (dateStr?: string) => {
    if (!dateStr) return true;
    const cleanDate = dateStr.slice(0, 10);
    if (startDate && cleanDate < startDate) return false;
    if (endDate && cleanDate > endDate) return false;
    return true;
  };

  // Compute filtered datasets based on active tab
  const filteredData = useMemo(() => {
    const s = searchTerm.toLowerCase();

    switch (activeTab) {
      case 'masterBarang':
        return masterBarang.filter(
          (m) =>
            (selectedCategory === 'SEMUA' || m.kategori === selectedCategory) &&
            (m.namaBarang.toLowerCase().includes(s) || m.kodeBarang.toLowerCase().includes(s))
        );

      case 'stokAktif':
        return masterBarang
          .filter((m) => m.stokAktif > 0)
          .filter(
            (m) =>
              (selectedCategory === 'SEMUA' || m.kategori === selectedCategory) &&
              (m.namaBarang.toLowerCase().includes(s) || m.kodeBarang.toLowerCase().includes(s))
          );

      case 'barangMasuk':
        return barangMasukList.filter(
          (b) =>
            isDateInRange(b.tanggalMasuk) &&
            (b.namaBarang.toLowerCase().includes(s) ||
              b.kodeBarang.toLowerCase().includes(s) ||
              b.sumberBarang.toLowerCase().includes(s))
        );

      case 'peminjaman':
        return peminjamanList.filter(
          (p) =>
            isDateInRange(p.tanggalPinjam) &&
            (p.noTransaksi.toLowerCase().includes(s) ||
              p.namaPeminjam.toLowerCase().includes(s) ||
              p.items.some((i) => i.namaBarang.toLowerCase().includes(s)))
        );

      case 'pengembalian':
        return pengembalianList.filter(
          (k) =>
            isDateInRange(k.tanggalKembali) &&
            (k.noPengembalian.toLowerCase().includes(s) ||
              k.namaPeminjam.toLowerCase().includes(s) ||
              k.items.some((i) => i.namaBarang.toLowerCase().includes(s)))
        );

      case 'barangRusak':
        return barangRusakList.filter(
          (r) =>
            isDateInRange(r.tanggalKerusakan) &&
            (r.namaBarang.toLowerCase().includes(s) ||
              r.kodeBarang.toLowerCase().includes(s) ||
              r.keterangan.toLowerCase().includes(s))
        );

      case 'perbaikan':
        return perbaikanList.filter(
          (pbk) =>
            isDateInRange(pbk.tanggalKerusakan) &&
            (pbk.noPerbaikan.toLowerCase().includes(s) ||
              pbk.namaBarang.toLowerCase().includes(s) ||
              pbk.namaPetugas.toLowerCase().includes(s))
        );

      case 'pembelian':
        return pembelianList.filter(
          (po) =>
            isDateInRange(po.tanggalPengajuan) &&
            (po.noPengadaan.toLowerCase().includes(s) ||
              po.namaBarang.toLowerCase().includes(s) ||
              po.namaPengaju.toLowerCase().includes(s))
        );

      case 'stockOpname':
        return stockOpnameList.filter(
          (op) =>
            isDateInRange(op.tanggalOpname) &&
            (op.noOpname.toLowerCase().includes(s) ||
              op.namaBarang.toLowerCase().includes(s) ||
              op.dicatatOleh.toLowerCase().includes(s))
        );

      case 'logAktivitas':
        return logsList.filter(
          (l) =>
            isDateInRange(l.timestamp) &&
            (l.username.toLowerCase().includes(s) ||
              l.modul.toLowerCase().includes(s) ||
              l.action.toLowerCase().includes(s) ||
              l.detail.toLowerCase().includes(s))
        );

      default:
        return [];
    }
  }, [
    activeTab,
    searchTerm,
    startDate,
    endDate,
    selectedCategory,
    masterBarang,
    barangMasukList,
    peminjamanList,
    pengembalianList,
    barangRusakList,
    perbaikanList,
    pembelianList,
    stockOpnameList,
    logsList,
  ]);

  const handleExportExcel = () => {
    let rowsToExport: any[] = [];
    let filename = `Laporan_${activeTab}_Hariklin`;

    if (activeTab === 'masterBarang' || activeTab === 'stokAktif') {
      rowsToExport = (filteredData as MasterBarang[]).map((it) => ({
        'Kode Barang': it.kodeBarang,
        'Nama Barang': it.namaBarang,
        Kategori: it.kategori,
        Satuan: it.satuan,
        'Stok Awal': it.stokAwal,
        'Stok Aktif': it.stokAktif,
        'Jumlah Dipinjam': it.dipinjam,
        'Jumlah Rusak': it.rusak,
        'Jumlah Perbaikan': it.perbaikan,
        'Menunggu Pembelian': it.menungguBeli,
        'Lokasi Rak': it.lokasiRak || '-',
        Keterangan: it.keterangan || '-',
      }));
    } else if (activeTab === 'barangMasuk') {
      rowsToExport = (filteredData as BarangMasuk[]).map((b) => ({
        'No Transaksi': b.noTransaksiMasuk,
        'Kode Barang': b.kodeBarang,
        'Nama Barang': b.namaBarang,
        Kategori: b.kategori,
        'Jumlah Masuk': b.jumlahMasuk,
        Satuan: b.satuan,
        'Tanggal Masuk': b.tanggalMasuk,
        'Sumber / Vendor': b.sumberBarang,
        'Penanggung Jawab': b.penanggungJawab,
        'Dicatat Oleh': b.dicatatOleh,
      }));
    } else if (activeTab === 'peminjaman') {
      (filteredData as Peminjaman[]).forEach((p) => {
        p.items.forEach((it) => {
          rowsToExport.push({
            'No Transaksi': p.noTransaksi,
            'Tanggal Pinjam': p.tanggalPinjam,
            'Rencana Kembali': p.tanggalRencanaKembali,
            'Nama Peminjam': p.namaPeminjam,
            'Penanggung Jawab': p.penanggungJawab,
            'Keperluan': p.keperluan,
            'Kode Barang': it.kodeBarang,
            'Nama Barang': it.namaBarang,
            'Jumlah Pinjam': it.jumlahPinjam,
            'Kembali Baik': it.jumlahKembaliBaik,
            'Kembali Rusak': it.jumlahKembaliRusak,
            Status: p.status,
          });
        });
      });
    } else if (activeTab === 'pengembalian') {
      (filteredData as Pengembalian[]).forEach((k) => {
        k.items.forEach((it) => {
          rowsToExport.push({
            'No Pengembalian': k.noPengembalian,
            'No Peminjaman': k.noTransaksiPinjam,
            'Tanggal Kembali': k.tanggalKembali,
            'Nama Peminjam': k.namaPeminjam,
            'Kode Barang': it.kodeBarang,
            'Nama Barang': it.namaBarang,
            'Jumlah Kembali': it.jumlahKembali,
            Kondisi: it.kondisi,
            'Keterangan Rusak': it.keteranganRusak || '-',
          });
        });
      });
    } else if (activeTab === 'barangRusak') {
      rowsToExport = (filteredData as BarangRusak[]).map((r) => ({
        'Kode Barang': r.kodeBarang,
        'Nama Barang': r.namaBarang,
        'Jumlah Rusak': r.jumlahRusak,
        Satuan: r.satuan,
        'Tanggal Kerusakan': r.tanggalKerusakan,
        'Sumber Kerusakan': r.sumberKerusakan,
        'Keterangan': r.keterangan,
        'Status Penanganan': r.statusPenanganan,
      }));
    } else if (activeTab === 'perbaikan') {
      rowsToExport = (filteredData as Perbaikan[]).map((pbk) => ({
        'No Perbaikan': pbk.noPerbaikan,
        'Kode Barang': pbk.kodeBarang,
        'Nama Barang': pbk.namaBarang,
        'Jumlah Unit': pbk.jumlahBarang,
        'Penyebab Kerusakan': pbk.penyebabKerusakan,
        'Petugas': pbk.namaPetugas,
        'Estimasi Biaya': pbk.estimasiBiaya,
        'Biaya Aktual': pbk.biayaAktual || '-',
        Status: pbk.status,
      }));
    } else if (activeTab === 'pembelian') {
      rowsToExport = (filteredData as Pembelian[]).map((po) => ({
        'No Pengadaan': po.noPengadaan,
        'Kode Barang': po.kodeBarang,
        'Nama Barang': po.namaBarang,
        'Jumlah': po.jumlahDibutuhkan,
        'Alasan Pengadaan': po.alasanPembelian,
        'Pengaju': po.namaPengaju,
        'Estimasi Harga': po.estimasiHarga,
        'Harga Aktual': po.hargaAktual || '-',
        Status: po.status,
      }));
    } else if (activeTab === 'stockOpname') {
      rowsToExport = (filteredData as StockOpname[]).map((op) => ({
        'No Opname': op.noOpname,
        'Tanggal': op.tanggalOpname,
        'Kode Barang': op.kodeBarang,
        'Nama Barang': op.namaBarang,
        'Stok Sistem': op.stokSistem,
        'Stok Fisik': op.stokFisik,
        Selisih: op.selisih,
        Status: op.statusPenyesuaian,
        Pemeriksa: op.dicatatOleh,
      }));
    } else if (activeTab === 'logAktivitas') {
      rowsToExport = (filteredData as LogAktivitas[]).map((l) => ({
        Waktu: l.timestamp,
        Pengguna: l.username,
        Aksi: l.action,
        Modul: l.modul,
        Detail: l.detail,
      }));
    }

    exportToCSV(filename, rowsToExport);
  };

  const handlePrintReport = () => {
    window.print();
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4 no-print">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Pusat Laporan &amp; Rekapitulasi</h1>
            <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
              10 Modul Laporan
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Unduh rekapitulasi data dalam format Excel (CSV) atau cetak langsung PDF resmi Hariklin
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportExcel}
            className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Excel</span>
          </button>

          <button
            onClick={handlePrintReport}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak / PDF</span>
          </button>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="bg-white rounded-xl border border-slate-200 p-2 shadow-xs no-print">
        <div className="flex items-center gap-1 overflow-x-auto pb-1">
          {reportTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Filter and Date Range Controls */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3 no-print">
        {/* Search Input */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari dalam laporan..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 text-xs focus:ring-2 focus:ring-emerald-500/20"
          />
        </div>

        {/* Date Filters & Category */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {(activeTab === 'masterBarang' || activeTab === 'stokAktif') && (
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-700 bg-white"
            >
              <option value="SEMUA">Semua Kategori</option>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          )}

          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <span>Dari:</span>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="px-2 py-1.5 rounded-lg border border-slate-200 text-xs text-slate-700"
            />
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <span>Sampai:</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="px-2 py-1.5 rounded-lg border border-slate-200 text-xs text-slate-700"
            />
          </div>

          {(startDate || endDate || searchTerm) && (
            <button
              onClick={() => {
                setStartDate('');
                setEndDate('');
                setSearchTerm('');
                setSelectedCategory('SEMUA');
              }}
              className="text-[11px] text-rose-600 hover:underline px-2 py-1"
            >
              Reset Filter
            </button>
          )}
        </div>
      </div>

      {/* PRINT HEADER (visible only during print) */}
      <div className="print-only mb-6 border-b-2 border-slate-800 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">HARIKLIN – SISTEM MANAJEMEN INVENTARIS</h1>
            <p className="text-sm font-semibold text-slate-700 mt-1 uppercase">
              LAPORAN {reportTabs.find((t) => t.key === activeTab)?.label}
            </p>
            <p className="text-xs text-slate-500 mt-0.5">
              Dicetak pada: {new Date().toLocaleString('id-ID')} &middot; Oleh: {currentUser.namaLengkap || currentUser.username}
            </p>
          </div>
          <div className="text-right text-xs text-slate-500 font-mono">
            {startDate || endDate ? `Periode: ${startDate || 'Awal'} s/d ${endDate || 'Sekarang'}` : 'Seluruh Riwayat'}
          </div>
        </div>
      </div>

      {/* REPORT CONTENT DATA TABLE */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-3 border-b border-slate-200 bg-slate-50 flex justify-between items-center text-xs">
          <span className="font-semibold text-slate-800">
            Tabel Rekapitulasi: {reportTabs.find((t) => t.key === activeTab)?.label}
          </span>
          <span className="text-slate-500 font-mono">Total Baris: {filteredData.length}</span>
        </div>

        <div className="overflow-x-auto">
          {/* 1. Master Barang & Stok Aktif */}
          {(activeTab === 'masterBarang' || activeTab === 'stokAktif') && (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                  <th className="py-2.5 px-3">Kode</th>
                  <th className="py-2.5 px-3">Nama Barang</th>
                  <th className="py-2.5 px-3">Kategori</th>
                  <th className="py-2.5 px-3">Satuan</th>
                  <th className="py-2.5 px-3 text-right">Stok Awal</th>
                  <th className="py-2.5 px-3 text-right font-bold text-emerald-800">Stok Aktif</th>
                  <th className="py-2.5 px-3 text-right text-blue-700">Dipinjam</th>
                  <th className="py-2.5 px-3 text-right text-rose-700">Rusak</th>
                  <th className="py-2.5 px-3 text-right text-amber-700">Perbaikan</th>
                  <th className="py-2.5 px-3 text-right text-purple-700">Wajib Beli</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(filteredData as MasterBarang[]).map((it) => (
                  <tr key={it.kodeBarang} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-mono font-bold text-slate-900">{it.kodeBarang}</td>
                    <td className="py-2 px-3 font-medium text-slate-900">{it.namaBarang}</td>
                    <td className="py-2 px-3 text-slate-600">{it.kategori}</td>
                    <td className="py-2 px-3 text-slate-600">{it.satuan}</td>
                    <td className="py-2 px-3 text-right font-mono text-slate-500">{it.stokAwal}</td>
                    <td className="py-2 px-3 text-right font-mono font-bold text-emerald-700 bg-emerald-50/40">
                      {it.stokAktif}
                    </td>
                    <td className="py-2 px-3 text-right font-mono text-blue-600">{it.dipinjam || '-'}</td>
                    <td className="py-2 px-3 text-right font-mono text-rose-600">{it.rusak || '-'}</td>
                    <td className="py-2 px-3 text-right font-mono text-amber-600">{it.perbaikan || '-'}</td>
                    <td className="py-2 px-3 text-right font-mono text-purple-600">{it.menungguBeli || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {/* 2. Barang Masuk */}
          {activeTab === 'barangMasuk' && (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                  <th className="py-2.5 px-3">No Transaksi</th>
                  <th className="py-2.5 px-3">Kode</th>
                  <th className="py-2.5 px-3">Nama Barang</th>
                  <th className="py-2.5 px-3 text-right">Jumlah Masuk</th>
                  <th className="py-2.5 px-3">Vendor / Sumber</th>
                  <th className="py-2.5 px-3">Tgl Masuk</th>
                  <th className="py-2.5 px-3">Penanggung Jawab</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(filteredData as BarangMasuk[]).map((b) => (
                  <tr key={b.id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-mono font-bold text-teal-800">{b.noTransaksiMasuk}</td>
                    <td className="py-2 px-3 font-mono text-slate-800">{b.kodeBarang}</td>
                    <td className="py-2 px-3 font-medium text-slate-900">{b.namaBarang}</td>
                    <td className="py-2 px-3 text-right font-mono font-bold text-teal-700">+{b.jumlahMasuk} {b.satuan}</td>
                    <td className="py-2 px-3 text-slate-800">{b.sumberBarang}</td>
                    <td className="py-2 px-3 font-mono text-slate-600">{b.tanggalMasuk}</td>
                    <td className="py-2 px-3 text-slate-600">{b.penanggungJawab}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {/* 3. Peminjaman */}
          {activeTab === 'peminjaman' && (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                  <th className="py-2.5 px-3">No Transaksi</th>
                  <th className="py-2.5 px-3">Peminjam</th>
                  <th className="py-2.5 px-3">Keperluan</th>
                  <th className="py-2.5 px-3">Barang Dipinjam</th>
                  <th className="py-2.5 px-3">Tgl Pinjam</th>
                  <th className="py-2.5 px-3">Rencana Kembali</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(filteredData as Peminjaman[]).map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-mono font-bold text-slate-900">{p.noTransaksi}</td>
                    <td className="py-2 px-3 font-medium text-slate-900">{p.namaPeminjam}</td>
                    <td className="py-2 px-3 text-slate-700">{p.keperluan}</td>
                    <td className="py-2 px-3">
                      {p.items.map((i, idx) => (
                        <div key={idx} className="text-[11px]">
                          {i.jumlahPinjam} {i.satuan} {i.namaBarang}
                        </div>
                      ))}
                    </td>
                    <td className="py-2 px-3 font-mono text-slate-600">{p.tanggalPinjam}</td>
                    <td className="py-2 px-3 font-mono text-slate-600">{p.tanggalRencanaKembali}</td>
                    <td className="py-2 px-3 text-center">
                      <span className="font-semibold text-[11px] text-slate-800">{p.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {/* 4. Pengembalian */}
          {activeTab === 'pengembalian' && (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                  <th className="py-2.5 px-3">No Pengembalian</th>
                  <th className="py-2.5 px-3">No Pinjam</th>
                  <th className="py-2.5 px-3">Peminjam</th>
                  <th className="py-2.5 px-3">Tgl Kembali</th>
                  <th className="py-2.5 px-3">Rincian Barang</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(filteredData as Pengembalian[]).map((k) => (
                  <tr key={k.id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-mono font-bold text-emerald-800">{k.noPengembalian}</td>
                    <td className="py-2 px-3 font-mono text-slate-700">{k.noTransaksiPinjam}</td>
                    <td className="py-2 px-3 font-medium text-slate-900">{k.namaPeminjam}</td>
                    <td className="py-2 px-3 font-mono text-slate-600">{k.tanggalKembali}</td>
                    <td className="py-2 px-3">
                      {k.items.map((i, idx) => (
                        <div key={idx} className="text-[11px]">
                          {i.jumlahKembali} {i.satuan} {i.namaBarang} ({i.kondisi})
                        </div>
                      ))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {/* 5. Barang Rusak */}
          {activeTab === 'barangRusak' && (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                  <th className="py-2.5 px-3">Kode</th>
                  <th className="py-2.5 px-3">Nama Barang</th>
                  <th className="py-2.5 px-3 text-right">Jumlah Rusak</th>
                  <th className="py-2.5 px-3">Tgl Rusak</th>
                  <th className="py-2.5 px-3">Sumber Kerusakan</th>
                  <th className="py-2.5 px-3">Keterangan</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(filteredData as BarangRusak[]).map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-mono font-bold text-slate-900">{r.kodeBarang}</td>
                    <td className="py-2 px-3 font-semibold text-slate-900">{r.namaBarang}</td>
                    <td className="py-2 px-3 text-right font-mono font-bold text-rose-600">{r.jumlahRusak} {r.satuan}</td>
                    <td className="py-2 px-3 font-mono text-slate-600">{r.tanggalKerusakan}</td>
                    <td className="py-2 px-3 text-slate-600">{r.sumberKerusakan}</td>
                    <td className="py-2 px-3 text-slate-700">{r.keterangan}</td>
                    <td className="py-2 px-3 text-center">
                      <span className="font-semibold text-[11px] text-slate-800">{r.statusPenanganan}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {/* 6. Perbaikan */}
          {activeTab === 'perbaikan' && (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                  <th className="py-2.5 px-3">No Perbaikan</th>
                  <th className="py-2.5 px-3">Nama Barang</th>
                  <th className="py-2.5 px-3 text-right">Jumlah</th>
                  <th className="py-2.5 px-3">Penyebab</th>
                  <th className="py-2.5 px-3">Petugas</th>
                  <th className="py-2.5 px-3 text-right">Biaya</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(filteredData as Perbaikan[]).map((pbk) => (
                  <tr key={pbk.id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-mono font-bold text-amber-900">{pbk.noPerbaikan}</td>
                    <td className="py-2 px-3 font-semibold text-slate-900">{pbk.namaBarang}</td>
                    <td className="py-2 px-3 text-right font-mono">{pbk.jumlahBarang} {pbk.satuan}</td>
                    <td className="py-2 px-3 text-slate-700">{pbk.penyebabKerusakan}</td>
                    <td className="py-2 px-3 text-slate-600">{pbk.namaPetugas}</td>
                    <td className="py-2 px-3 text-right font-mono">
                      {pbk.biayaAktual ? formatRupiah(pbk.biayaAktual) : formatRupiah(pbk.estimasiBiaya)}
                    </td>
                    <td className="py-2 px-3 text-center">
                      <span className="font-semibold text-[11px] text-slate-800">{pbk.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {/* 7. Pembelian */}
          {activeTab === 'pembelian' && (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                  <th className="py-2.5 px-3">No PO</th>
                  <th className="py-2.5 px-3">Nama Barang</th>
                  <th className="py-2.5 px-3 text-right">Jumlah</th>
                  <th className="py-2.5 px-3">Alasan</th>
                  <th className="py-2.5 px-3">Pengaju</th>
                  <th className="py-2.5 px-3 text-right">Harga</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(filteredData as Pembelian[]).map((po) => (
                  <tr key={po.id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-mono font-bold text-purple-900">{po.noPengadaan}</td>
                    <td className="py-2 px-3 font-semibold text-slate-900">{po.namaBarang}</td>
                    <td className="py-2 px-3 text-right font-mono">{po.jumlahDibutuhkan} {po.satuan}</td>
                    <td className="py-2 px-3 text-slate-700">{po.alasanPembelian}</td>
                    <td className="py-2 px-3 text-slate-600">{po.namaPengaju}</td>
                    <td className="py-2 px-3 text-right font-mono">
                      {po.hargaAktual ? formatRupiah(po.hargaAktual) : formatRupiah(po.estimasiHarga)}
                    </td>
                    <td className="py-2 px-3 text-center">
                      <span className="font-semibold text-[11px] text-slate-800">{po.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {/* 8. Stock Opname */}
          {activeTab === 'stockOpname' && (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                  <th className="py-2.5 px-3">No Opname</th>
                  <th className="py-2.5 px-3">Nama Barang</th>
                  <th className="py-2.5 px-3 text-right">Stok Sistem</th>
                  <th className="py-2.5 px-3 text-right">Stok Fisik</th>
                  <th className="py-2.5 px-3 text-right">Selisih</th>
                  <th className="py-2.5 px-3">Tgl Periksa</th>
                  <th className="py-2.5 px-3">Pemeriksa</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(filteredData as StockOpname[]).map((op) => (
                  <tr key={op.id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-mono font-bold text-purple-900">{op.noOpname}</td>
                    <td className="py-2 px-3 font-semibold text-slate-900">{op.namaBarang}</td>
                    <td className="py-2 px-3 text-right font-mono">{op.stokSistem}</td>
                    <td className="py-2 px-3 text-right font-mono font-bold text-slate-900">{op.stokFisik}</td>
                    <td className="py-2 px-3 text-right font-mono font-bold">
                      {op.selisih > 0 ? `+${op.selisih}` : op.selisih}
                    </td>
                    <td className="py-2 px-3 font-mono text-slate-600">{op.tanggalOpname}</td>
                    <td className="py-2 px-3 text-slate-600">{op.dicatatOleh}</td>
                    <td className="py-2 px-3 text-center">
                      <span className="font-semibold text-[11px] text-slate-800">{op.statusPenyesuaian}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {/* 9. Log Aktivitas */}
          {activeTab === 'logAktivitas' && (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                  <th className="py-2.5 px-3">Waktu</th>
                  <th className="py-2.5 px-3">Pengguna</th>
                  <th className="py-2.5 px-3">Modul</th>
                  <th className="py-2.5 px-3">Aksi</th>
                  <th className="py-2.5 px-3">Detail Aktivitas</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(filteredData as LogAktivitas[]).map((l) => (
                  <tr key={l.id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-mono text-slate-500 whitespace-nowrap">{l.timestamp}</td>
                    <td className="py-2 px-3 font-semibold text-slate-900">{l.username}</td>
                    <td className="py-2 px-3 text-slate-700">{l.modul}</td>
                    <td className="py-2 px-3 font-mono text-[11px] text-emerald-800">{l.action}</td>
                    <td className="py-2 px-3 text-slate-700">{l.detail}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
