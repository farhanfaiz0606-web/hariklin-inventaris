import React, { useState } from 'react';
import {
  Wrench,
  Search,
  CheckCircle,
  XCircle,
  Clock,
  ShieldCheck,
  FileSpreadsheet,
  Check,
  AlertCircle,
  X,
} from 'lucide-react';
import { Perbaikan, User, StatusPerbaikan } from '../types';
import { exportToCSV, formatRupiah } from '../utils/exportUtils';

interface PerbaikanViewProps {
  perbaikanList: Perbaikan[];
  onUpdateStatusPerbaikan: (
    perbaikanId: string,
    newStatus: StatusPerbaikan,
    options: {
      biayaAktual?: number;
      keteranganTambahan?: string;
      tanggalMulai?: string;
      tanggalSelesai?: string;
      alasanTolak?: string;
    }
  ) => void;
  currentUser: User;
}

export const PerbaikanView: React.FC<PerbaikanViewProps> = ({
  perbaikanList,
  onUpdateStatusPerbaikan,
  currentUser,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('SEMUA');

  // Selected item to update
  const [selectedTicket, setSelectedTicket] = useState<Perbaikan | null>(null);
  const [targetStatus, setTargetStatus] = useState<StatusPerbaikan | null>(null);

  // Form fields for update
  const [biayaAktual, setBiayaAktual] = useState<number>(0);
  const [tanggalMulai, setTanggalMulai] = useState(new Date().toISOString().split('T')[0]);
  const [tanggalSelesai, setTanggalSelesai] = useState(new Date().toISOString().split('T')[0]);
  const [alasanTolak, setAlasanTolak] = useState('');
  const [keteranganTambahan, setKeteranganTambahan] = useState('');

  const isAdmin = currentUser.role === 'ADMIN';

  const handleOpenAction = (ticket: Perbaikan, status: StatusPerbaikan) => {
    setSelectedTicket(ticket);
    setTargetStatus(status);
    setBiayaAktual(ticket.biayaAktual || ticket.estimasiBiaya || 0);
    setTanggalMulai(ticket.tanggalMulai || new Date().toISOString().split('T')[0]);
    setTanggalSelesai(new Date().toISOString().split('T')[0]);
    setAlasanTolak('');
    setKeteranganTambahan('');
  };

  const handleConfirmAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !targetStatus) return;

    onUpdateStatusPerbaikan(selectedTicket.id, targetStatus, {
      biayaAktual: Number(biayaAktual),
      tanggalMulai,
      tanggalSelesai,
      alasanTolak,
      keteranganTambahan,
    });

    setSelectedTicket(null);
    setTargetStatus(null);
  };

  const filteredList = perbaikanList.filter((it) => {
    const matchSearch =
      it.noPerbaikan.toLowerCase().includes(searchTerm.toLowerCase()) ||
      it.kodeBarang.toLowerCase().includes(searchTerm.toLowerCase()) ||
      it.namaBarang.toLowerCase().includes(searchTerm.toLowerCase()) ||
      it.namaPetugas.toLowerCase().includes(searchTerm.toLowerCase()) ||
      it.penyebabKerusakan.toLowerCase().includes(searchTerm.toLowerCase());

    const matchStatus = filterStatus === 'SEMUA' || it.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const handleExport = () => {
    const exportRows = filteredList.map((p) => ({
      'No Perbaikan': p.noPerbaikan,
      'Kode Barang': p.kodeBarang,
      'Nama Barang': p.namaBarang,
      'Jumlah Unit': p.jumlahBarang,
      Satuan: p.satuan,
      'Penyebab Kerusakan': p.penyebabKerusakan,
      'Nama Petugas': p.namaPetugas,
      'Estimasi Biaya': p.estimasiBiaya,
      'Biaya Aktual': p.biayaAktual || '-',
      'Tgl Mulai': p.tanggalMulai || '-',
      'Tgl Selesai': p.tanggalSelesai || '-',
      Status: p.status,
      'Disetujui Oleh': p.disetujuiOleh || '-',
      'ACC Selesai Oleh': p.accSelesaiOleh || '-',
      'Alasan Ditolak': p.ditolakAlasan || '-',
    }));
    exportToCSV('Laporan_Perbaikan_Barang_Hariklin', exportRows);
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Perbaikan &amp; Servis Alat</h1>
            <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">
              {perbaikanList.filter((p) => p.status !== 'Selesai Diperbaiki' && p.status !== 'Ditolak').length} Tiket Aktif
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Alur persetujuan bertingkat: Petugas mengerjakan/mengajukan selesai &middot; <strong className="text-slate-800">ACC Admin</strong> mengembalikan stok ke Master Barang
          </p>
        </div>

        <button
          onClick={handleExport}
          className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold border border-slate-200 transition-colors"
        >
          <FileSpreadsheet className="w-3.5 h-3.5" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari tiket PBK, kode barang, petugas..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500/20"
          />
        </div>

        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-700 bg-white"
        >
          <option value="SEMUA">Semua Status Perbaikan</option>
          <option value="Menunggu Persetujuan">1. Menunggu Persetujuan</option>
          <option value="Disetujui untuk Diperbaiki">2. Disetujui untuk Diperbaiki</option>
          <option value="Sementara Pengerjaan">3. Sementara Pengerjaan</option>
          <option value="Menunggu Persetujuan Selesai">4. Menunggu Persetujuan Selesai</option>
          <option value="Selesai Diperbaiki">5. Selesai Diperbaiki (Stok Aktif)</option>
          <option value="Ditolak">6. Ditolak</option>
        </select>
      </div>

      {/* Table Data Perbaikan */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                <th className="py-3 px-3">No Perbaikan</th>
                <th className="py-3 px-3">Nama Barang</th>
                <th className="py-3 px-3 text-right">Jumlah</th>
                <th className="py-3 px-3">Penyebab Kerusakan</th>
                <th className="py-3 px-3">Petugas Penanggung</th>
                <th className="py-3 px-3 text-right">Biaya</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-3 text-center">Aksi / Persetujuan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    Tidak ada tiket perbaikan yang cocok.
                  </td>
                </tr>
              ) : (
                filteredList.map((ticket) => {
                  const isDone = ticket.status === 'Selesai Diperbaiki';
                  const isRejected = ticket.status === 'Ditolak';

                  return (
                    <tr key={ticket.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-3 font-mono font-bold text-amber-900">{ticket.noPerbaikan}</td>
                      <td className="py-3 px-3 font-semibold text-slate-900">
                        <div>{ticket.namaBarang}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{ticket.kodeBarang}</div>
                      </td>
                      <td className="py-3 px-3 text-right font-mono font-bold text-slate-800 tabular-nums">
                        {ticket.jumlahBarang} {ticket.satuan}
                      </td>
                      <td className="py-3 px-3 text-slate-700 max-w-xs">
                        <div>{ticket.penyebabKerusakan}</div>
                        <div className="text-[10px] text-slate-400">{ticket.keteranganPerbaikan}</div>
                      </td>
                      <td className="py-3 px-3 text-slate-700">
                        <div>{ticket.namaPetugas}</div>
                        {ticket.disetujuiOleh && (
                          <div className="text-[10px] text-emerald-600">Disetujui: {ticket.disetujuiOleh}</div>
                        )}
                        {ticket.accSelesaiOleh && (
                          <div className="text-[10px] text-emerald-700 font-semibold">
                            ACC Selesai: {ticket.accSelesaiOleh}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-800">
                        {ticket.biayaAktual ? formatRupiah(ticket.biayaAktual) : formatRupiah(ticket.estimasiBiaya)}
                      </td>
                      <td className="py-3 px-3 text-center">
                        <span
                          className={`text-[11px] px-2 py-0.5 rounded font-semibold inline-block ${
                            ticket.status === 'Selesai Diperbaiki'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : ticket.status === 'Menunggu Persetujuan'
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : ticket.status === 'Disetujui untuk Diperbaiki'
                              ? 'bg-blue-50 text-blue-700 border border-blue-200'
                              : ticket.status === 'Sementara Pengerjaan'
                              ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                              : ticket.status === 'Menunggu Persetujuan Selesai'
                              ? 'bg-purple-50 text-purple-700 border border-purple-200'
                              : 'bg-rose-50 text-rose-700 border border-rose-200'
                          }`}
                        >
                          {ticket.status}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-center">
                        {!isDone && !isRejected && (
                          <div className="flex flex-wrap items-center justify-center gap-1.5">
                            {/* ADMIN: Approve initial repair */}
                            {isAdmin && ticket.status === 'Menunggu Persetujuan' && (
                              <>
                                <button
                                  onClick={() => handleOpenAction(ticket, 'Disetujui untuk Diperbaiki')}
                                  className="px-2 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white font-semibold text-[10px]"
                                >
                                  ACC Mulai
                                </button>
                                <button
                                  onClick={() => handleOpenAction(ticket, 'Ditolak')}
                                  className="px-2 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white font-semibold text-[10px]"
                                >
                                  Tolak
                                </button>
                              </>
                            )}

                            {/* PETUGAS: Mulai Pengerjaan */}
                            {ticket.status === 'Disetujui untuk Diperbaiki' && (
                              <button
                                onClick={() => handleOpenAction(ticket, 'Sementara Pengerjaan')}
                                className="px-2 py-1 rounded bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-[10px]"
                              >
                                Mulai Kerjakan
                              </button>
                            )}

                            {/* PETUGAS: Ajukan Selesai */}
                            {ticket.status === 'Sementara Pengerjaan' && (
                              <button
                                onClick={() => handleOpenAction(ticket, 'Menunggu Persetujuan Selesai')}
                                className="px-2 py-1 rounded bg-purple-600 hover:bg-purple-500 text-white font-semibold text-[10px]"
                              >
                                Ajukan Selesai
                              </button>
                            )}

                            {/* ADMIN: ACC SELESAI DIPERBAIKI (CRITICAL RULE) */}
                            {isAdmin && ticket.status === 'Menunggu Persetujuan Selesai' && (
                              <button
                                onClick={() => handleOpenAction(ticket, 'Selesai Diperbaiki')}
                                className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] shadow-xs flex items-center gap-1"
                              >
                                <ShieldCheck className="w-3.5 h-3.5" />
                                <span>ACC Selesai (Aktifkan Stok)</span>
                              </button>
                            )}
                          </div>
                        )}
                        {isDone && (
                          <span className="text-emerald-700 font-semibold text-[11px] flex items-center justify-center gap-1">
                            <Check className="w-3.5 h-3.5" />
                            Stok Kembali Aktif
                          </span>
                        )}
                        {isRejected && (
                          <span className="text-rose-600 text-[11px] italic">Perbaikan Ditolak</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL: Update Status / Persetujuan Perbaikan */}
      {selectedTicket && targetStatus && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-md overflow-hidden">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-amber-50">
              <div className="flex items-center gap-2">
                <Wrench className="w-4 h-4 text-amber-700" />
                <h3 className="font-bold text-amber-950 text-sm">Update Status: {targetStatus}</h3>
              </div>
              <button
                onClick={() => {
                  setSelectedTicket(null);
                  setTargetStatus(null);
                }}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmAction} className="p-4 space-y-3.5 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="font-semibold text-slate-800">{selectedTicket.namaBarang}</div>
                <div className="text-[11px] text-slate-500">
                  Nomor: <strong className="text-slate-800">{selectedTicket.noPerbaikan}</strong> &middot; Jumlah: {selectedTicket.jumlahBarang} {selectedTicket.satuan}
                </div>
              </div>

              {targetStatus === 'Selesai Diperbaiki' && (
                <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200 text-emerald-800 space-y-1">
                  <div className="font-bold flex items-center gap-1">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    Persetujuan Selesai oleh Admin
                  </div>
                  <p className="text-[11px]">
                    Dengan menyetujui, sebanyak <strong>{selectedTicket.jumlahBarang} {selectedTicket.satuan} {selectedTicket.namaBarang}</strong> akan otomatis dikembalikan ke Stok Aktif Master Barang dan siap dipinjamkan kembali.
                  </p>
                </div>
              )}

              {targetStatus === 'Ditolak' ? (
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Alasan Penolakan Perbaikan *</label>
                  <textarea
                    rows={2}
                    required
                    placeholder="Alasan perbaikan ditolak (misal: biaya melebihi harga unit baru)..."
                    value={alasanTolak}
                    onChange={(e) => setAlasanTolak(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                  />
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-slate-700 font-semibold mb-1">Biaya Perbaikan Aktual (Rp)</label>
                      <input
                        type="number"
                        min="0"
                        step="1000"
                        value={biayaAktual}
                        onChange={(e) => setBiayaAktual(Number(e.target.value))}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-700 font-semibold mb-1">
                        {targetStatus === 'Selesai Diperbaiki' ? 'Tanggal Selesai' : 'Tanggal Mulai'}
                      </label>
                      <input
                        type="date"
                        value={targetStatus === 'Selesai Diperbaiki' ? tanggalSelesai : tanggalMulai}
                        onChange={(e) =>
                          targetStatus === 'Selesai Diperbaiki'
                            ? setTanggalSelesai(e.target.value)
                            : setTanggalMulai(e.target.value)
                        }
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Catatan Tambahan Teknis</label>
                    <textarea
                      rows={2}
                      placeholder="Part yang diganti, garansi bengkel, dll..."
                      value={keteranganTambahan}
                      onChange={(e) => setKeteranganTambahan(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                    />
                  </div>
                </>
              )}

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedTicket(null);
                    setTargetStatus(null);
                  }}
                  className="px-3.5 py-2 rounded-lg border border-slate-200 text-slate-700 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className={`px-4 py-2 rounded-lg font-semibold text-white shadow-xs ${
                    targetStatus === 'Selesai Diperbaiki'
                      ? 'bg-emerald-600 hover:bg-emerald-500'
                      : targetStatus === 'Ditolak'
                      ? 'bg-rose-600 hover:bg-rose-500'
                      : 'bg-amber-600 hover:bg-amber-500'
                  }`}
                >
                  Konfirmasi Status: {targetStatus}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
