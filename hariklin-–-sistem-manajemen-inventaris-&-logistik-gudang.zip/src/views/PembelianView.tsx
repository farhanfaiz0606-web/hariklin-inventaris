import React, { useState } from 'react';
import {
  ShoppingCart,
  Search,
  CheckCircle,
  XCircle,
  ShieldCheck,
  FileSpreadsheet,
  Upload,
  Image as ImageIcon,
  Check,
  X,
  Plus,
} from 'lucide-react';
import { Pembelian, User, StatusPembelian, MasterBarang } from '../types';
import { exportToCSV, formatRupiah } from '../utils/exportUtils';

interface PembelianViewProps {
  pembelianList: Pembelian[];
  masterBarang: MasterBarang[];
  onUpdateStatusPembelian: (
    pembelianId: string,
    newStatus: StatusPembelian,
    options: {
      hargaAktual?: number;
      buktiPembelianUrl?: string;
      alasanTolak?: string;
    }
  ) => void;
  currentUser: User;
}

export const PembelianView: React.FC<PembelianViewProps> = ({
  pembelianList,
  masterBarang,
  onUpdateStatusPembelian,
  currentUser,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('SEMUA');

  // Action Modals State
  const [selectedPO, setSelectedPO] = useState<Pembelian | null>(null);
  const [targetStatus, setTargetStatus] = useState<StatusPembelian | null>(null);

  // Form fields for update
  const [hargaAktual, setHargaAktual] = useState<number>(0);
  const [buktiPembelianUrl, setBuktiPembelianUrl] = useState<string>('');
  const [alasanTolak, setAlasanTolak] = useState<string>('');

  const isAdmin = currentUser.role === 'ADMIN';

  const handleOpenAction = (po: Pembelian, status: StatusPembelian) => {
    setSelectedPO(po);
    setTargetStatus(status);
    setHargaAktual(po.hargaAktual || po.estimasiHarga || 0);
    setBuktiPembelianUrl(po.buktiPembelianUrl || '');
    setAlasanTolak('');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setBuktiPembelianUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleConfirmAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPO || !targetStatus) return;

    onUpdateStatusPembelian(selectedPO.id, targetStatus, {
      hargaAktual: Number(hargaAktual),
      buktiPembelianUrl: buktiPembelianUrl || undefined,
      alasanTolak,
    });

    setSelectedPO(null);
    setTargetStatus(null);
  };

  const filteredList = pembelianList.filter((po) => {
    const matchSearch =
      po.noPengadaan.toLowerCase().includes(searchTerm.toLowerCase()) ||
      po.kodeBarang.toLowerCase().includes(searchTerm.toLowerCase()) ||
      po.namaBarang.toLowerCase().includes(searchTerm.toLowerCase()) ||
      po.namaPengaju.toLowerCase().includes(searchTerm.toLowerCase()) ||
      po.alasanPembelian.toLowerCase().includes(searchTerm.toLowerCase());

    const matchStatus = filterStatus === 'SEMUA' || po.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const handleExport = () => {
    const exportRows = filteredList.map((po) => ({
      'No Pengadaan': po.noPengadaan,
      'Kode Barang': po.kodeBarang,
      'Nama Barang': po.namaBarang,
      'Jumlah Unit': po.jumlahDibutuhkan,
      Satuan: po.satuan,
      'Alasan Pengadaan': po.alasanPembelian,
      'Nama Pengaju': po.namaPengaju,
      'Estimasi Biaya': po.estimasiHarga,
      'Harga Aktual': po.hargaAktual || '-',
      Status: po.status,
      'Disetujui Oleh': po.disetujuiOleh || '-',
      'ACC Diterima Oleh': po.accDiterimaOleh || '-',
      'Tgl Diterima': po.tanggalDiterima || '-',
    }));
    exportToCSV('Laporan_Pembelian_Barang_Hariklin', exportRows);
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Pengadaan &amp; Pembelian Barang Baru</h1>
            <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-purple-50 text-purple-700 border border-purple-200">
              {pembelianList.filter((p) => p.status !== 'Sudah Dibeli' && p.status !== 'Ditolak').length} Pengajuan Aktif
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Penggantian inventaris rusak yang tidak ekonomis diperbaiki. Begitu berstatus <strong className="text-slate-800">Sudah Dibeli &amp; ACC Admin</strong>, unit otomatis aktif di Master.
          </p>
        </div>

        <button
          onClick={handleExport}
          className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold border border-slate-200 transition-colors"
        >
          <FileSpreadsheet className="w-3.5 h-3.5" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari PO, kode barang, nama pengaju..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 text-xs focus:ring-2 focus:ring-purple-500/20"
          />
        </div>

        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-700 bg-white"
        >
          <option value="SEMUA">Semua Status Pembelian</option>
          <option value="Menunggu Persetujuan">1. Menunggu Persetujuan</option>
          <option value="Disetujui untuk Dibeli">2. Disetujui untuk Dibeli</option>
          <option value="Belum Dibeli">3. Belum Dibeli (Dalam Proses Pengadaan)</option>
          <option value="Sudah Dibeli">4. Sudah Dibeli (Stok Masuk Aktif)</option>
          <option value="Ditolak">5. Ditolak</option>
        </select>
      </div>

      {/* Table Data Pembelian */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200">
                <th className="py-3 px-3">No Pengadaan</th>
                <th className="py-3 px-3">Nama Barang</th>
                <th className="py-3 px-3 text-right">Jumlah Unit</th>
                <th className="py-3 px-3">Alasan Pengadaan</th>
                <th className="py-3 px-3">Pengaju &amp; Tanggal</th>
                <th className="py-3 px-3 text-right">Estimasi / Aktual</th>
                <th className="py-3 px-3 text-center">Bukti Nota</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-3 text-center">Aksi / Persetujuan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-400">
                    Tidak ada transaksi pembelian yang cocok.
                  </td>
                </tr>
              ) : (
                filteredList.map((po) => {
                  const isDone = po.status === 'Sudah Dibeli';
                  const isRejected = po.status === 'Ditolak';

                  return (
                    <tr key={po.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-3 font-mono font-bold text-purple-900">{po.noPengadaan}</td>
                      <td className="py-3 px-3 font-semibold text-slate-900">
                        <div>{po.namaBarang}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{po.kodeBarang}</div>
                      </td>
                      <td className="py-3 px-3 text-right font-mono font-bold text-slate-800 tabular-nums">
                        {po.jumlahDibutuhkan} {po.satuan}
                      </td>
                      <td className="py-3 px-3 text-slate-700 max-w-xs">{po.alasanPembelian}</td>
                      <td className="py-3 px-3 text-slate-600">
                        <div>{po.namaPengaju}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{po.tanggalPengajuan}</div>
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-800">
                        <div>{po.hargaAktual ? formatRupiah(po.hargaAktual) : formatRupiah(po.estimasiHarga)}</div>
                        {po.hargaAktual && (
                          <div className="text-[10px] text-slate-400">Est: {formatRupiah(po.estimasiHarga)}</div>
                        )}
                      </td>
                      <td className="py-3 px-3 text-center">
                        {po.buktiPembelianUrl ? (
                          <a
                            href={po.buktiPembelianUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1 text-[11px] font-semibold text-purple-700 hover:text-purple-800"
                          >
                            <ImageIcon className="w-3.5 h-3.5" />
                            <span>Lihat</span>
                          </a>
                        ) : (
                          <span className="text-slate-400">-</span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-center">
                        <span
                          className={`text-[11px] px-2 py-0.5 rounded font-semibold inline-block ${
                            po.status === 'Sudah Dibeli'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : po.status === 'Menunggu Persetujuan'
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : po.status === 'Disetujui untuk Dibeli'
                              ? 'bg-blue-50 text-blue-700 border border-blue-200'
                              : po.status === 'Belum Dibeli'
                              ? 'bg-purple-50 text-purple-700 border border-purple-200'
                              : 'bg-rose-50 text-rose-700 border border-rose-200'
                          }`}
                        >
                          {po.status}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-center">
                        {!isDone && !isRejected && (
                          <div className="flex flex-wrap items-center justify-center gap-1.5">
                            {/* ADMIN: Approve purchase */}
                            {isAdmin && po.status === 'Menunggu Persetujuan' && (
                              <>
                                <button
                                  onClick={() => handleOpenAction(po, 'Disetujui untuk Dibeli')}
                                  className="px-2 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white font-semibold text-[10px]"
                                >
                                  ACC Beli
                                </button>
                                <button
                                  onClick={() => handleOpenAction(po, 'Ditolak')}
                                  className="px-2 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white font-semibold text-[10px]"
                                >
                                  Tolak
                                </button>
                              </>
                            )}

                            {/* Move to Belum Dibeli (Dalam Proses) */}
                            {po.status === 'Disetujui untuk Dibeli' && (
                              <button
                                onClick={() => handleOpenAction(po, 'Belum Dibeli')}
                                className="px-2 py-1 rounded bg-purple-600 hover:bg-purple-500 text-white font-semibold text-[10px]"
                              >
                                Proses Beli
                              </button>
                            )}

                            {/* ADMIN: ACC BARANG DITERIMA / SUDAH DIBELI -> STOK MASUK AKTIF */}
                            {isAdmin && (po.status === 'Belum Dibeli' || po.status === 'Disetujui untuk Dibeli') && (
                              <button
                                onClick={() => handleOpenAction(po, 'Sudah Dibeli')}
                                className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] shadow-xs flex items-center gap-1"
                              >
                                <ShieldCheck className="w-3.5 h-3.5" />
                                <span>ACC Diterima (Aktifkan)</span>
                              </button>
                            )}
                          </div>
                        )}
                        {isDone && (
                          <span className="text-emerald-700 font-semibold text-[11px] flex items-center justify-center gap-1">
                            <Check className="w-3.5 h-3.5" />
                            Stok Aktif Bertambah
                          </span>
                        )}
                        {isRejected && (
                          <span className="text-rose-600 text-[11px] italic">Pengadaan Ditolak</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL: Update Status / Persetujuan Pembelian */}
      {selectedPO && targetStatus && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-md overflow-hidden">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-purple-50">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-4 h-4 text-purple-700" />
                <h3 className="font-bold text-purple-950 text-sm">Pembaruan Status: {targetStatus}</h3>
              </div>
              <button
                onClick={() => {
                  setSelectedPO(null);
                  setTargetStatus(null);
                }}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmAction} className="p-4 space-y-3.5 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="font-semibold text-slate-800">{selectedPO.namaBarang}</div>
                <div className="text-[11px] text-slate-500">
                  No PO: <strong className="text-slate-800">{selectedPO.noPengadaan}</strong> &middot; Jumlah: {selectedPO.jumlahDibutuhkan} {selectedPO.satuan}
                </div>
              </div>

              {targetStatus === 'Sudah Dibeli' && (
                <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200 text-emerald-800 space-y-1">
                  <div className="font-bold flex items-center gap-1">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    Persetujuan Penerimaan Fisik oleh Admin
                  </div>
                  <p className="text-[11px]">
                    Dengan konfirmasi ini, barang pengganti sebanyak <strong>{selectedPO.jumlahDibutuhkan} {selectedPO.satuan}</strong> otomatis diaktifkan ke Stok Aktif Master Barang dan jumlah menunggu pembelian akan berkurang.
                  </p>
                </div>
              )}

              {targetStatus === 'Ditolak' ? (
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Alasan Penolakan Pengadaan *</label>
                  <textarea
                    rows={2}
                    required
                    placeholder="Alasan pembelian ditolak atau ditunda..."
                    value={alasanTolak}
                    onChange={(e) => setAlasanTolak(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                  />
                </div>
              ) : (
                <>
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Harga Beli Aktual (Rp)</label>
                    <input
                      type="number"
                      min="0"
                      step="1000"
                      value={hargaAktual}
                      onChange={(e) => setHargaAktual(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-mono"
                    />
                  </div>

                  {/* Upload Nota Bukti Pembelian */}
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Bukti Nota Pembelian / Kwitansi</label>
                    <div className="flex items-center gap-3">
                      <label className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded border border-slate-300 cursor-pointer text-slate-700 font-medium">
                        <Upload className="w-3.5 h-3.5 text-slate-500" />
                        <span>Unggah Foto Nota</span>
                        <input type="file" accept="image/*" onChange={handleFileUpload} className="sr-only" />
                      </label>
                      {buktiPembelianUrl && (
                        <div className="flex items-center gap-1.5 text-emerald-600 text-[11px] font-semibold">
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span>Nota siap dilampirkan</span>
                        </div>
                      )}
                    </div>
                  </div>
                </>
              )}

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedPO(null);
                    setTargetStatus(null);
                  }}
                  className="px-3.5 py-2 rounded-lg border border-slate-200 text-slate-700 font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className={`px-4 py-2 rounded-lg font-semibold text-white shadow-xs ${
                    targetStatus === 'Sudah Dibeli'
                      ? 'bg-emerald-600 hover:bg-emerald-500'
                      : targetStatus === 'Ditolak'
                      ? 'bg-rose-600 hover:bg-rose-500'
                      : 'bg-purple-600 hover:bg-purple-500'
                  }`}
                >
                  Simpan Status: {targetStatus}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
